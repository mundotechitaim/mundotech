<?php
header("Content-Type: application/json");

// Caminho do arquivo JSON
$jsonFile = "precos.json";

// Método GET: Retorna os preços
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (file_exists($jsonFile)) {
        echo file_get_contents($jsonFile);
    } else {
        echo json_encode([]);
    }
    exit;
}

// Método POST: Atualiza os preços
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    if ($data) {
        file_put_contents($jsonFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo json_encode(["success" => true, "message" => "Preços atualizados com sucesso."]);
    } else {
        echo json_encode(["success" => false, "message" => "Erro ao salvar os preços."]);
    }
    exit;
}

// Retorna erro caso o método não seja permitido
echo json_encode(["success" => false, "message" => "Método não permitido."]);
?>
