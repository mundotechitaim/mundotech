// ============================
// Pendências de OS - Exibição e Observações
// ============================

// Exemplo esperado:
// const senhasVendedores = {"senha123": "Carlos Silva", "admin01": "Ana P."};

async function carregarAlertasOS() {
    const container = document.getElementById('novaTabelaOSWrapper');
    if (!container) {
        console.warn('⚠️ novaTabelaOSWrapper não encontrado no DOM');
        return;
    }

    console.log('🚀 Iniciando carregarAlertasOS()');
    container.innerHTML = '<p class="text-center py-3"><i class="fas fa-spinner fa-spin fa-2x"></i> Carregando ordens de serviço pendentes...</p>';

    try {
        const res = await fetch('https://www.mundotechip.com.br/index.php/api/os/pendentes-alerta-com-historico');
        const data = await res.json();

        if (!Array.isArray(data) || data.length === 0) {
            container.innerHTML = '<p class="text-success text-center py-3">Nenhuma OS pendente que necessite atenção imediata 🎉</p>';
            atualizarContadorOSPendencias?.(0);
            return;
        }

        atualizarContadorOSPendencias?.(data.length);

        let html = `
            <table class="table table-striped table-hover table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Cliente</th>
                        <th>Aparelho</th>
                        <th>Status</th>
                        <th>Data Inicial</th>
                        <th>Responsável OS</th>
                        <th>Funcionário OS</th>
                        <th>Histórico de Observações</th>
                        <th>Nova Observação</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
        `;

        data.forEach(os => {
            const { idOs, nomeCliente, descricaoProduto, status, dataInicial, responsavel, atendente_nome, observacoes = [] } = os;
            const aparelho = descricaoProduto || '<em>(não especificado)</em>';
            const responsavelOS = responsavel || '<em>(não definido)</em>';
            const funcionarioHtml = atendente_nome ? `<span class="badge badge-primary">${atendente_nome}</span>` : '<em>(não informado)</em>';

            let historicoHtml = '<em>(Nenhuma observação anterior)</em>';
            if (observacoes.length > 0) {
                const ordenadas = observacoes.sort((a, b) => new Date(b.dataHora) - new Date(a.dataHora));
                historicoHtml = '<ul class="list-unstyled mb-0 historico-observacoes-lista">';
                ordenadas.forEach(obs => {
                    historicoHtml += `
                        <li class="mb-1">
                            <small class="text-muted"><strong>${formatarDataHora(obs.dataHora)} (${obs.responsavel || 'Sistema'}):</strong></small><br>
                            <span class="observacao-texto">${obs.texto}</span>
                        </li>`;
                });
                historicoHtml += '</ul>';
            }

            html += `
                <tr>
                    <td>${idOs}</td>
                    <td>${nomeCliente}</td>
                    <td>${aparelho}</td>
                    <td><span class="badge badge-warning">${status}</span></td>
                    <td>${formatarData(dataInicial)}</td>
                    <td>${responsavelOS}</td>
                    <td>${funcionarioHtml}</td>
                    <td class="celula-historico">${historicoHtml}</td>
                    <td><textarea rows="3" class="form-control form-control-sm motivo-textarea" data-id="${idOs}" placeholder="Adicionar nova observação..."></textarea></td>
                    <td class="text-center">
                        <button class="btn btn-dark btn-sm btn-block mb-1 salvar-observacao" data-id="${idOs}"><i class="fas fa-save"></i> Salvar Obs.</button>
                    </td>
                </tr>`;
        });

        html += '</tbody></table>';
        container.innerHTML = html;

        container.querySelectorAll('.salvar-observacao').forEach(btn => {
            btn.addEventListener('click', async () => {
                const idOs = btn.dataset.id;
                const textarea = container.querySelector(`textarea[data-id="${idOs}"]`);
                const textoObservacao = textarea.value.trim();

                if (!textoObservacao) {
                    alert('Por favor, escreva a observação antes de salvar.');
                    textarea.focus();
                    return;
                }

                if (!senhasVendedores || Object.keys(senhasVendedores).length === 0) {
                    alert("Erro de configuração: sistema de senhas não encontrado.");
                    return;
                }

                const senha = prompt("Digite sua senha de funcionário:");
                if (!senha) return;

                const nomeResponsavel = senhasVendedores[senha];
                if (!nomeResponsavel) {
                    alert('Senha inválida.');
                    return;
                }

                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Salvando...';

                try {
                    const response = await fetch(`https://www.mundotechip.com.br/index.php/api/os/adicionar-observacao/${idOs}`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ textoObservacao, responsavel: nomeResponsavel })
                    });
                    const result = await response.json();

                    if (result.success) {
                        alert('✅ Observação salva com sucesso!');
                        textarea.value = '';
                        carregarAlertasOS();
                    } else {
                        alert('❌ Erro: ' + (result.message || 'Erro desconhecido.'));
                    }
                } catch (e) {
                    console.error('❌ Erro ao salvar observação:', e);
                    alert('❌ Erro na requisição.');
                } finally {
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-save"></i> Salvar Obs.';
                }
            });
        });

    } catch (err) {
        console.error('❌ Erro ao carregar OS pendentes:', err);
        container.innerHTML = '<p class="text-danger text-center py-3">❌ Erro ao carregar OS. Tente novamente mais tarde.</p>';
        atualizarContadorOSPendencias?.('!');
    }
}

function formatarData(dataStr) {
    if (!dataStr?.includes('-')) return 'N/A';
    const [ano, mes, dia] = dataStr.split(' ')[0].split('-');
    return `${dia}/${mes}/${ano}`;
}

function formatarDataHora(dataHoraStr) {
    try {
        const data = new Date(dataHoraStr);
        if (isNaN(data)) return dataHoraStr;
        const dia = String(data.getDate()).padStart(2, '0');
        const mes = String(data.getMonth() + 1).padStart(2, '0');
        const ano = data.getFullYear();
        const horas = String(data.getHours()).padStart(2, '0');
        const minutos = String(data.getMinutes()).padStart(2, '0');
        return `${dia}/${mes}/${ano} ${horas}:${minutos}`;
    } catch {
        return dataHoraStr;
    }
}

function atualizarContadorOSPendencias(total) {
    const contador = document.getElementById('contadorOSPendencias');
    if (!contador) return;
    contador.textContent = total;
    contador.style.display = total > 0 || total === '!' ? 'inline-block' : 'none';
    contador.classList.toggle('bg-danger', total > 0 || total === '!');
    contador.classList.toggle('bg-secondary', total <= 0 && total !== '!');
}

window.carregarAlertasOS = carregarAlertasOS;

document.addEventListener('DOMContentLoaded', () => {
    const btn = document.querySelector('button[data-page="os-alertas"]');

    // Carrega inicialmente para mostrar contador mesmo sem clicar
    carregarAlertasOS();

    // Recarrega ao clicar na aba "Pendências OS"
    if (btn) {
        btn.addEventListener('click', () => {
            const pagina = document.getElementById('pagina-os-alertas');
            if (pagina?.classList.contains('active')) {
                carregarAlertasOS();
            }
        });
    }

    // Atualiza automaticamente a cada 30 segundos
    setInterval(() => {
        carregarAlertasOS();
    }, 30000);
});

// ============================
// CSS (inline via JS para aplicação direta)
// ============================
const estiloPendencias = document.createElement('style');
estiloPendencias.textContent = `
    .historico-observacoes-lista li {
        background-color: #f8f9fa;
        border-left: 3px solid #007bff;
        padding: 6px 10px;
        margin-bottom: 5px;
        border-radius: 4px;
    }
    .badge-primary {
        background-color: #007bff;
    }
    .motivo-textarea {
        resize: vertical;
    }
    .btn.salvar-observacao {
        font-weight: 500;
    }
`;
document.head.appendChild(estiloPendencias);