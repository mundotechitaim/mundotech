/**
 * estoque-alertas.js
 *
 * Gerencia a lógica de verificação de estoque mínimo (local e global),
 * exibição da seção de alertas na página de Alertas, limpeza de alertas órfãos,
 * atualização periódica e armazenamento/gerenciamento de alertas no localStorage.
 *
 * Depende de:
 * - Variáveis globais de config.js: lojaAtual, shopCode, senhasVendedores
 * - Função global de config.js: fetchComToken
 * - Funções globais de ui-interactions.js: window.atualizarContadorAlertasUI, window.exibirPainelDeAlertas
 */

// --- Configurações e Constantes Globais do Módulo ---

const CONFIG_ALERTAS = {
    minimoGlobal: {
        peliculas: 10,
        carregadores: 5,
        cabos: 5,
        capinhas: 10,
        outros: 10
    },
    minimoLocal: {
        peliculas: 5,
        carregadores: 3,
        cabos: 3,
        capinhas: 5,
        outros: 5
    },
};

const FILTRO_CATEGORIA_API_NEXTAR = 'peliculasloja';
const INTERVALO_ATUALIZACAO_ALERTAS_MS = 5 * 60 * 1000; // 5 minutos

// --- Variáveis Globais do Módulo ---
let alertasLocaisAtivos;
try {
    alertasLocaisAtivos = JSON.parse(localStorage.getItem('alertas_locais_ativos') || '{}');
} catch (e) {
    console.error("Erro ao parsear 'alertas_locais_ativos' do localStorage. Usando objeto vazio.", e);
    alertasLocaisAtivos = {};
}

let alertasGlobaisAtivos;
try {
    alertasGlobaisAtivos = JSON.parse(localStorage.getItem('alertas_globais_ativos') || '{}');
} catch (e) {
    console.error("Erro ao parsear 'alertas_globais_ativos' do localStorage. Usando objeto vazio.", e);
    alertasGlobaisAtivos = {};
}

let todosOsProdutosCarregados = [];

// --- Funções Utilitárias ---

function getCategoriaProduto(produto) {
    const desc = (produto?.description || '').toLowerCase();
    if (desc.includes('película') || desc.includes('pelicula') || desc.includes('cerâmica') || desc.includes('vidro')) return 'peliculas';
    if (desc.includes('carregador') || desc.includes('charger') || desc.includes('fonte')) return 'carregadores';
    if (desc.includes('cabo')) return 'cabos';
    if (desc.includes('capinha') || desc.includes('case')) return 'capinhas';
    return 'outros';
}

// --- Limpeza de Alertas Órfãos ---

function limparAlertasGlobaisOrfaos() {
    if (!todosOsProdutosCarregados || !alertasGlobaisAtivos) return;

    const codigosDeProdutosAtuais = new Set(todosOsProdutosCarregados.map(p => p.code));
    let alterado = false;

    for (const alertaID in alertasGlobaisAtivos) {
        if (Object.hasOwnProperty.call(alertasGlobaisAtivos, alertaID)) {
            const codigoProdutoAlerta = alertaID.substring("global_".length);
            if (!codigosDeProdutosAtuais.has(codigoProdutoAlerta)) {
                console.log(`[Limpeza] Removendo alerta global órfão para produto ${codigoProdutoAlerta} (ID: ${alertaID})`);
                delete alertasGlobaisAtivos[alertaID];
                alterado = true;
            }
        }
    }

    if (alterado) {
        try {
            localStorage.setItem('alertas_globais_ativos', JSON.stringify(alertasGlobaisAtivos));
        } catch (e) {
            console.error("[limparAlertasGlobaisOrfaos] Erro ao salvar no localStorage:", e);
        }
    }
}

function limparAlertasLocaisOrfaos() {
    if (!todosOsProdutosCarregados || !alertasLocaisAtivos || !lojaAtual) return;

    const codigosDeProdutosValidosParaLojaAtual = new Set();
    todosOsProdutosCarregados.forEach(p => {
        // === IMPORTANTE: Adapte a condição abaixo para sua estrutura de dados ===
        // Exemplo: Se a loja está na descrição da categoria (ex: "outroslojaloja3")
        // E 'lojaAtual' é "loja3"
        if (p.category?.description?.toLowerCase().includes(lojaAtual.toLowerCase())) {
             codigosDeProdutosValidosParaLojaAtual.add(p.code);
        }
        // Exemplo alternativo: Se o produto 'p' tem um campo como 'p.identificadorDaLoja'
        // if (p.identificadorDaLoja === lojaAtual) {
        //     codigosDeProdutosValidosParaLojaAtual.add(p.code);
        // }
    });

    let alterado = false;
    for (const alertaID in alertasLocaisAtivos) {
        if (Object.hasOwnProperty.call(alertasLocaisAtivos, alertaID)) {
            const parts = alertaID.split('_');
            const codigoProdutoAlerta = parts[0];
            const lojaDoAlerta = parts.slice(1).join('_');

            if (lojaDoAlerta === lojaAtual) {
                if (!codigosDeProdutosValidosParaLojaAtual.has(codigoProdutoAlerta)) {
                    console.log(`[Limpeza] Removendo alerta local órfão para produto ${codigoProdutoAlerta} na loja ${lojaAtual} (ID: ${alertaID})`);
                    delete alertasLocaisAtivos[alertaID];
                    alterado = true;
                }
            }
        }
    }

    if (alterado) {
        try {
            localStorage.setItem('alertas_locais_ativos', JSON.stringify(alertasLocaisAtivos));
        } catch (e) {
            console.error("[limparAlertasLocaisOrfaos] Erro ao salvar no localStorage:", e);
        }
    }
}

// --- Carregamento de Dados ---

async function carregarTodosProdutosParaAlertas() {
    if (!shopCode || typeof fetchComToken !== 'function') {
        console.error("[carregarTodosProdutosParaAlertas] Erro: 'shopCode' ou 'fetchComToken' não definidos.");
        return Promise.reject("Configuração inválida para carregar produtos."); // Retorna uma promessa rejeitada
    }
    const url = `https://api.web.nextar.com.br/api/v1/product/${shopCode}?page=0&size=1500&sort=description&direction=asc&pdv=true&filter=active&_=${Date.now()}`;

    console.log("[carregarTodosProdutosParaAlertas] Buscando produtos da API...");
    try {
        const res = await fetchComToken(url);
        if (!res.ok) throw new Error(`Erro ${res.status} ao carregar produtos da API`);

        const json = await res.json();
        const produtosCarregadosDaAPI = json.content || [];
        console.debug(`[carregarTodosProdutosParaAlertas] ${produtosCarregadosDaAPI.length} produtos recebidos da API.`);

        if (FILTRO_CATEGORIA_API_NEXTAR) {
            todosOsProdutosCarregados = produtosCarregadosDaAPI.filter(p =>
                p.category?.description?.toLowerCase().includes(FILTRO_CATEGORIA_API_NEXTAR)
            );
            console.log(`[carregarTodosProdutosParaAlertas] Produtos filtrados por '${FILTRO_CATEGORIA_API_NEXTAR}': ${todosOsProdutosCarregados.length}`);
        } else {
            todosOsProdutosCarregados = produtosCarregadosDaAPI;
            console.log(`[carregarTodosProdutosParaAlertas] Usando todos os ${todosOsProdutosCarregados.length} produtos carregados.`);
        }

        console.log("[carregarTodosProdutosParaAlertas] Limpando alertas órfãos...");
        limparAlertasGlobaisOrfaos();
        limparAlertasLocaisOrfaos();

        console.log("[carregarTodosProdutosParaAlertas] Recalculando alertas globais...");
        todosOsProdutosCarregados.forEach(p => verificarEstoqueMinimoGlobal(p));

        // A exibição é chamada pelo cicloDeAtualizacaoDeAlertas após todas as operações.
        // exibirAlertas(); // Movido para cicloDeAtualizacaoDeAlertas

    } catch (err) {
        console.error("[carregarTodosProdutosParaAlertas] Falha ao carregar ou processar produtos:", err);
        throw err; // Propaga o erro para ser tratado pelo chamador (cicloDeAtualizacaoDeAlertas)
    }
}

// --- Lógica de Verificação de Estoque ---

function verificarEstoqueMinimoLocal(produto) {
    if (!produto || !produto.code || !produto.description) return;
    if (!lojaAtual) {
        console.warn("[verificarEstoqueMinimoLocal] 'lojaAtual' não definida.");
        return;
    }

    const categoria = getCategoriaProduto(produto);
    if (!CONFIG_ALERTAS.minimoLocal[categoria] && categoria !== 'outros' && categoria !== 'capinhas') {
        return;
    }
    const minimoLocal = CONFIG_ALERTAS.minimoLocal[categoria] ?? (categoria === 'capinhas' ? 5 : 3);

    const code = produto.code;
    const lojaID = lojaAtual;
    const qtdAtual = produto.current_stock ?? 0;
    const alertaID = `${code}_${lojaID}`;
    let mudouEstado = false;

    if (qtdAtual < minimoLocal) {
        if (!alertasLocaisAtivos[alertaID] || alertasLocaisAtivos[alertaID].estoqueAtual !== qtdAtual) {
            alertasLocaisAtivos[alertaID] = {
                id: alertaID,
                produto: produto.description,
                loja: lojaID,
                code,
                estoqueAtual: qtdAtual,
                minimo: minimoLocal,
                categoria
            };
            mudouEstado = true;
            console.log(`[ALERTA LOCAL ATIVADO] ${produto.description} (${lojaID}): ${qtdAtual}/${minimoLocal}`);
        }
    } else {
        if (alertasLocaisAtivos[alertaID]) {
            delete alertasLocaisAtivos[alertaID];
            mudouEstado = true;
            console.log(`[ALERTA LOCAL RESOLVIDO AUTO] ${produto.description} (${lojaID}): ${qtdAtual}/${minimoLocal}`);
        }
    }

    if (mudouEstado) {
        try {
            localStorage.setItem('alertas_locais_ativos', JSON.stringify(alertasLocaisAtivos));
            // exibirAlertas(); // Será chamado centralizadamente
            // if (typeof window.atualizarContadorAlertasUI === 'function') { // Será chamado centralizadamente
            //     window.atualizarContadorAlertasUI();
            // }
        } catch (e) {
            console.error("[verificarEstoqueMinimoLocal] Erro ao salvar no localStorage:", e);
        }
    }
}

function verificarEstoqueMinimoGlobal(produto) {
    if (!produto || !produto.code || !produto.description || !todosOsProdutosCarregados?.length) return;

    const categoria = getCategoriaProduto(produto);
    if (!CONFIG_ALERTAS.minimoGlobal[categoria] && categoria !== 'outros' && categoria !== 'capinhas') {
        return;
    }
    const minimoGlobal = CONFIG_ALERTAS.minimoGlobal[categoria] ?? 10;

    const produtosIguais = todosOsProdutosCarregados.filter(p => p.code === produto.code);
    const estoqueTotal = produtosIguais.reduce((soma, p) => soma + (p.current_stock ?? 0), 0);
    const alertaID = `global_${produto.code}`;
    let mudouEstado = false;

    if (estoqueTotal < minimoGlobal) {
        const novoAlerta = {
            id: alertaID,
            produto: produto.description,
            code: produto.code,
            estoqueTotal,
            minimoGlobal,
            categoria
        };
        if (!alertasGlobaisAtivos[alertaID] || alertasGlobaisAtivos[alertaID].estoqueTotal !== estoqueTotal) {
            alertasGlobaisAtivos[alertaID] = novoAlerta;
            mudouEstado = true;
            console.log(`[ALERTA GLOBAL ATIVADO/ATUALIZADO] ${produto.description}: ${estoqueTotal}/${minimoGlobal}`);
        }
    } else {
        if (alertasGlobaisAtivos[alertaID]) {
            delete alertasGlobaisAtivos[alertaID];
            mudouEstado = true;
            console.log(`[ALERTA GLOBAL RESOLVIDO AUTO] ${produto.description}: ${estoqueTotal}/${minimoGlobal}`);
        }
    }

    if (mudouEstado) {
        try {
            localStorage.setItem('alertas_globais_ativos', JSON.stringify(alertasGlobaisAtivos));
        } catch (e) {
            console.error("[verificarEstoqueMinimoGlobal] Erro ao salvar no localStorage:", e);
        }
    }
}

// --- Lógica de Ações de Alerta ---

function copiarMensagemAlertaGlobal(alertaCode) {
    if (typeof senhasVendedores === 'undefined') {
        alert("Erro: Configuração de senhas de vendedores não encontrada.");
        return;
    }
    const alerta = alertasGlobaisAtivos[`global_${alertaCode}`];
    if (!alerta) {
        alert("Alerta global não encontrado para cópia.");
        return;
    }
    const senha = prompt(`COPIAR MSG ALERTA GLOBAL (${alerta.produto}):\nDigite a senha do vendedor:`);
    if (!senha) return;
    const vendedor = senhasVendedores[senha];
    if (!vendedor) {
        alert("Senha inválida. Ação cancelada.");
        return;
    }
    const produtosRelacionados = todosOsProdutosCarregados.filter(p => p.code === alerta.code);
    const estoqueTotalAtual = produtosRelacionados.reduce((soma, p) => soma + (p.current_stock ?? 0), 0);
    const minimoGlobalParaProduto = CONFIG_ALERTAS.minimoGlobal[alerta.categoria] ?? CONFIG_ALERTAS.minimoGlobal['outros'] ?? 10;
    const msg = `🚨 ALERTA DE ESTOQUE GLOBAL 🚨\n=============================\n📦 Produto: ${alerta.produto}\n📉 Estoque Total Atual (todas lojas): ${estoqueTotalAtual} unidades\n📈 Mínimo Global Ideal: ${minimoGlobalParaProduto}\n=============================\n👤 Ação registrada por: ${vendedor}`;
    navigator.clipboard.writeText(msg).then(() => {
        alert("Mensagem de Alerta Global copiada com sucesso!\n\n" + msg);
    }).catch(err => {
        console.error("[copiarMensagemAlertaGlobal] Erro ao copiar:", err);
        alert("Erro ao copiar mensagem. Verifique o console.");
    });
}

function resolverAlertaLocalManualmente(alertaID) {
    if (typeof senhasVendedores === 'undefined') {
        alert("Erro: Configuração de senhas de vendedores não encontrada.");
        return;
    }
    const alertaParaResolver = alertasLocaisAtivos[alertaID];
    if (!alertaParaResolver) {
        alert(`Alerta local com ID ${alertaID} não encontrado para resolver.`);
        return;
    }
    const senha = prompt(`RESOLVER ALERTA LOCAL MANUALMENTE:\nProduto: ${alertaParaResolver.produto}\nLoja: ${alertaParaResolver.loja}\nDigite a senha:`);
    if (!senha) return;
    if (!senhasVendedores[senha]) {
        alert("Senha inválida. Operação cancelada.");
        return;
    }
    const alertaRemovido = { ...alertasLocaisAtivos[alertaID] };
    delete alertasLocaisAtivos[alertaID];
    try {
        localStorage.setItem('alertas_locais_ativos', JSON.stringify(alertasLocaisAtivos));
        console.log(`[resolverAlertaLocalManualmente] Alerta resolvido por ${senhasVendedores[senha]}: ${alertaRemovido.produto} (${alertaID})`);
        alert(`Alerta local para "${alertaRemovido.produto}" na ${alertaRemovido.loja} resolvido com sucesso!`);
        exibirAlertas();
        if (typeof window.atualizarContadorAlertasUI === 'function') {
            window.atualizarContadorAlertasUI();
        }
        if (document.getElementById('pagina-alertas')?.classList.contains('active') && typeof window.exibirPainelDeAlertas === 'function') {
            window.exibirPainelDeAlertas();
        }
    } catch (e) {
        console.error("[resolverAlertaLocalManualmente] Erro:", e);
        alertasLocaisAtivos[alertaID] = alertaRemovido;
        alert("Erro ao salvar a resolução do alerta local.");
    }
}

function resolverAlertaGlobalManualmente(alertaCode) {
    if (typeof senhasVendedores === 'undefined') {
        alert("Erro: Configuração de senhas de vendedores não encontrada.");
        return;
    }
    const alertaID = `global_${alertaCode}`;
    const alertaParaResolver = alertasGlobaisAtivos[alertaID];
    if (!alertaParaResolver) {
        alert(`Alerta global para produto código ${alertaCode} não encontrado.`);
        return;
    }
    const senha = prompt(`RESOLVER ALERTA GLOBAL MANUALMENTE:\nProduto: ${alertaParaResolver.produto}\nEstoque Total: ${alertaParaResolver.estoqueTotal}\nDigite a senha:`);
    if (!senha) return;
    if (!senhasVendedores[senha]) {
        alert("Senha inválida. Operação cancelada.");
        return;
    }
    const alertaRemovido = { ...alertasGlobaisAtivos[alertaID] };
    delete alertasGlobaisAtivos[alertaID];
    try {
        localStorage.setItem('alertas_globais_ativos', JSON.stringify(alertasGlobaisAtivos));
        console.log(`[resolverAlertaGlobalManualmente] Alerta resolvido por ${senhasVendedores[senha]}: ${alertaRemovido.produto} (Global ${alertaCode})`);
        alert(`Alerta global para "${alertaRemovido.produto}" resolvido!`);
        exibirAlertas();
        if (document.getElementById('pagina-alertas')?.classList.contains('active') && typeof window.exibirPainelDeAlertas === 'function') {
            window.exibirPainelDeAlertas();
        }
    } catch (e) {
        console.error("[resolverAlertaGlobalManualmente] Erro:", e);
        alertasGlobaisAtivos[alertaID] = alertaRemovido;
        alert("Erro ao salvar a resolução do alerta global.");
    }
}

// --- Exibição da Seção de Alertas na UI ---

function exibirAlertas() {
    const divAlertasContainer = document.getElementById("alertasEstoqueMinimo");
    if (!divAlertasContainer) {
        // console.warn("[exibirAlertas] Div 'alertasEstoqueMinimo' não encontrada."); // Comentado para reduzir spam no console
        return;
    }

    const alertasLocaisArray = Object.values(alertasLocaisAtivos || {});
    const alertasGlobaisArray = Object.values(alertasGlobaisAtivos || {});
    const lojaAtualFormatada = lojaAtual ? lojaAtual.replace(/^loja/i, 'Loja ').trim() : 'N/A';
    let html = '';

    html += `<div class="c-alert-block c-alert-block--local">
               <h3 class="c-alert-block__title">⚠️ Alertas de Estoque Local (Loja: ${lojaAtualFormatada})</h3>
               <p class="c-alert-block__description">Produtos na sua loja que estão abaixo do estoque mínimo definido.</p>`;
    if (alertasLocaisArray.length === 0) {
        html += '<p class="c-alert-block__empty-message">Nenhum alerta de estoque local ativo.</p>';
    } else {
        alertasLocaisArray.forEach(a => {
            const nomeLojaExibicao = a.loja.replace(/^loja/i, 'Loja ').trim();
            html += `<div class="c-alert-card">
                       <h4 class="c-alert-card__title">${a.produto}</h4>
                       <p class="c-alert-card__details">
                           <strong>Loja:</strong> ${nomeLojaExibicao} • 
                           <strong>Estoque:</strong> <span class="c-alert-card__stock-low">${a.estoqueAtual}</span> • 
                           <strong>Mín. Local:</strong> ${a.minimo}
                       </p>
                       <div class="c-alert-card__actions">
                           <button class="c-alert-card__btn c-alert-card__btn--resolver" data-action="resolver-local" data-alerta-id="${a.id}">
                               ✅ Resolver Local
                           </button>
                       </div>
                   </div>`;
        });
    }
    html += '</div>';

    html += `<div class="c-alert-block c-alert-block--global">
               <h3 class="c-alert-block__title">🌍 Alertas de Estoque Global</h3>
               <p class="c-alert-block__description">Produtos com estoque total baixo, considerando todas as lojas.</p>`;
    if (alertasGlobaisArray.length === 0) {
        html += '<p class="c-alert-block__empty-message">Nenhum alerta global ativo.</p>';
    } else {
        alertasGlobaisArray.sort((a, b) => a.produto.localeCompare(b.produto)).forEach(a => {
            html += `<div class="c-alert-card">
                       <h4 class="c-alert-card__title">${a.produto}</h4>
                       <p class="c-alert-card__details">
                           <strong>Total Global:</strong> <span class="c-alert-card__stock-low">${a.estoqueTotal}</span> • 
                           <strong>Mín. Global:</strong> ${a.minimoGlobal}
                       </p>
                       <div class="c-alert-card__actions">
                           <button class="c-alert-card__btn c-alert-card__btn--copiar" data-action="copiar-global" data-alerta-code="${a.code}">
                               📋 Copiar MSG
                           </button>
                           <button class="c-alert-card__btn c-alert-card__btn--resolver" data-action="resolver-global" data-alerta-code="${a.code}">
                               ✅ Resolver Global
                           </button>
                       </div>
                   </div>`;
        });
    }
    html += '</div>';
    divAlertasContainer.innerHTML = html;
}

function handleAlertasAction(event) {
    const targetButton = event.target.closest('button[data-action]'); // Garante que clicamos no botão ou em seu filho (ícone)
    if (!targetButton) return;

    const action = targetButton.dataset.action;
    const alertaId = targetButton.dataset.alertaId;
    const alertaCode = targetButton.dataset.alertaCode;

    if (action === 'resolver-local' && alertaId) {
        resolverAlertaLocalManualmente(alertaId);
    } else if (action === 'copiar-global' && alertaCode) {
        copiarMensagemAlertaGlobal(alertaCode);
    } else if (action === 'resolver-global' && alertaCode) {
        resolverAlertaGlobalManualmente(alertaCode);
    }
}

function sugerirLojaComMaisEstoque(alertaLocal, listaProdutosParaSugestao = todosOsProdutosCarregados) {
    if (!alertaLocal || !alertaLocal.produto || !alertaLocal.loja || !alertaLocal.code) {
        console.warn("[sugerirLojaComMaisEstoque] Dados do alerta local incompletos.");
        return null;
    }
    if (!Array.isArray(listaProdutosParaSugestao) || listaProdutosParaSugestao.length === 0) {
        console.warn("[sugerirLojaComMaisEstoque] Lista de produtos para sugestão vazia.");
        return null;
    }
    const descOrigemNorm = alertaLocal.produto.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
    const lojaOrigemId = alertaLocal.loja;
    const produtoCodeOrigem = alertaLocal.code;
    const alternativas = listaProdutosParaSugestao.filter(p => {
        if (!p.description || !p.code || !p.category?.description) return false;
        if (p.code !== produtoCodeOrigem) return false;
        const matchLoja = p.category.description.match(/loja\d+/i); // Adapte se necessário
        const lojaProdutoId = matchLoja ? matchLoja[0].toLowerCase() : null;
        return lojaProdutoId && lojaProdutoId !== lojaOrigemId.toLowerCase() && (p.current_stock ?? 0) > 0;
    });
    if (!alternativas.length) return null;
    const maisEstoque = alternativas.reduce((max, p) => (p.current_stock ?? 0) > (max.current_stock ?? 0) ? p : max, alternativas[0]);
    console.log(`[sugerirLojaComMaisEstoque] Sugestão para ${alertaLocal.produto}: ${maisEstoque.category.description} com ${maisEstoque.current_stock} unid.`);
    return maisEstoque;
}

// --- Ciclo de Atualização e Inicialização ---

async function cicloDeAtualizacaoDeAlertas() {
    const horaAtual = new Date().toLocaleTimeString();
    console.log(`[Ciclo de Atualização] Iniciando às ${horaAtual}...`);
    try {
        await carregarTodosProdutosParaAlertas();

        if (lojaAtual && todosOsProdutosCarregados.length > 0) {
            console.log(`[Ciclo de Atualização] Revalidando alertas locais para a loja: ${lojaAtual}`);
            const produtosDaLojaAtual = todosOsProdutosCarregados.filter(p => {
                 // === IMPORTANTE: Adapte a condição abaixo para sua estrutura de dados ===
                return p.category?.description?.toLowerCase().includes(lojaAtual.toLowerCase());
            });
            produtosDaLojaAtual.forEach(produtoDaLoja => {
                verificarEstoqueMinimoLocal(produtoDaLoja);
            });
        }
        exibirAlertas(); // Garante que a UI seja atualizada após todas as operações
        if (typeof window.atualizarContadorAlertasUI === 'function') {
            window.atualizarContadorAlertasUI();
        }
        console.log(`[Ciclo de Atualização] Concluído às ${new Date().toLocaleTimeString()}. Próxima em ${INTERVALO_ATUALIZACAO_ALERTAS_MS / 60000} min.`);
    } catch (error) {
        console.error("[Ciclo de Atualização] Erro:", error);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    console.log("[estoque-alertas.js] DOM carregado. Iniciando módulo de alertas...");
    const divAlertasContainer = document.getElementById("alertasEstoqueMinimo");
    if (divAlertasContainer) {
        divAlertasContainer.addEventListener('click', handleAlertasAction);
        console.log("[estoque-alertas.js] Event listener para ações de alerta configurado.");
    } else {
        console.warn("[estoque-alertas.js] Container de alertas 'alertasEstoqueMinimo' não encontrado.");
    }

    // Carregamento inicial e primeiro ciclo de atualização
    cicloDeAtualizacaoDeAlertas().then(() => {
        console.log("[estoque-alertas.js] Primeiro ciclo de atualização de alertas completo.");
        // Exibe alertas do localStorage imediatamente (já feito no ciclo, mas pode ser redundante se o ciclo for rápido)
        // exibirAlertas();
        // if (typeof window.atualizarContadorAlertasUI === 'function') {
        //     window.atualizarContadorAlertasUI();
        // }
    }).catch(error => {
        console.error("[estoque-alertas.js] Erro durante o primeiro ciclo de atualização:", error);
        // Mesmo com erro, tenta exibir o que está no localStorage
        exibirAlertas();
         if (typeof window.atualizarContadorAlertasUI === 'function') {
            window.atualizarContadorAlertasUI();
        }
    });

    setInterval(cicloDeAtualizacaoDeAlertas, INTERVALO_ATUALIZACAO_ALERTAS_MS);
    console.log(`[estoque-alertas.js] Atualização periódica configurada para cada ${INTERVALO_ATUALIZACAO_ALERTAS_MS / 60000} minutos.`);
});

window.estoqueAlertas = {
    verificarEstoqueMinimoLocal,
    verificarEstoqueMinimoGlobal,
    sugerirLojaComMaisEstoque,
    exibirAlertas,
    getAlertasLocaisAtivos: () => alertasLocaisAtivos,
    getAlertasGlobaisAtivos: () => alertasGlobaisAtivos,
    forcarAtualizacao: cicloDeAtualizacaoDeAlertas // Permite forçar uma atualização externamente
};

console.log("[estoque-alertas.js] Script carregado e funções de alerta expostas em window.estoqueAlertas.");