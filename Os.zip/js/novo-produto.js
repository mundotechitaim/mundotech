document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('novoProdutoForm');
    const codigoBarrasInput = document.getElementById('novoCodigoBarras');
    const descricaoInput = document.getElementById('novoDescricao');
    const precoInput = document.getElementById('novoPreco');
    const estoqueInput = document.getElementById('novoEstoque');
    const imagemBase64Textarea = document.getElementById('novoImagemBase64');
    const statusDiv = document.getElementById('statusNovoProduto');
    const previewImagem = document.getElementById('previewImagem');
    const inputUploadImagem = document.getElementById('uploadImagem');

    document.getElementById('buscarPorURL').addEventListener('click', async () => {
        const url = document.getElementById('urlProdutoExterno').value.trim();
        if (!url) return;
    
        const status = document.getElementById('statusNovoProduto');
        status.innerHTML = `<div class="alert alert-info">🔍 Buscando dados da URL...</div>`;
    
        try {
            const response = await fetch("https://mundotechip.com.br/api/microservico.php/extrair-dados-url", {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url })
            });
    
            const data = await response.json(); // ✅ Agora sim "response" existe
    
            if (data.titulo) document.getElementById('novoDescricao').value = data.titulo;
            if (data.imagem) {
                const base64 = await converterImagemParaBase64(data.imagem);
                document.getElementById('novoImagemBase64').value = base64;
                document.getElementById('previewImagem').src = base64;
                document.getElementById('previewImagem').style.display = 'block';
            }
    
            status.innerHTML = `<div class="alert alert-success">✅ Dados extraídos da URL com sucesso</div>`;
        } catch (e) {
            console.error(e);
            status.innerHTML = `<div class="alert alert-danger">Erro ao extrair dados da URL</div>`;
        }
    });


    // Atualizar preview quando colar a imagem Base64 manualmente
    imagemBase64Textarea.addEventListener('input', function () {
        const valor = imagemBase64Textarea.value.trim();
        if (valor.startsWith('data:image')) {
            previewImagem.src = valor;
            previewImagem.style.display = 'block';
        } else {
            previewImagem.src = '';
            previewImagem.style.display = 'none';
        }
    });

    // Upload + Redimensionar para Base64
    inputUploadImagem.addEventListener('change', function (event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function (e) {
            const img = new Image();
            img.src = e.target.result;

            img.onload = function () {
                const canvas = document.createElement('canvas');
                const maxSize = 800;
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > maxSize) {
                        height *= maxSize / width;
                        width = maxSize;
                    }
                } else {
                    if (height > maxSize) {
                        width *= maxSize / height;
                        height = maxSize;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                const base64 = canvas.toDataURL('image/png');

                imagemBase64Textarea.value = base64;
                previewImagem.src = base64;
                previewImagem.style.display = 'block';

                console.log('[Novo Produto] Imagem redimensionada e convertida para Base64.');
                alert('Imagem redimensionada e convertida para Base64!');
            };
        };
        reader.readAsDataURL(file);
    });

    // Busca automática ao sair do campo Código de Barras
    codigoBarrasInput.addEventListener('blur', async function () {
        const codigo = codigoBarrasInput.value.trim();
        if (codigo) {
            statusDiv.innerHTML = '<div class="alert alert-info">🔍 Buscando informações do produto...</div>';
            const resultado = await buscarProdutoPorCodigoBarras(codigo);
            if (resultado) {
                descricaoInput.value = resultado.titulo;
                if (resultado.imagemBase64) {
                    imagemBase64Textarea.value = resultado.imagemBase64;
                    previewImagem.src = resultado.imagemBase64;
                    previewImagem.style.display = 'block';
                    console.log('[Busca Produto] Imagem carregada e convertida.');
                }
                statusDiv.innerHTML = `<div class="alert alert-success">✅ Produto sugerido: ${resultado.titulo}</div>`;
            } else {
                statusDiv.innerHTML = `<div class="alert alert-warning">Nenhum resultado encontrado para o código informado.</div>`;
            }
        }
    });

    // Envio do formulário para criar produto
    form.addEventListener('submit', async function (e) {
        e.preventDefault();

        const descricao = descricaoInput.value.trim();
        const preco = parseFloat(precoInput.value.trim());
        const estoque = parseInt(estoqueInput.value.trim(), 10) || 0;
        const imagemBase64 = imagemBase64Textarea.value.trim();
        const codigoBarras = codigoBarrasInput.value.trim();

        if (!descricao || isNaN(preco)) {
            statusDiv.innerHTML = '<div class="alert alert-danger">Descrição e Preço são obrigatórios.</div>';
            return;
        }

        if (imagemBase64 && imagemBase64.length > 15000000) {
            statusDiv.innerHTML = `<div class="alert alert-warning">
                🚨 A imagem selecionada é muito grande (${(imagemBase64.length / 1024 / 1024).toFixed(2)} MB). 
                Por favor, selecione uma imagem menor que 15MB.
            </div>`;
            console.warn('[Novo Produto] Imagem Base64 muito grande, tamanho:', imagemBase64.length);
            return;
        }

        // ✅ Categoria fixa (Loja 1)
        const categoriaFixa = {
            uid: "DA1582E5-0249-4843-8BDE-C937313ADED1",
            shopcode: "2411349",
            description: "PeliculasLoja1",
            id: 33,
            subcategories: []
        };

        const payload = {
            uid: crypto.randomUUID(),
            shopcode: "2411349",
            combo: false,
            unit_price: 0,
            stock: estoque,
            stockmin: 5,
            active: true,
            profit_margin: 0,
            can_change_price: false,
            auto_price: false,
            price_promo: 0,
            prodtend: null,
            prodtbegin: null,
            published: false,
            promotional: false,
            fractional_sale: false,
            description: descricao,
            code: codigoBarras,
            'automatic-code': true,
            category: categoriaFixa, // ✅ FIXO no payload
            subcategory: null,
            brand: null,
            price: preco,
            cost_price: 0,
            stock_control: true,
            stockmax: 30,
            unit: null,
            combo_items: [],
            tax: null,
            no_tax: false,
            tax_use_global: false,
            default_markup: false,
            current_stock: estoque,
            commission_percentage: 0,
            commission_profit: false,
            commission_use_global: true,
            supplier_uid: '',
            suppliers: [],
            photos: [],
            image: null,
            base64_images: []
        };

        if (imagemBase64 && imagemBase64.startsWith('data:image')) {
            payload.base64_images.push({
                data_uri: imagemBase64,
                url: '',
                status: 0,
                md5: ''
            });
            console.log('[Novo Produto] Imagem incluída no payload.');
        } else {
            console.log('[Novo Produto] Nenhuma imagem fornecida.');
        }

        console.log('[Novo Produto] Payload final antes de enviar:', payload);

        try {
            statusDiv.innerHTML = '<div class="alert alert-info">Enviando dados para criar produto...</div>';
            const response = await fetchComToken(`https://api.web.nextar.com.br/api/v1/product/2411349`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });

            if (response.ok) {
                const rawText = await response.text();
                let data;
                try {
                    data = JSON.parse(rawText);
                } catch (e) {
                    data = rawText;
                }
                console.log('[Novo Produto] Produto criado com sucesso:', data);
                statusDiv.innerHTML = '<div class="alert alert-success">✅ Produto criado com sucesso!</div>';
                form.reset();
                imagemBase64Textarea.value = '';
                previewImagem.src = '';
                previewImagem.style.display = 'none';
            } else {
                const err = await response.text();
                console.error('[Novo Produto] Erro:', err);
                statusDiv.innerHTML = `<div class="alert alert-danger">Erro ao criar produto: ${err}</div>`;
            }
        } catch (err) {
            console.error('[Novo Produto] Falha:', err.message);
            statusDiv.innerHTML = `<div class="alert alert-danger">Erro inesperado: ${err.message}</div>`;
        }
    });
});

async function buscarProdutoPorCodigoBarras(codigoBarras) {
    const apiKey = 'AIzaSyAtARS832RNDU_ro7MiF2rLgmrc1gtqYMM';
    const cx = 'c5fac1003de364d92';
    const statusBusca = document.getElementById('statusNovoProduto');

    const termosDeBusca = [
        `${codigoBarras} produto`,
        `${codigoBarras} embalagem`,
        `${codigoBarras} site:mercadolivre.com.br`,
        `${codigoBarras} site:magazineluiza.com.br`,
        `${codigoBarras} site:buscape.com.br`
    ];

    for (const termo of termosDeBusca) {
        try {
            const url = `https://www.googleapis.com/customsearch/v1?key=${apiKey}&cx=${cx}&q=${encodeURIComponent(termo)}`;
            console.log('[Busca Produto] Consultando Google API com termo:', termo);

            const response = await fetch(url);
            if (!response.ok) throw new Error(`Erro HTTP ${response.status}`);
            const data = await response.json();

            if (data.items && data.items.length > 0) {
                for (const item of data.items) {
                    const titulo = item.title;
                    const descricao = item.snippet;
                    const imagens = item.pagemap?.cse_image || [];

                    let imagemURL = null;
                    for (const img of imagens) {
                        const src = img.src.toLowerCase();
                        if (!src.includes('logo') && !src.includes('icon') && !src.includes('placeholder')) {
                            imagemURL = img.src;
                            break;
                        }
                    }

                    if (imagemURL) {
                        const base64 = await converterImagemParaBase64(imagemURL);
                        if (base64) {
                            document.getElementById('novoDescricao').value = titulo;
                            document.getElementById('novoImagemBase64').value = base64;
                            const previewImagem = document.getElementById('previewImagem');
                            previewImagem.src = base64;
                            previewImagem.style.display = 'block';

                            statusBusca.innerHTML = `<div class="alert alert-success">✅ Produto sugerido: ${titulo} (imagem carregada)</div>`;
                            return { titulo, descricao, imagemBase64: base64 };
                        }
                    }
                }
            }
        } catch (error) {
            console.error(`[Busca Produto] Erro com termo "${termo}":`, error);
        }
    }

    statusBusca.innerHTML = `<div class="alert alert-warning">⚠️ Nenhuma imagem ou título útil encontrado para o código informado.</div>`;
    return null;
}


    async function buscarProdutoExistente(codigoBarras) {
        try {
            const url = `https://api.web.nextar.com.br/api/v1/product/${shopCode}?page=0&size=1&search=${encodeURIComponent(codigoBarras)}&filter=active`;
            const res = await fetchComToken(url);
            if (!res.ok) throw new Error(`Erro ${res.status}`);

            const dados = await res.json();
            const produto = dados.content?.[0];

            if (produto && produto.code === codigoBarras) {
                // Produto encontrado ➔ Atualiza os campos automaticamente
                document.getElementById('novoDescricao').value = produto.description;
                document.getElementById('novoPreco').value = produto.price ?? 0;
                document.getElementById('novoEstoque').value = produto.current_stock ?? 0;
                
                // Mostra preview da imagem (se tiver)
                if (produto.photos?.[0]?.url) {
                    document.getElementById('previewImagem').src = produto.photos[0].url;
                    document.getElementById('previewImagem').style.display = 'block';
                }

                // Atualiza status para o usuário
                document.getElementById('statusNovoProduto').innerHTML = `
                    <div class="alert alert-warning">
                        Este produto já existe. Atualize apenas o estoque para <strong>${produto.description}</strong>.
                        Estoque atual: ${produto.current_stock ?? 0}
                    </div>
                `;

                // Troca o comportamento do botão
                const form = document.getElementById('novoProdutoForm');
                form.dataset.produtoExistenteUid = produto.uid;  // Salva o UID no form para uso posterior
            } else {
                // Produto não encontrado ➔ mantém fluxo normal
                document.getElementById('statusNovoProduto').innerHTML = `<div class="alert alert-info">Produto novo. Preencha os dados.</div>`;
                document.getElementById('previewImagem').style.display = 'none';
                form.dataset.produtoExistenteUid = '';  // Limpa se antes estava preenchido
            }
        } catch (e) {
            console.error("Erro ao buscar produto existente:", e);
            document.getElementById('statusNovoProduto').innerHTML = `<div class="alert alert-danger">Erro ao buscar produto: ${e.message}</div>`;
        }
    }

    async function atualizarEstoqueExistente(uid, quantidadeAdicional) {
        try {
            // Busca produto atual
            const urlGet = `https://api.web.nextar.com.br/api/v1/product/${shopCode}/${uid}`;
            const resProduto = await fetchComToken(urlGet);
            if (!resProduto.ok) throw new Error(`Erro ${resProduto.status}`);
            const produto = await resProduto.json();
    
            // Atualiza estoque
            produto.current_stock = (produto.current_stock ?? 0) + quantidadeAdicional;
            produto.stock = produto.current_stock; // redundante, mas Nextar pede isso
    
            // Envia PUT
            const urlPut = `https://api.web.nextar.com.br/api/v1/product/${shopCode}`;
            const resUpdate = await fetchComToken(urlPut, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(produto)
            });
    
            if (resUpdate.ok) {
                document.getElementById('statusNovoProduto').innerHTML = `<div class="alert alert-success">Estoque atualizado com sucesso!</div>`;
            } else {
                const erroTxt = await resUpdate.text();
                throw new Error(`Erro ${resUpdate.status}: ${erroTxt}`);
            }
        } catch (e) {
            console.error("Erro ao atualizar estoque:", e);
            document.getElementById('statusNovoProduto').innerHTML = `<div class="alert alert-danger">Erro ao atualizar estoque: ${e.message}</div>`;
        }
    }
    


// Função para converter imagem URL em Base64
async function converterImagemParaBase64(url) {
    try {
        const response = await fetch("https://mundotechip.com.br/api/microservico.php/convert-base64", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url })
        });

        const data = await response.json(); // ✅ agora "response" está definido
        return data.base64 || null;
    } catch (err) {
        console.error('[Converter Imagem] Erro via servidor:', err);
        return null;
    }
}


function processarXML() {
    const input = document.getElementById('xmlUpload');
    const file = input.files[0];
    const listaContainer = document.getElementById('listaProdutosXML');
    const statusDiv = document.getElementById('statusNovoProduto');

    if (!file) {
        alert("Selecione um arquivo XML.");
        return;
    }

    const reader = new FileReader();
    reader.onload = async function (e) {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(e.target.result, "text/xml");
        const itens = xmlDoc.querySelectorAll("det");

        if (!itens.length) {
            statusDiv.innerHTML = '<div class="alert alert-danger">❌ Nenhum produto encontrado na NF.</div>';
            return;
        }

        listaContainer.innerHTML = ''; // limpa a lista

        itens.forEach((item, index) => {
            const prod = item.querySelector("prod");
            let descricao = prod.querySelector("xProd")?.textContent || "";
            const ean = prod.querySelector("cEAN")?.textContent || "SEM GTIN";
            const qtd = parseFloat(prod.querySelector("qCom")?.textContent || "1");
            descricao = descricao.replace(/Ean ?:?\s*\d{8,14}$/i, '').trim();

            const html = `
                <div class="card-produto-xml shadow-sm">
                    <h6 class="font-weight-bold mb-2">📦 Produto ${index + 1}</h6>
                    <p><strong>Descrição:</strong> ${descricao}</p>
                    <p><strong>EAN:</strong> ${ean}</p>
                    <p><strong>Qtd:</strong> ${qtd}</p>

                    <input type="number" class="form-control form-control-sm preco-manual mb-2"
                        data-desc="${descricao}" data-ean="${ean}" data-qtd="${qtd}"
                        placeholder="💰 Preço Unitário" step="0.01">

                    <input type="text" class="form-control form-control-sm input-url-manual mb-2"
                        placeholder="🌐 URL da Imagem">

                    <div class="btn-group btn-group-sm w-100 mb-2">
                        <button class="btn btn-outline-secondary" onclick="buscarImagemManualURL(this)">🌐 Buscar Imagem</button>
                        <button class="btn btn-outline-info" onclick="buscarImagemXML(this)">🔍 AutoImagem</button>
                    </div>

                    <button class="btn btn-success btn-sm w-100 btn-incluir-cadastro">✅ Incluir no Cadastro</button>

                    <img src="" class="img-preview mt-2" style="display:none; max-height: 80px; border-radius: 4px; margin: 0 auto;">
                </div>
            `;
            listaContainer.innerHTML += html;
        });

        // Após renderizar os cards, ativa o botão de "incluir no cadastro"
        setTimeout(() => {
            document.querySelectorAll('.btn-incluir-cadastro').forEach(btn => {
                btn.addEventListener('click', function () {
                    preencherFormParaCadastro(this);
                });
            });
        }, 100);

        statusDiv.innerHTML = `<div class="alert alert-success">✅ ${itens.length} produto(s) encontrados na NF.</div>`;
    };

    reader.readAsText(file);
}

async function buscarImagemXML(botao) {
    const card = botao.closest('.card-produto-xml');
    if (!card) return;

    const input = card.querySelector('input.preco-manual');
    const desc = input?.dataset?.desc || '';
    const ean = input?.dataset?.ean || '';

    const resultado = await buscarProdutoPorCodigoBarras(ean !== "SEM GTIN" ? ean : desc);
    const img = card.querySelector('.img-preview');

    if (resultado?.imagemBase64) {
        img.src = resultado.imagemBase64;
        img.dataset.base64 = resultado.imagemBase64;
        img.style.display = 'block';
    } else {
        img.style.display = 'none';
        alert("Nenhuma imagem encontrada.");
    }
}


function preencherFormParaCadastro(botao) {
    const card = botao.closest('.card-produto-xml');
    if (!card) return;

    const input = card.querySelector('input.preco-manual');
    const preco = parseFloat(input?.value);
    const ean = input?.dataset?.ean;
    const qtd = input?.dataset?.qtd;

    const descricaoNode = card.querySelector('p strong')?.nextSibling;
    const descricao = descricaoNode ? descricaoNode.textContent.trim() : input?.dataset?.desc;

    if (isNaN(preco) || preco <= 0) {
        alert("Digite um preço válido antes de incluir.");
        return;
    }

    document.getElementById('novoDescricao').value = descricao;
    document.getElementById('novoPreco').value = preco.toFixed(2);
    document.getElementById('novoEstoque').value = qtd;
    document.getElementById('novoCodigoBarras').value = (ean === "SEM GTIN") ? "" : ean;

    const imagem = card.querySelector('.img-preview');
    const preview = document.getElementById('previewImagem');
    const base64 = imagem?.dataset?.base64;

    if (base64) {
        document.getElementById('novoImagemBase64').value = base64;
        preview.src = base64;
        preview.style.display = 'block';
    } else {
        preview.src = '';
        preview.style.display = 'none';
    }

    document.getElementById('statusNovoProduto').innerHTML = `
        <div class="alert alert-info">
            📝 Produto transferido para cadastro. Agora clique em "Criar Produto".
        </div>`;
}

async function cadastrarTodosProdutosXML() {
    const cards = document.querySelectorAll('#listaProdutosXML .card-produto-xml');

    // ⚠️ Verifica produtos sem preço preenchido
    const semPreco = Array.from(cards).filter(card => {
        const preco = parseFloat(card.querySelector('input.preco-manual').value);
        return isNaN(preco) || preco <= 0;
    });
    if (semPreco.length > 0) {
        const continuar = confirm(`⚠️ Existem ${semPreco.length} produto(s) sem preço. Deseja continuar mesmo assim?`);
        if (!continuar) return;
    }
    
    const statusDiv = document.getElementById('statusNovoProduto');
    let cadastrados = 0;
    let erros = 0;

    for (const card of cards) {
        const input = card.querySelector('input.preco-manual');
        const descricao = input.dataset.desc;
        const ean = input.dataset.ean;
        const qtd = parseFloat(input.dataset.qtd);
        const preco = parseFloat(input.value);

        if (isNaN(preco) || preco <= 0) {
            erros++;
            console.warn(`⚠️ Produto ignorado (sem preço): ${descricao}`);
            continue;
        }

        const imagem = card.querySelector('.img-preview');
        const imagemBase64 = imagem?.dataset.base64 || "";

        const payload = {
            uid: crypto.randomUUID(),
            shopcode: "2411349",
            combo: false,
            unit_price: 0,
            stock: qtd,
            stockmin: 5,
            active: true,
            profit_margin: 0,
            can_change_price: false,
            auto_price: false,
            price_promo: 0,
            prodtend: null,
            prodtbegin: null,
            published: false,
            promotional: false,
            fractional_sale: false,
            description: descricao,
            code: (ean === "SEM GTIN") ? "" : ean,  // ✅ agora o código de barras será salvo corretamente
            'automatic-code': true,
            category: {
                uid: "DA1582E5-0249-4843-8BDE-C937313ADED1",
                shopcode: "2411349",
                description: "PeliculasLoja1",
                id: 33,
                subcategories: []
            },
            subcategory: null,
            brand: null,
            price: preco,
            cost_price: 0,
            stock_control: true,
            stockmax: 30,
            unit: null,
            combo_items: [],
            tax: null,
            no_tax: false,
            tax_use_global: false,
            default_markup: false,
            current_stock: qtd,
            commission_percentage: 0,
            commission_profit: false,
            commission_use_global: true,
            supplier_uid: '',
            suppliers: [],
            photos: [],
            image: null,
            base64_images: []
        };

        if (imagemBase64 && imagemBase64.startsWith('data:image')) {
            payload.base64_images.push({
                data_uri: imagemBase64,
                url: '',
                status: 0,
                md5: ''
            });
        }

        try {
            const res = await fetchComToken(`https://api.web.nextar.com.br/api/v1/product/2411349`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (res.ok) {
                cadastrados++;
                console.log(`✅ Produto cadastrado: ${descricao}`);
            } else {
                erros++;
                const msg = await res.text();
                console.error(`❌ Erro ao cadastrar ${descricao}:`, msg);
            }
        } catch (err) {
            erros++;
            console.error(`❌ Erro inesperado ao cadastrar ${descricao}:`, err);
        }
    }

    statusDiv.innerHTML = `<div class="alert alert-${erros ? 'warning' : 'success'}">
        ✅ ${cadastrados} produto(s) cadastrados com sucesso. ${erros ? `❗ ${erros} com erro (sem preço ou falha na API)` : ''}
    </div>`;
}

async function buscarImagensParaTodos() {
    const cards = document.querySelectorAll('#listaProdutosXML .card-produto-xml');
    let carregadas = 0;
    let falhas = 0;

    for (const card of cards) {
        const input = card.querySelector('input.preco-manual');
        const desc = input?.dataset?.desc || '';
        const ean = input?.dataset?.ean || '';
        const img = card.querySelector('.img-preview');

        const resultado = await buscarProdutoPorCodigoBarras(ean !== "SEM GTIN" ? ean : desc);

        if (resultado?.imagemBase64) {
            img.src = resultado.imagemBase64;
            img.dataset.base64 = resultado.imagemBase64;
            img.style.display = 'block';
            carregadas++;
        } else {
            img.style.display = 'none';
            falhas++;
        }
    }

    document.getElementById('statusNovoProduto').innerHTML = `
        <div class="alert alert-info">
            🔍 Imagens carregadas: ${carregadas} | Falhas: ${falhas}
        </div>
    `;
}

async function buscarImagemManualURL(botao) {
    const card = botao.closest('.card-produto-xml');
    if (!card) return;

    const inputURL = card.querySelector('.input-url-manual');
    const url = inputURL?.value?.trim();
    const img = card.querySelector('.img-preview');

    if (!url) {
        alert("Por favor, cole uma URL da imagem.");
        return;
    }

    try {
        const base64 = await converterImagemParaBase64(url);
        if (base64) {
            img.src = base64;
            img.dataset.base64 = base64;
            img.style.display = 'block';
        } else {
            alert("❌ Falha ao converter imagem. Verifique a URL.");
        }
    } catch (err) {
        console.error("Erro ao buscar imagem manual:", err);
        alert("❌ Erro ao buscar imagem da URL.");
    }
}


window.preencherFormParaCadastro = preencherFormParaCadastro;