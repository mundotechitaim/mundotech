const cliCepInput = document.getElementById("cliCep");
const cepLoadingSpan = document.getElementById("cepLoading");

if (cliCepInput && cepLoadingSpan) {
    cliCepInput.addEventListener("blur", async () => {
        const cep = cliCepInput.value.replace(/\D/g, '');
        if (cep.length !== 8) {
            return;
        }
        cepLoadingSpan.style.display = 'inline-block';
        // Limpa/Indica carregamento
        document.getElementById("cliRua").value = "...";
        document.getElementById("cliBairro").value = "...";
        document.getElementById("cliCidade").value = "...";
        document.getElementById("cliEstado").value = "...";

        try {
            const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
            const data = await response.json();

            if (!data.erro) {
                document.getElementById("cliRua").value = data.logradouro || '';
                document.getElementById("cliBairro").value = data.bairro || '';
                document.getElementById("cliCidade").value = data.localidade || '';
                document.getElementById("cliEstado").value = data.uf || '';
                document.getElementById("cliNumero").focus(); // Foca no número após preencher
            } else {
                console.warn("CEP não encontrado");
                // Limpa campos se CEP não for encontrado
                document.getElementById("cliRua").value = '';
                document.getElementById("cliBairro").value = '';
                document.getElementById("cliCidade").value = '';
                document.getElementById("cliEstado").value = '';
            }
        } catch (e) {
             console.error("Erro ao buscar CEP:", e);
             // Limpa campos em caso de erro na requisição
             document.getElementById("cliRua").value = '';
             document.getElementById("cliBairro").value = '';
             document.getElementById("cliCidade").value = '';
             document.getElementById("cliEstado").value = '';
        } finally {
            cepLoadingSpan.style.display = 'none'; // Esconde o spinner
        }
    });
}