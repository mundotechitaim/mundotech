document.addEventListener('DOMContentLoaded', () => {
    // --- Seletores de Elementos do DOM ---
    const loadReportButton = document.getElementById('loadReport');
    const reportResultContainer = document.getElementById('reportResult');
    const dateBeginInput = document.getElementById('datebegin');
    const dateEndInput = document.getElementById('dateend');

    // --- Constantes e Configurações ---
    const COR_PRIMARIA_RELATORIO = "#007bff"; // Azul padrão Bootstrap, pode ser seu #FF6600
    const COR_SECUNDARIA_RELATORIO = "#6c757d"; // Cinza para botões secundários

    // --- CSS Embutido ---
    const estiloCssRelatorio = `
        .report-table-actions button {
            margin-right: 5px;
            transition: all 0.2s ease-in-out;
        }
        .report-table-actions button:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .report-table-actions .btn-print-thermal {
            background-color: ${COR_SECUNDARIA_RELATORIO};
            border-color: ${COR_SECUNDARIA_RELATORIO};
            color: white;
        }
        .report-table-actions .btn-print-thermal:hover {
            background-color: color-mix(in srgb, ${COR_SECUNDARIA_RELATORIO} 90%, black);
            border-color: color-mix(in srgb, ${COR_SECUNDARIA_RELATORIO} 90%, black);
        }
        .report-table-actions .btn-print-receipt {
            background-color: ${COR_PRIMARIA_RELATORIO};
            border-color: ${COR_PRIMARIA_RELATORIO};
            color: white;
        }
         .report-table-actions .btn-print-receipt:hover {
            background-color: color-mix(in srgb, ${COR_PRIMARIA_RELATORIO} 90%, black);
            border-color: color-mix(in srgb, ${COR_PRIMARIA_RELATORIO} 90%, black);
        }
        .loading-spinner-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.7);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1060; /* Acima do modal, se houver */
            flex-direction: column;
            gap: 15px;
        }
        .spinner-border-lg { /* Classe para um spinner maior */
            width: 3rem;
            height: 3rem;
            border-width: .3em;
        }
        .print-thermal-styles { /* Estilos para a janela de impressão térmica */
            width: 58mm;
            margin: 0;
            padding: 5mm 2mm; /* Adiciona um pequeno padding */
            font-family: 'Courier New', Courier, monospace; /* Fonte monoespaçada comum */
            font-size: 9pt; /* Tamanho de fonte típico para recibos */
            line-height: 1.3;
            text-align: left; /* Alinhamento à esquerda é mais comum para itens */
            background-color: #fff; /* Garante fundo branco */
            color: #000; /* Garante texto preto */
        }
        .print-thermal-styles hr {
            border: none;
            border-top: 1px dashed #000; /* Linha tracejada */
            margin: 5px 0;
        }
        .print-thermal-styles .text-center { text-align: center; }
        .print-thermal-styles .text-bold { font-weight: bold; }
        .print-thermal-styles .item-line { display: flex; justify-content: space-between; }
        .print-thermal-styles .item-line span:first-child { max-width: 70%; word-break: break-word; } /* Nome do produto */
        .print-thermal-styles .item-line span:last-child { white-space: nowrap; } /* Preço */
        .print-thermal-styles h3 { font-size: 12pt; margin: 5px 0; text-align:center; }
        .print-thermal-styles p { margin: 2px 0; }
    `;
    const styleSheet = document.createElement("style");
    styleSheet.type = "text/css";
    styleSheet.innerText = estiloCssRelatorio;
    document.head.appendChild(styleSheet);


    // --- Verificação de Elementos Essenciais ---
    if (!loadReportButton || !reportResultContainer || !dateBeginInput || !dateEndInput) {
        console.error("Relatório: Elementos essenciais do DOM não foram encontrados.");
        if (reportResultContainer) {
            reportResultContainer.innerHTML = '<div class="alert alert-danger">Erro de configuração da página. Contacte o suporte.</div>';
        }
        return;
    }

    // --- Adição de Event Listeners ---
    loadReportButton.addEventListener('click', handleLoadReport);

    reportResultContainer.addEventListener('click', (event) => {
        const target = event.target.closest('button'); // Procura o botão mais próximo
        if (!target) return;

        const action = target.getAttribute('data-action');
        const saleDataJson = target.getAttribute('data-sale');

        if (saleDataJson) {
            try {
                const saleData = JSON.parse(saleDataJson);
                if (action === 'print-receipt') {
                    handleImprimirCanhoto(saleData);
                } else if (action === 'print-thermal') {
                    handleImprimirReciboTermico(saleData);
                }
            } catch (e) {
                console.error("Relatório: Erro ao processar dados da venda para ação:", e);
                alert("Erro ao processar dados da venda.");
            }
        }
    });

    // --- Funções de Lógica Principal ---
    async function handleLoadReport() {
        const dateBeginValue = dateBeginInput.value;
        const dateEndValue = dateEndInput.value;

        if (!dateBeginValue || !dateEndValue) {
            showAlert(reportResultContainer, 'Por favor, selecione as datas de início e fim.', 'warning');
            return;
        }

        const dateBegin = new Date(dateBeginValue + 'T00:00:00-03:00');
        const dateEnd = new Date(dateEndValue + 'T23:59:59-03:00');

        if (dateEnd < dateBegin) {
            showAlert(reportResultContainer, 'A data final não pode ser anterior à data inicial.', 'warning');
            return;
        }

        showLoadingState(true);

        try {
            if (typeof shopCode === 'undefined' || typeof fetchComToken === 'undefined') {
                throw new Error("Variáveis globais `shopCode` ou `fetchComToken` não definidas.");
            }
            const allSalesData = await fetchAllSalePages(dateBegin.toISOString(), dateEnd.toISOString());
            renderReport(allSalesData);
        } catch (error) {
            console.error('Relatório: Erro ao buscar:', error);
            showAlert(reportResultContainer, `Erro ao buscar relatório: ${error.message}`, 'danger');
        } finally {
            showLoadingState(false);
        }
    }

    async function fetchAllSalePages(isoDateBegin, isoDateEnd) {
        let currentPage = 0;
        const pageSize = 100;
        let allSalesContent = [];
        let reportTotals = { totalQty: 0, totalValue: 0 };

        const requestBody = {
            search: "", datebegin: isoDateBegin, dateend: isoDateEnd,
            payment: [], origin: [], transaction: []
        };

        const initialUrl = `https://api.web.nextar.com.br/api/v1/sale/${shopCode}/historic?page=${currentPage}&size=${pageSize}&sort=date&direction=desc&ts=${Date.now()}`;
        const initialResponse = await fetchComToken(initialUrl, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestBody)
        });

        if (!initialResponse.ok) {
            const errorText = await initialResponse.text();
            throw new Error(`Falha na API (página inicial ${initialResponse.status}): ${errorText}`);
        }

        const initialData = await initialResponse.json();
        if (initialData.sales && initialData.sales.content) {
            allSalesContent.push(...initialData.sales.content);
        }
        reportTotals.totalQty = initialData.totalQty || 0;
        reportTotals.totalValue = initialData.totalValue || 0;

        const totalPages = initialData.sales ? initialData.sales.totalPages : 0;

        if (totalPages > 1) {
            const promises = [];
            for (currentPage = 1; currentPage < totalPages; currentPage++) {
                const url = `https://api.web.nextar.com.br/api/v1/sale/${shopCode}/historic?page=${currentPage}&size=${pageSize}&sort=date&direction=desc&ts=${Date.now()}`;
                promises.push(
                    fetchComToken(url, {
                        method: 'POST', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(requestBody)
                    }).then(async response => {
                        if (!response.ok) {
                            console.warn(`Erro ao buscar página ${currentPage}. Status: ${response.status}`);
                            return null; // Retorna null para falhas, para não quebrar Promise.all
                        }
                        return response.json();
                    })
                );
            }
            const results = await Promise.all(promises);
            results.forEach(pageData => {
                if (pageData && pageData.sales && pageData.sales.content) {
                    allSalesContent.push(...pageData.sales.content);
                }
            });
        }
        return { sales: { content: allSalesContent }, totalQty: reportTotals.totalQty, totalValue: reportTotals.totalValue };
    }

    function renderReport(data) {
        if (!data.sales || !data.sales.content || data.sales.content.length === 0) {
            showAlert(reportResultContainer, 'Nenhuma venda encontrada no período selecionado.', 'info');
            return;
        }

        let html = `<table class="table table-striped table-hover table-responsive-md">
            <thead class="thead-dark">
                <tr>
                    <th>Data</th><th>Vendedor</th><th>Valor</th><th>Pagamento</th><th>Produtos</th><th>Ações</th>
                </tr>
            </thead>
            <tbody>`;

        data.sales.content.forEach(sale => {
            const saleDate = new Date(sale.date);
            const formattedDate = `${saleDate.toLocaleDateString('pt-BR')} ${saleDate.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
            
            let vendedor = sale.seller?.name || 'N/A';
            if ((!vendedor || vendedor === 'N/A') && sale.obs) {
                const match = sale.obs.match(/vendedor:\s*([^-\n]+)/i);
                vendedor = (match && match[1]) ? match[1].trim() : sale.obs.substring(0, 30);
            }

            const valor = `R$ ${sale.final_value.toFixed(2)}`;
            const pagamento = sale.payments?.map(p => p.description).join(', ') || 'N/A';
            const produtos = sale.products?.map(p => `${p.qty}x ${p.description || 'Produto s/ descrição'}`).join('<br>') || 'Nenhum produto';

            const saleDataForButton = {
                code: sale.code || sale.uid,
                date: formattedDate,
                vendedor: vendedor,
                valorTotal: sale.final_value, // Valor numérico para cálculos no recibo
                valorFormatado: valor, // String formatada para exibição
                pagamento: pagamento,
                produtos: sale.products?.map(p => ({ 
                    qty: p.qty, 
                    description: p.description || 'Produto s/ descrição', 
                    price: p.price, // Preço unitário original
                    totalItem: (p.price * p.qty) // Subtotal do item
                })) || []
            };
            const saleDataString = JSON.stringify(saleDataForButton).replace(/'/g, "&apos;");

            html += `<tr>
                <td>${formattedDate}</td>
                <td>${vendedor}</td>
                <td>${valor}</td>
                <td>${pagamento}</td>
                <td><small>${produtos}</small></td>
                <td class="report-table-actions">
                    <button class="btn btn-sm btn-print-receipt" data-action="print-receipt" data-sale='${saleDataString}' title="Imprimir 2ª Via (Canhoto)">
                        <i class="fas fa-receipt"></i> Canhoto
                    </button>
                    <button class="btn btn-sm btn-print-thermal" data-action="print-thermal" data-sale='${saleDataString}' title="Imprimir Recibo Térmico">
                        <i class="fas fa-print"></i> Térmico
                    </button>
                </td>
            </tr>`;
        });

        html += `</tbody></table>
        <div class="alert alert-success mt-3">
            <strong>Total de Vendas (itens):</strong> ${data.totalQty} <br>
            <strong>Valor Total das Vendas:</strong> R$ ${data.totalValue.toFixed(2)}
        </div>`;
        reportResultContainer.innerHTML = html;
    }

    // --- Funções Auxiliares de UI ---
    function showAlert(container, message, type = 'info') {
        container.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    }

    function showLoadingState(isLoading) {
        loadReportButton.disabled = isLoading;
        let overlay = document.getElementById('loadingOverlay');
        if (isLoading) {
            if (!overlay) {
                overlay = document.createElement('div');
                overlay.id = 'loadingOverlay';
                overlay.className = 'loading-spinner-overlay';
                overlay.innerHTML = `
                    <div class="spinner-border spinner-border-lg text-primary" role="status">
                        <span class="sr-only">Carregando...</span>
                    </div>
                    <p class="mt-2 h5">Carregando Relatório...</p>
                `;
                document.body.appendChild(overlay);
            }
            overlay.style.display = 'flex';
        } else {
            if (overlay) {
                overlay.style.display = 'none';
            }
        }
    }

    // --- Funções de Impressão Adaptadas ---
    function handleImprimirCanhoto(saleData) {
        console.log("Relatório: Imprimindo Canhoto para:", saleData);
        // Formata a lista de produtos para a string esperada por imprimirCanhoto
        const produtosString = saleData.produtos.map(p => `${p.qty}x ${p.description}`).join(', '); // Ou \n se preferir

        imprimirCanhoto( // Chama a sua função original
            saleData.code,
            saleData.date,
            saleData.vendedor,
            saleData.valorFormatado, // Já está como "R$ XX.XX"
            saleData.pagamento,
            produtosString
        );
    }
    
    // Sua função imprimirCanhoto original (mantida para referência)
    function imprimirCanhoto(codigo, data, vendedor, valor, pagamento, produtos) {
        const janela = window.open('', 'PRINT_CANHOTO', 'height=600,width=800');
        janela.document.write('<html><head><title>2ª Via de Canhoto</title>');
        janela.document.write('<style>body { font-family: Arial, sans-serif; margin: 20px; } h2 {color: #333;} p { margin-bottom: 8px; } strong {color: #555;}</style>');
        janela.document.write('</head><body>');
        janela.document.write(`<h2>2ª Via de Canhoto</h2>`);
        janela.document.write(`<p><strong>Código da Venda:</strong> ${codigo}</p>`);
        janela.document.write(`<p><strong>Data:</strong> ${data}</p>`);
        janela.document.write(`<p><strong>Vendedor:</strong> ${vendedor}</p>`);
        janela.document.write(`<p><strong>Valor Total:</strong> ${valor}</p>`);
        janela.document.write(`<p><strong>Forma de Pagamento:</strong> ${pagamento}</p>`);
        janela.document.write(`<p><strong>Produtos:</strong><br>${produtos.replace(/\n/g, '<br>')}</p>`); // Se produtosString usar \n
        janela.document.write(`<hr><p style="text-align:center;">Obrigado pela compra!</p>`);
        janela.document.write('</body></html>');
        janela.document.close();
        janela.focus();
        setTimeout(() => { // Adiciona um pequeno delay para garantir que o conteúdo foi renderizado
            janela.print();
            janela.close();
        }, 250);
    }


    function handleImprimirReciboTermico(saleData) {
        console.log("Relatório: Imprimindo Recibo Térmico para:", saleData);
        const textoRecibo = gerarTextoReciboTermicoAdaptado(saleData);
        imprimirTextoTermico(textoRecibo); // Nova função para apenas imprimir o texto
    }

    function gerarTextoReciboTermicoAdaptado(saleData) {
        const linhas = [];
        const empresa = "MUNDO TECH"; // Pode vir de uma config global
        const razao = "MUNDO TECH COMERCIO E\nSERVIÇOS LTDA - ME";
        const cnpj = "CNPJ: 24.596.084/0001-36";
        const endereco = "R Severino Batista de\nMenezes, 10";
        const local = "Jd Aimore - São Paulo - SP";
        const cep = "CEP: 08110-410";
        const separador = "-".repeat(30); // Ajuste o tamanho conforme a impressora

        linhas.push(empresa.padStart( (30 + empresa.length) / 2 )); // Centraliza
        linhas.push(razao); // Já tem quebra de linha
        linhas.push(cnpj);
        linhas.push(endereco);
        linhas.push(local);
        linhas.push(cep);
        linhas.push(separador);
        linhas.push(`Data: ${saleData.date}`);
        linhas.push(`Vendedor: ${saleData.vendedor}`);
        linhas.push(`Pagamento: ${saleData.pagamento}`);
        linhas.push(separador);
        linhas.push("Itens:");
        
        saleData.produtos.forEach(item => {
            const nomeItem = `${item.qty}x ${item.description}`;
            const precoItem = `R$${(item.totalItem || (item.price * item.qty)).toFixed(2)}`;
            // Alinhamento simples: nome à esquerda, preço à direita
            const espacos = Math.max(1, 30 - nomeItem.length - precoItem.length);
            linhas.push(`${nomeItem}${' '.repeat(espacos)}${precoItem}`);
        });

        linhas.push(separador);
        linhas.push(`TOTAL:${' '.repeat(Math.max(1, 30 - 6 - saleData.valorFormatado.length))}${saleData.valorFormatado}`);
        linhas.push(separador);
        linhas.push("Obrigado pela preferência!".padStart( (30 + "Obrigado pela preferência!".length) / 2 ));
        linhas.push(" "); // Linha em branco para corte

        return linhas.join("\n");
    }

    function imprimirTextoTermico(texto) {
        const janela = window.open('', '_blank', 'width=300,height=500'); // Tamanho pequeno para simular
        janela.document.write('<html><head><title>Recibo Térmico</title>');
        // Os estilos da classe .print-thermal-styles serão aplicados aqui
        janela.document.write('<style>');
        janela.document.write(`
            body, pre {
                width: 58mm; /* Largura da bobina */
                margin: 0;
                padding: 2mm; /* Pequena margem interna */
                font-family: 'Courier New', Courier, monospace; /* Fonte monoespaçada */
                font-size: 9pt; /* Tamanho de fonte comum para recibos */
                line-height: 1.3;
                background-color: #fff;
                color: #000;
                word-break: break-all; /* Quebra palavras longas */
            }
            pre {
                white-space: pre-wrap; /* Mantém quebras de linha e espaços do texto */
            }
            /* Estilos específicos para impressão podem ir em @media print */
            @media print {
                body, pre {
                    margin: 0; padding: 0; /* Remove margens/padding para impressão */
                    font-size: 8pt; /* Pode ajustar para impressão */
                }
                @page {
                    margin: 2mm; /* Margem da página na impressão */
                    size: 58mm auto; /* Define o tamanho do papel */
                }
            }
        `);
        janela.document.write('</style></head><body>');
        janela.document.write(`<pre>${texto}</pre>`); // Usa <pre> para manter a formatação do texto
        janela.document.write('</body></html>');
        janela.document.close();
        janela.focus();
        setTimeout(() => { // Delay para renderização
            janela.print();
            janela.close();
        }, 300);
    }

});