/**
 * js/ordem-servico.js
 * Gerencia OS em 2 etapas (Cliente -> Detalhes OS + Serviços).
 * Valida senha do funcionário LOCALMENTE (INSEGURO! Senhas visíveis no código fonte).
 * Redireciona para impressão após sucesso.
 */
document.addEventListener("DOMContentLoaded", () => {

    // --- Configuração Global ---
    const API_BASE_URL = "https://www.mundotechip.com.br/index.php/api";
    // Tenta obter de uma variável global (definida em config.js ou app-loja3.js)
    const lojaAtual = window.lojaAtual || 'loja3';
    const lojaTexto = lojaAtual.replace('loja', 'Loja ');
    // ATENÇÃO: Obter ID do usuário logado de forma segura!
    const usuarioLogadoId = window.usuarioLogadoId || 1; // Exemplo, ajuste conforme seu sistema

    // --- Variáveis de Estado ---
    let clienteConfirmadoId = null;
    let clienteConfirmadoNome = null;
    let osServicosAdicionados = []; // Array para guardar { id, nome, qtd, precoUnit, totalParcial }
    let servicoSelecionado = null; // Guarda o último serviço selecionado no autocomplete { id, nome, preco }
    let debounceTimer = null; // Para autocomplete
    let isBuscandoCliente = false;
    let isSalvandoCliente = false;
    let isSalvandoOS = false;
    let nomeFuncionarioLogado = null;

    // --- Elementos do DOM ---
    // (Referências aos elementos como definidas anteriormente)
    const loginInfoBox = document.getElementById("loginInfoBox");
    const cadastroClienteDiv = document.getElementById("cadastroCliente");
    const cliCpfInput = document.getElementById("cliCpf");
    const cliNomeInput = document.getElementById("cliNome");
    const cliCelularInput = document.getElementById("cliCelular");
    const cliTelefoneInput = document.getElementById("cliTelefone");
    const cliCepInput = document.getElementById("cliCep");
    const cliRuaInput = document.getElementById("cliRua");
    const cliNumeroInput = document.getElementById("cliNumero");
    const cliComplementoInput = document.getElementById("cliComplemento");
    const cliBairroInput = document.getElementById("cliBairro");
    const cliCidadeInput = document.getElementById("cliCidade");
    const cliEstadoInput = document.getElementById("cliEstado");
    const statusCadastroClienteDiv = document.getElementById("statusCadastroCliente");
    const btnConfirmarClienteIniciarOS = document.getElementById("btnConfirmarClienteIniciarOS");
    const clienteLoadingSpinner = document.getElementById("clienteLoadingSpinner");
    const formOSDiv = document.getElementById("formOSWrapper");
    const imei1OSInput = document.getElementById('imei1OS');
    const imei2OSInput = document.getElementById('imei2OS');
    const osNomeClienteInput = document.getElementById("osNomeCliente");
    const descricaoProdutoInput = document.getElementById('descricaoProduto');
    const defeitoProdutoInput = document.getElementById('defeitoProduto');
    const observacoesOSInput = document.getElementById('observacoesOS');
    const laudoTecnicoOSInput = document.getElementById('laudoTecnicoOS');
    const statusOSInput = document.getElementById('statusOS');
    const dataInicialInput = document.getElementById('dataInicial');
    const dataFinalInput = document.getElementById('dataFinal');
    const garantiaOSInput = document.getElementById('garantiaOS');
    const termoGarantiaInput = document.getElementById('termoGarantia');
    const osServicoInput = document.getElementById('osServicoInput');
    const osServicoSugestoesDiv = document.getElementById('osServicoSugestoes');
    const osServicoSelecionadoIdInput = document.getElementById('osServicoSelecionadoId');
    const osServicoQtdInput = document.getElementById('osServicoQtd');
    const osServicoPrecoInput = document.getElementById('osServicoPreco');
    const btnAddServico = document.getElementById('btnAddServico');
    const osServicosTableBody = document.querySelector('#osServicosTable tbody');
    const osServicosSubtotalEl = document.getElementById('osServicosSubtotal');
    const osTotalGeralEl = document.getElementById('osTotalGeral');
    const statusSalvarOSDiv = document.getElementById('statusSalvarOS');
    const btnSalvarOS = document.getElementById("salvarOS");
    const btnCancelarOS = document.getElementById("cancelarOS");
    const osLoadingSpinner = document.getElementById("osLoadingSpinner");

    // --- Funções Auxiliares ---
    function formatCurrency(value) {
        if (isNaN(value)) value = 0;
        return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    }
    function toggleSpinner(spinnerElement, show) {
        if (spinnerElement) spinnerElement.style.display = show ? 'inline-block' : 'none';
    }
    function setElementsDisabled(elements, disabled) {
         elements.forEach(el => { if(el) el.disabled = disabled; });
    }
    function updateStatus(element, message, type) {
        if (!element) return; element.innerHTML = message; // Usa innerHTML para ícones/spinners
        const baseClasses = element.id.includes('SalvarOS') || element.id.includes('CadastroCliente') ? 'mt-3 text-center font-weight-bold' : 'login-info-box alert';
        let typeClass = element.id === 'loginInfoBox' ? `alert-${type}` : `text-${type}`;
        element.className = `${baseClasses} ${typeClass}`;
        if (element.id === 'loginInfoBox') element.style.display = message ? 'block' : 'none';
        else { element.style.display = 'block'; if (!message) element.innerHTML = '&nbsp;'; }
    }

    function preencherFormularioCliente(cliente) {
        if (!cliente) cliente = {};
        if (cliNomeInput) cliNomeInput.value = cliente.nomeCliente || '';
        if (cliCelularInput) cliCelularInput.value = cliente.celular || '';
        if (cliCepInput) cliCepInput.value = cliente.cep || '';
        if (cliRuaInput) cliRuaInput.value = cliente.rua || '';
        if (cliNumeroInput) cliNumeroInput.value = cliente.numero || '';
        if (cliComplementoInput) cliComplementoInput.value = cliente.complemento || '';
        if (cliBairroInput) cliBairroInput.value = cliente.bairro || '';
        if (cliCidadeInput) cliCidadeInput.value = cliente.cidade || '';
        if (cliEstadoInput) cliEstadoInput.value = cliente.estado || '';
        if (cliTelefoneInput) cliTelefoneInput.value = cliente.telefone || '';
    }


    function coletarDadosCliente() {
        const nome = cliNomeInput?.value.trim();
        const cpf = cliCpfInput?.value.trim().replace(/\D/g, '');
        const celular = cliCelularInput?.value.trim();
        const telefone = cliTelefoneInput?.value.trim();  // ← AQUI

        if (!nome || !cpf || cpf.length !== 11 || !celular) {
            updateStatus(statusCadastroClienteDiv, "❌ Preencha Nome, CPF (11 dígitos) e Celular.", "danger");
            return null;
        }

        return {
            nomeCliente: nome,
            documento: cpf,
            celular: celular,
            telefone: telefone,  // ← AQUI
            cep: cliCepInput?.value.trim() || '',
            rua: cliRuaInput?.value.trim() || '',
            numero: cliNumeroInput?.value.trim() || '',
            complemento: cliComplementoInput?.value.trim() || '',
            bairro: cliBairroInput?.value.trim() || '',
            cidade: cliCidadeInput?.value.trim() || '',
            estado: cliEstadoInput?.value.trim() || ''
        };
    }

     /** Limpa e define valores padrão para o formulário OS (Etapa 2), incluindo funcionário */
    function resetarFormularioOS(funcionarioNome = null) {
        const hojeFormatado = getDataLocalFormatadaBR(); // usa fuso correto

        if(osNomeClienteInput) osNomeClienteInput.value = '';
        if(descricaoProdutoInput) { descricaoProdutoInput.value = ''; descricaoProdutoInput.classList.remove('is-invalid'); }
        if(defeitoProdutoInput) { defeitoProdutoInput.value = ''; defeitoProdutoInput.classList.remove('is-invalid'); }
        if(observacoesOSInput) observacoesOSInput.value = '';
        if(laudoTecnicoOSInput) laudoTecnicoOSInput.value = '';
        if(imei1OSInput) imei1OSInput.value = '';
        if(imei2OSInput) imei2OSInput.value = '';
        if(statusOSInput) { statusOSInput.value = 'Em Andamento'; statusOSInput.classList.remove('is-invalid');}
        if(dataInicialInput) { dataInicialInput.value = hojeFormatado; dataInicialInput.classList.remove('is-invalid');}
        if(dataFinalInput) dataFinalInput.value = hojeFormatado;
        if(garantiaOSInput) garantiaOSInput.value = '90 dias';
        if(termoGarantiaInput) termoGarantiaInput.value = 'Serviço Prestado';
        if(osServicoInput) osServicoInput.value = '';
        if(osServicoSelecionadoIdInput) osServicoSelecionadoIdInput.value = '';
        if(osServicoQtdInput) osServicoQtdInput.value = '1';
        if(osServicoPrecoInput) osServicoPrecoInput.value = '';
        if(osServicoSugestoesDiv) osServicoSugestoesDiv.innerHTML = '';
        servicoSelecionado = null;
    }

    function getDataLocalFormatadaBR() {
        const agora = new Date();
        const fusoBrasil = new Date(agora.getTime() - (agora.getTimezoneOffset() * 60000));
        const dia = String(fusoBrasil.getDate()).padStart(2, '0');
        const mes = String(fusoBrasil.getMonth() + 1).padStart(2, '0');
        const ano = fusoBrasil.getFullYear();
        return `${dia}/${mes}/${ano}`;
    }



    /** Reseta o fluxo completo para o estado inicial (Etapa 1) */
    function resetarFluxo() {
        console.log("Resetando fluxo para Etapa 1...");
        clienteConfirmadoId = null; clienteConfirmadoNome = null; osServicosAdicionados = []; servicoSelecionado = null;
        isBuscandoCliente = false; isSalvandoCliente = false; isSalvandoOS = false;
        if(cliCpfInput) cliCpfInput.value = ''; preencherFormularioCliente(null);
        if(statusCadastroClienteDiv) updateStatus(statusCadastroClienteDiv, '', 'info');
        if(statusSalvarOSDiv) updateStatus(statusSalvarOSDiv, '', 'info');
        resetarFormularioOS(); renderServicosTable(); calcularTotais(); // Reseta form OS e serviços
        if(cadastroClienteDiv) cadastroClienteDiv.style.display = 'block'; if(formOSDiv) formOSDiv.style.display = 'none';
        const allClientInputs = [ cliCpfInput, cliNomeInput, cliCelularInput, cliCepInput, cliRuaInput, cliNumeroInput, cliComplementoInput, cliBairroInput, cliCidadeInput, cliEstadoInput ];
        setElementsDisabled([btnConfirmarClienteIniciarOS, ...allClientInputs], false);
        toggleSpinner(clienteLoadingSpinner, false); toggleSpinner(osLoadingSpinner, false);
        if(cliCpfInput) cliCpfInput.focus();
    }

    // --- Funções de API (exceto validação de senha que foi removida) ---
    async function tentarLoginAutomatico() {
        // AVISO: Credenciais hardcoded - INSEGURO!
        const credenciaisPorLoja = { loja1:{email:"mundotech1@gmail.com",senha:"S@s@1414"}, loja2:{email:"mundotech2@gmail.com",senha:"S@s@1414"}, loja3:{email:"mundotech3@gmail.com",senha:"S@s@1414"} };
        const credenciais = credenciaisPorLoja[lojaAtual]; if (!credenciais) { updateStatus(loginInfoBox, `❌ Config login ${lojaTexto}.`, "danger"); return; }
        updateStatus(loginInfoBox, `⏳ Login ${lojaTexto}...`, "info"); try { const res = await fetch(`${API_BASE_URL}/login`, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ email: credenciais.email, senha: credenciais.senha }) }); const dados = await res.json(); if (dados.success) { updateStatus(loginInfoBox, `✅ Login OK (${lojaTexto}).`, "success"); } else { updateStatus(loginInfoBox, `❌ Falha login: ${dados.message || 'Verifique API.'}`, "danger"); } } catch (error) { console.error("[LOGIN AUTOMÁTICO] Erro:", error); updateStatus(loginInfoBox, `❌ Erro login. Verifique conexão/API.`, "danger"); }
    }

    async function buscarClientePorCPF(cpf) {
        if (isBuscandoCliente) return null; 
        if (!cpf || cpf.length !== 11) return null; 
        isBuscandoCliente = true;
        setElementsDisabled([btnConfirmarClienteIniciarOS, cliCpfInput], true);
        updateStatus(statusCadastroClienteDiv, "⏳ Buscando CPF...", "info");

        let clienteEncontrado = null;

        try {
            const res = await fetch(`${API_BASE_URL}/clientes/buscar?documento=${cpf}`);
            const cliente = await res.json();
            console.log('[DEBUG buscarClientePorCPF]', cliente);  // <===== ADICIONE ESTA LINHA

            if (!res.ok) {
                throw new Error(`Erro ${res.status}`);
            }

            if (cliente && cliente.id) {
                clienteEncontrado = cliente;
            }
        } catch (error) {
            console.error("Erro buscar CPF:", error);
            updateStatus(statusCadastroClienteDiv, `❌ Erro ao buscar CPF.`, "danger");
        } finally {
            isBuscandoCliente = false;
            setElementsDisabled([btnConfirmarClienteIniciarOS, cliCpfInput], false);
            if (clienteEncontrado) {
                preencherFormularioCliente(clienteEncontrado);
                clienteConfirmadoId = clienteEncontrado.id;
                clienteConfirmadoNome = clienteEncontrado.nomeCliente;
                updateStatus(statusCadastroClienteDiv, `✅ Cliente ${clienteEncontrado.nomeCliente.split(' ')[0]} encontrado!`, "success");
                if(formOSDiv) formOSDiv.style.display = 'none';
                if(cadastroClienteDiv) cadastroClienteDiv.style.display = 'block';
            } else {
                clienteConfirmadoId = null;
                clienteConfirmadoNome = null;
                if(cliRuaInput) cliRuaInput.value = '';
                if(cliNumeroInput) cliNumeroInput.value = '';
                if(cliComplementoInput) cliComplementoInput.value = '';
                if(cliBairroInput) cliBairroInput.value = '';
                if(cliCidadeInput) cliCidadeInput.value = '';
                if(cliEstadoInput) cliEstadoInput.value = '';
                if(cliCepInput) cliCepInput.value = '';
                updateStatus(statusCadastroClienteDiv, "ℹ️ Cliente não encontrado. Preencha para cadastrar.", "info");
                if(formOSDiv) formOSDiv.style.display = 'none';
                if(cadastroClienteDiv) cadastroClienteDiv.style.display = 'block';
            }
        }
        return clienteEncontrado;
    }

    async function cadastrarNovoCliente(clienteData) {
        if (isSalvandoCliente || !clienteData) return null;
        isSalvandoCliente = true;
        setElementsDisabled([btnConfirmarClienteIniciarOS], true);
        toggleSpinner(clienteLoadingSpinner, true);
        updateStatus(statusCadastroClienteDiv, "⏳ Cadastrando...", "info");

        let resultado = null;

        try {
            const res = await fetch(`${API_BASE_URL}/clientes`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(clienteData)
            });
            const dados = await res.json();
            console.log('[DEBUG cadastrarNovoCliente]', dados);  // <===== ADICIONE ESTA LINHA

            if (dados.success && dados.id) {
                resultado = dados;
            } else {
                updateStatus(statusCadastroClienteDiv, `❌ Erro cadastro: ${dados.message || "Falha."}`, "danger");
            }
        } catch (error) {
            console.error("Erro conexão cadastro:", error);
            updateStatus(statusCadastroClienteDiv, "❌ Erro conexão cadastro.", "danger");
        } finally {
            isSalvandoCliente = false;
            setElementsDisabled([btnConfirmarClienteIniciarOS], false);
            toggleSpinner(clienteLoadingSpinner, false);
        }

        return resultado;
    }

    async function salvarOuAtualizarCliente(clienteData) {
    if (!clienteData) return;

    // Se tiver ID, é atualização
    if (clienteConfirmadoId) {
        clienteData.id = clienteConfirmadoId;
    }

    const url = clienteConfirmadoId
        ? `${API_BASE_URL}/clientes/atualizar`  // Rota que você criou no backend
        : `${API_BASE_URL}/clientes`;          // Cadastro novo cliente

    try {
        const res = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(clienteData),
        });

        const dados = await res.json();
        console.log('[DEBUG salvarOuAtualizarCliente]', dados);

        if (dados.success) {
            updateStatus(
                statusCadastroClienteDiv,
                clienteConfirmadoId
                    ? "✅ Cliente atualizado com sucesso!"
                    : "✅ Cliente cadastrado com sucesso!",
                "success"
            );
            if (!clienteConfirmadoId) {
                clienteConfirmadoId = dados.id;
            }
        } else {
            updateStatus(statusCadastroClienteDiv, `❌ Erro: ${dados.message || "Falha no cadastro/atualização."}`, "danger");
        }
    } catch (error) {
        console.error("Erro conexão salvarOuAtualizarCliente:", error);
        updateStatus(statusCadastroClienteDiv, "❌ Erro de conexão.", "danger");
    }
}


    /** Busca serviços na API para autocomplete */
    async function buscarServicosAPI(termo) {
        if (!termo || termo.length < 2) { if(osServicoSugestoesDiv) { osServicoSugestoesDiv.innerHTML = ''; osServicoSugestoesDiv.style.display = 'none';} return; }
        console.log("Buscando serviço:", termo);
        try {
            // ** NECESSÁRIO ENDPOINT NO BACKEND: GET /api/servicos/buscar?termo=... **
            const response = await fetch(`${API_BASE_URL}/servicos/buscar?termo=${encodeURIComponent(termo)}`);
            if (!response.ok) throw new Error('Falha ao buscar serviços');
            const servicos = await response.json();
            if(!osServicoSugestoesDiv) return;
            osServicoSugestoesDiv.innerHTML = '';
            if (servicos && servicos.length > 0) {
                servicos.forEach(servico => {
                    const div = document.createElement('div'); const preco = parseFloat(servico.preco || 0);
                    div.innerHTML = `${servico.nome} - ${formatCurrency(preco)}`;
                    div.dataset.id = servico.idServicos || servico.id; div.dataset.nome = servico.nome; div.dataset.preco = preco;
                    div.addEventListener('click', () => { selecionarServico({ id: div.dataset.id, nome: div.dataset.nome, preco: parseFloat(div.dataset.preco) }); });
                    osServicoSugestoesDiv.appendChild(div);
                });
                osServicoSugestoesDiv.style.display = 'block';
            } else {
                osServicoSugestoesDiv.innerHTML = '<div>Nenhum serviço encontrado.</div>'; osServicoSugestoesDiv.style.display = 'block';
            }
        } catch (error) {
            console.error("Erro ao buscar serviços:", error);
            if(osServicoSugestoesDiv) { osServicoSugestoesDiv.innerHTML = '<div class="text-danger">Erro ao buscar.</div>'; osServicoSugestoesDiv.style.display = 'block'; }
        }
    }

    /** Salva a Ordem de Serviço com os detalhes e serviços */
    async function salvarOrdemServico() {
        if (isSalvandoOS || !clienteConfirmadoId) {
            updateStatus(statusSalvarOSDiv, "❌ Erro interno: ID do cliente não confirmado.", "danger");
            return;
        }

        const descricao = descricaoProdutoInput?.value.trim();
        const defeito = defeitoProdutoInput?.value.trim();
        const statusOS = statusOSInput?.value;
        const dataInicioTexto = dataInicialInput?.value;

        let dataInicioAPI = null;
        if (dataInicioTexto) {
            const p = dataInicioTexto.split('/');
            if (p.length === 3) dataInicioAPI = `${p[2]}-${p[1]}-${p[0]}`;
        }

        let dataFinalAPI = null;
        const dataFinalTexto = dataFinalInput?.value;
        if (dataFinalTexto) {
            const p = dataFinalTexto.split('/');
            if (p.length === 3) dataFinalAPI = `${p[2]}-${p[1]}-${p[0]}`;
        }

        if (!descricao || !defeito || !statusOS || !dataInicioAPI) {
            updateStatus(statusSalvarOSDiv, "❌ Preencha os campos obrigatórios (*) da OS.", "danger");
            return;
        }

        [descricaoProdutoInput, defeitoProdutoInput].forEach(input => input?.classList.remove('is-invalid'));

        const totalFinal = calcularTotais();

        const osPayload = {
            clientes_id: clienteConfirmadoId,
            usuarios_id: usuarioLogadoId,
            descricaoProduto: descricao,
            defeito: defeito,
            observacoes: observacoesOSInput?.value.trim() || '',
            laudoTecnico: laudoTecnicoOSInput?.value.trim() || '',
            imei1: imei1OSInput?.value.trim() || '',
            imei2: imei2OSInput?.value.trim() || '',
            status: statusOS,
            dataInicial: dataInicioAPI,
            dataFinal: dataFinalAPI,
            garantia: parseInt(garantiaOSInput?.value.replace(/\D/g, '') || 0),
            valorTotal: totalFinal.toFixed(2),
            atendente_nome: nomeFuncionarioLogado,
            servicos: osServicosAdicionados.map(s => ({
                servico_id: s.id,
                quantidade: s.qtd,
                valor: s.precoUnit.toFixed(2)
            }))
        };

        console.log("Payload para salvar OS:", osPayload);

        isSalvandoOS = true;
        setElementsDisabled([btnSalvarOS, btnCancelarOS, btnAddServico, osServicoInput, osServicoQtdInput, osServicoPrecoInput], true);
        toggleSpinner(osLoadingSpinner, true);
        updateStatus(statusSalvarOSDiv, "⏳ Salvando OS...", "info");

        try {
            const res = await fetch(`${API_BASE_URL}/os`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(osPayload)
            });

            const resultado = await res.json();
            console.log("🔄 Resposta da API (Salvar OS):", resultado);

            if (resultado && resultado.success && resultado.idOs) {
                const osId = resultado.idOs;

                // 🔄 Atualiza lista automaticamente (Vue)
                const vueInstanciaListaOS = document.querySelector("#lista-os-app")?.__vue__;
                if (vueInstanciaListaOS && typeof vueInstanciaListaOS.carregarOrdens === 'function') {
                    vueInstanciaListaOS.carregarOrdens(); // ✅ nome certo do método
                } else if (vueInstanciaListaOS) {
                    vueInstanciaListaOS.$forceUpdate(); // fallback visual
                }

                // ✅ Busca HTML da OS para imprimir
                const resPrint = await fetch(`${API_BASE_URL}/os/imprimir-os/${osId}`);
                const respostaPrint = await resPrint.json();

                if (respostaPrint?.success && respostaPrint?.html) {
                    const novaJanela = window.open('', '_blank');
                    novaJanela.document.write(respostaPrint.html);
                    novaJanela.document.close();
                } else {
                    alert(`OS salva, mas erro ao carregar impressão. Acesse manualmente: /os/imprimir-os/${osId}`);
                }

                updateStatus(statusSalvarOSDiv, `✅ OS N° ${osId} salva com sucesso!`, "success");
                resetarFluxo();
            } else {
                throw new Error(resultado?.message || 'Falha ao salvar OS.');
            }
        } catch (error) {
            console.error("Erro ao salvar OS:", error);
            const errorMessage = error instanceof Error ? error.message : "Erro desconhecido.";
            updateStatus(statusSalvarOSDiv, `❌ Erro ao salvar OS: ${errorMessage}`, "danger");
            setElementsDisabled([btnSalvarOS, btnCancelarOS, btnAddServico, osServicoInput, osServicoQtdInput, osServicoPrecoInput], false);
        } finally {
            isSalvandoOS = false;
            toggleSpinner(osLoadingSpinner, false);
        }
    }


    // --- Funções de UI para Serviços ---
    function selecionarServico(servico) { console.log("Selecionado:", servico); servicoSelecionado = servico; if(osServicoInput) osServicoInput.value = servicoSelecionado.nome; if(osServicoSelecionadoIdInput) osServicoSelecionadoIdInput.value = servicoSelecionado.id; if(osServicoPrecoInput) osServicoPrecoInput.value = servicoSelecionado.preco.toFixed(2); if(osServicoSugestoesDiv) osServicoSugestoesDiv.style.display = 'none'; if(osServicoQtdInput) { osServicoQtdInput.value = '1'; osServicoQtdInput.focus(); } }
    function adicionarServico() { if (!servicoSelecionado || !servicoSelecionado.id) { updateStatus(statusSalvarOSDiv, "Selecione um serviço.", "warning"); return; } const qtd = parseInt(osServicoQtdInput?.value || 1); const precoUnit = parseFloat(osServicoPrecoInput?.value || servicoSelecionado.preco); if (isNaN(qtd) || qtd <= 0 || isNaN(precoUnit) || precoUnit < 0) { updateStatus(statusSalvarOSDiv, "Qtd/Preço inválidos.", "warning"); return; } osServicosAdicionados.push({ id: servicoSelecionado.id, nome: servicoSelecionado.nome, qtd: qtd, precoUnit: precoUnit, totalParcial: qtd * precoUnit }); renderServicosTable(); calcularTotais(); servicoSelecionado = null; if(osServicoInput) osServicoInput.value = ''; if(osServicoSelecionadoIdInput) osServicoSelecionadoIdInput.value = ''; if(osServicoQtdInput) osServicoQtdInput.value = '1'; if(osServicoPrecoInput) osServicoPrecoInput.value = ''; if(osServicoInput) osServicoInput.focus(); updateStatus(statusSalvarOSDiv, '', 'info'); }
    function removerServico(index) { if (index >= 0 && index < osServicosAdicionados.length) { osServicosAdicionados.splice(index, 1); renderServicosTable(); calcularTotais(); } }
    function renderServicosTable() { if (!osServicosTableBody) return; osServicosTableBody.innerHTML = ''; if (osServicosAdicionados.length === 0) { osServicosTableBody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">Nenhum serviço adicionado.</td></tr>'; return; } osServicosAdicionados.forEach((item, index) => { const row = osServicosTableBody.insertRow(); row.innerHTML = `<td>${item.nome}</td> <td>${item.qtd}</td> <td>${formatCurrency(item.precoUnit)}</td> <td>${formatCurrency(item.totalParcial)}</td> <td><button type="button" class="btn btn-danger btn-remove-item" data-index="${index}" title="Remover"><i class="fas fa-trash-alt"></i></button></td>`; row.querySelector('.btn-remove-item').addEventListener('click', (e) => { removerServico(parseInt(e.currentTarget.dataset.index)); }); }); }
    function calcularTotais() { let subtotal = osServicosAdicionados.reduce((sum, item) => sum + item.totalParcial, 0); const totalGeral = subtotal; if (osServicosSubtotalEl) osServicosSubtotalEl.textContent = formatCurrency(subtotal); if (osTotalGeralEl) osTotalGeralEl.textContent = formatCurrency(totalGeral); return totalGeral; }

    /** Prepara e exibe o formulário para detalhes da OS (Etapa 2) */
    function iniciarFormularioOS(funcionarioNome) { // Recebe nome validado
        if (!clienteConfirmadoId || !clienteConfirmadoNome) { updateStatus(statusCadastroClienteDiv, "❌ Cliente não confirmado.", "danger"); return; }
        if (!funcionarioNome) { updateStatus(statusCadastroClienteDiv, "❌ Funcionário não validado.", "danger"); return;} // Verifica se o nome veio

        if(cadastroClienteDiv) cadastroClienteDiv.style.display = 'none';
        resetarFormularioOS(funcionarioNome); // Passa nome para resetar/preencher
        osServicosAdicionados = []; renderServicosTable(); calcularTotais(); // Reseta serviços
        if(osNomeClienteInput) osNomeClienteInput.value = clienteConfirmadoNome;
        nomeFuncionarioLogado = funcionarioNome;
        if(formOSDiv) formOSDiv.style.display = 'block';
        updateStatus(statusCadastroClienteDiv, '', 'info'); updateStatus(statusSalvarOSDiv, '', 'info');
        setElementsDisabled([btnSalvarOS, btnCancelarOS, btnAddServico, osServicoInput, osServicoQtdInput, osServicoPrecoInput], false);
        if(descricaoProdutoInput) descricaoProdutoInput.focus();

        // ⚠️ Garante que a lista de OS apareça
        const vueInstanciaListaOS = document.querySelector("#lista-os-app")?.__vue__;
        if (vueInstanciaListaOS) {
            vueInstanciaListaOS.mostrarListaOS = true;
        }
    }

    // --- Event Listeners ---
    // 1. Busca cliente por CPF
    if (cliCpfInput) { cliCpfInput.addEventListener("blur", async () => { if(!clienteConfirmadoId) { await buscarClientePorCPF(cliCpfInput.value.trim().replace(/\D/g, '')); } }); } else { console.warn("#cliCpf não encontrado."); }

    // 2. Confirma Cliente / Cadastra Novo -> VALIDA SENHA LOCALMENTE -> Inicia OS
    if (btnConfirmarClienteIniciarOS) {
        btnConfirmarClienteIniciarOS.addEventListener("click", async () => {
            if (isSalvandoCliente || isBuscandoCliente) return;

            setElementsDisabled([btnConfirmarClienteIniciarOS], true);
            toggleSpinner(clienteLoadingSpinner, true);
            updateStatus(statusCadastroClienteDiv, "Verificando cliente...", "info");

            const clienteData = coletarDadosCliente();
            if (clienteData) {
                // Aqui chamamos a nova função única
                await salvarOuAtualizarCliente(clienteData);

                clienteConfirmadoNome = clienteData.nomeCliente;

                // Etapa de Validação da Senha
                const senha = prompt("Digite a senha do funcionário para continuar:");
                if (senha === null) {
                    updateStatus(statusCadastroClienteDiv, "Operação cancelada.", "warning");
                    setElementsDisabled([btnConfirmarClienteIniciarOS], false);
                    toggleSpinner(clienteLoadingSpinner, false);
                    return;
                }

                if (typeof senhasVendedores !== 'undefined' && senhasVendedores[senha]) {
                    const nomeFuncionarioValidado = senhasVendedores[senha];
                    updateStatus(statusCadastroClienteDiv, `✅ Senha OK (${nomeFuncionarioValidado})`, "success");
                    console.log("Senha validada localmente para:", nomeFuncionarioValidado);
                    iniciarFormularioOS(nomeFuncionarioValidado);
                } else {
                    updateStatus(statusCadastroClienteDiv, "❌ Senha inválida!", "danger");
                    console.warn("Senha inválida ou objeto senhasVendedores não encontrado/acessível.");
                }
            }

            setElementsDisabled([btnConfirmarClienteIniciarOS], false);
            toggleSpinner(clienteLoadingSpinner, false);
        });
    } else {
        console.warn("#btnConfirmarClienteIniciarOS não encontrado.");
    }


    // 3. Autocomplete de Serviços
    if (osServicoInput && osServicoSugestoesDiv) { osServicoInput.addEventListener('input', () => { clearTimeout(debounceTimer); const termo = osServicoInput.value; if (!termo) { osServicoSugestoesDiv.innerHTML = ''; osServicoSugestoesDiv.style.display = 'none'; servicoSelecionado = null; if(osServicoSelecionadoIdInput) osServicoSelecionadoIdInput.value = ''; if(osServicoPrecoInput) osServicoPrecoInput.value = ''; return; } debounceTimer = setTimeout(() => { buscarServicosAPI(termo); }, 300); }); document.addEventListener('click', (e) => { if (!osServicoInput.contains(e.target) && !osServicoSugestoesDiv.contains(e.target)) { osServicoSugestoesDiv.style.display = 'none'; } }); } else { console.warn("Elementos autocomplete serviço não encontrados."); }

    // 4. Adicionar Serviço à Lista
    if (btnAddServico) { btnAddServico.addEventListener('click', adicionarServico); } else { console.warn("#btnAddServico não encontrado."); }

    // 5. Salva a Ordem de Serviço (Etapa 2)
    if (btnSalvarOS) { btnSalvarOS.addEventListener("click", salvarOrdemServico); } else { console.warn("#salvarOS não encontrado."); }

    // 6. Cancela a OS (Etapa 2) e volta para Etapa 1
    if (btnCancelarOS) { btnCancelarOS.addEventListener("click", resetarFluxo); } else { console.warn("#cancelarOS não encontrado."); }

    // --- Inicialização ---
    function init() { tentarLoginAutomatico(); resetarFluxo(); console.log(`Módulo OS (${lojaTexto}) inicializado com Validação Local.`); }
    const paginaOrdemDiv = document.getElementById("pagina-ordem"); let activeCheckInterval = setInterval(() => { if (paginaOrdemDiv && (paginaOrdemDiv.classList.contains('active') || getComputedStyle(paginaOrdemDiv).display !== 'none')) { clearInterval(activeCheckInterval); init(); } }, 300); window.addEventListener('beforeunload', () => clearInterval(activeCheckInterval));

}); // Fim do DOMContentLoaded