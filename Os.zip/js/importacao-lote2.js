console.log("[Importação Lote] Script carregado.");

// Configuração da senha mestre
const SENHA_MESTRE_IMPORTACAO = "S@s@1602";

// Criação e inserção do modal na página (caso ainda não esteja no HTML)
(function criarModalImportacaoLote() {
    const modalHtml = `
    <div id="modalImportacaoLote" class="modal-importacao-lote-overlay" style="display: none;">
        <div class="modal-importacao-lote-content">
            <span class="modal-importacao-lote-close" id="fecharModalImportacao">&times;</span>
            <h2>📦 Importação em Lote</h2>
            <div class="modal-importacao-lote-upload">
                <label for="arquivoImportacao">1️⃣ Upload do Arquivo</label>
                <input type="file" id="arquivoImportacao" accept=".xlsx, .xls" />
                <button id="validarArquivoBtn">Validar Arquivo</button>
            </div>

            <div id="previewImportacao" style="margin-top: 20px; display: none;">
                <h4>🔎 Prévia da Importação</h4>
                <div id="tabelaPreviewContainer" class="modal-importacao-lote-preview"></div>
                <button id="importarAgoraBtn" style="margin-top: 10px; display: none;">🚀 Importar Agora</button>
            </div>

            <div class="modal-importacao-lote-historico" style="margin-top:20px;">
                <h4>📜 Histórico de Importações</h4>
                <table id="historicoImportacoes" class="modal-importacao-lote-table">
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Usuário</th>
                            <th>Qtd. Itens</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td colspan="4" style="text-align:center;">Nenhuma importação ainda.</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <style>
    /* Modal Overlay */
    .modal-importacao-lote-overlay {
        position: fixed;
        z-index: 900;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.5);
    }

    /* Modal Content */
    .modal-importacao-lote-content {
        background: #fff;
        margin: 3% auto;
        padding: 20px;
        width: 95%;
        max-width: 1400px;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0,0,0,0.3);
    }

    .modal-importacao-lote-close {
        float: right;
        font-size: 26px;
        cursor: pointer;
        color: #333;
    }
    .modal-importacao-lote-close:hover {
        color: #000;
    }

    .modal-importacao-lote-upload {
        margin-bottom: 20px;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 6px;
        background: #f9f9f9;
    }

    .modal-importacao-lote-preview {
        overflow-x: auto;
        max-height: 500px;
        overflow-y: auto;
        border: 1px solid #ddd;
        border-radius: 6px;
    }

    .modal-importacao-lote-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 1200px;
    }

    .modal-importacao-lote-table th,
    .modal-importacao-lote-table td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: center;
        font-size: 13px;
        vertical-align: top;
        word-break: break-word;
    }

    .modal-importacao-lote-table th {
        background: #f2f2f2;
        position: sticky;
        top: 0;
        z-index: 1;
    }

    .modal-importacao-lote-table input {
        width: 100%;
        box-sizing: border-box;
        padding: 6px;
        font-size: 13px;
    }

    button {
        margin-top: 10px;
        padding: 10px 15px;
        border: none;
        background: #007bff;
        color: white;
        border-radius: 4px;
        cursor: pointer;
        transition: background 0.3s;
    }

    button:hover {
        background: #0056b3;
    }

    .linha-invalida {
        background-color: #ffe0e0;
    }
    </style>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHtml);
})();

// Seletores
const modalImportacao = document.getElementById("modalImportacaoLote");
const btnFecharModalImportacao = document.getElementById("fecharModalImportacao");

// Função para abrir modal com verificação de senha
function abrirModalImportacaoLote() {
    Swal.fire({
        title: 'Acesso Restrito',
        text: 'Digite a senha mestre para continuar:',
        input: 'password',
        inputPlaceholder: 'Senha...',
        confirmButtonText: 'Entrar',
        showCancelButton: true,
        cancelButtonText: 'Cancelar',
        inputAttributes: {
            autocapitalize: 'off',
            autocorrect: 'off'
        },
        preConfirm: (senha) => {
            if (senha !== SENHA_MESTRE_IMPORTACAO) {
                Swal.showValidationMessage('Senha incorreta!');
            }
            return senha;
        }
    }).then((result) => {
        if (result.isConfirmed && result.value === SENHA_MESTRE_IMPORTACAO) {
            console.log("[Importação Lote] Senha correta. Modal liberado.");
            if (modalImportacao) {
                modalImportacao.style.display = 'block';
            }
        } else {
            console.log("[Importação Lote] Acesso negado ou cancelado.");
        }
    });
}

// Fecha modal
function fecharModalImportacao() {
    if (modalImportacao) modalImportacao.style.display = 'none';
}

// Atalho: Ctrl + Alt + G
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.altKey && e.key.toLowerCase() === 'g') {
        e.preventDefault();
        console.log("[Hotkey] Abrindo modal de importação em lote...");
        abrirModalImportacaoLote();
    }
});

// Fecha modal no clique do X
if (btnFecharModalImportacao) {
    btnFecharModalImportacao.addEventListener('click', fecharModalImportacao);
}

// Evento para validar arquivo e exibir prévia
document.addEventListener('click', function(e) {
    if (e.target && e.target.id === "validarArquivoBtn") {
        const inputArquivo = document.getElementById("arquivoImportacao");
        if (!inputArquivo.files.length) {
            Swal.fire('Erro', 'Selecione um arquivo antes de validar.', 'warning');
            return;
        }

        const arquivo = inputArquivo.files[0];
        const reader = new FileReader();

        reader.onload = function(event) {
            try {
                const data = new Uint8Array(event.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const primeiraAba = workbook.Sheets[workbook.SheetNames[0]];
                const jsonData = XLSX.utils.sheet_to_json(primeiraAba, { defval: '' });

                console.log("[Importação Lote] Prévia dos dados:", jsonData);

                if (!jsonData.length) {
                    Swal.fire('Erro', 'A planilha está vazia.', 'error');
                    return;
                }

                renderPreviewTable(jsonData);

            } catch (error) {
                console.error("[Importação Lote] Erro ao ler o arquivo:", error);
                Swal.fire('Erro', 'Falha ao processar o arquivo.', 'error');
            }
        };

        reader.readAsArrayBuffer(arquivo);
    }
});

// Renderizar prévia dos dados editáveis
function renderPreviewTable(dados) {
    const container = document.getElementById("tabelaPreviewContainer");
    const previewSection = document.getElementById("previewImportacao");
    const btnImportar = document.getElementById("importarAgoraBtn");

    container.innerHTML = '';
    previewSection.style.display = 'block';

    const tabela = document.createElement("table");
    tabela.className = "modal-importacao-lote-table";

    const colunas = ["Nome", "Código", "Preço", "Estoque Atual", "Categoria", "Sub Categoria"];
    const thead = document.createElement("thead");
    const trHead = document.createElement("tr");
    colunas.forEach(col => {
        const th = document.createElement("th");
        th.textContent = col;
        trHead.appendChild(th);
    });
    thead.appendChild(trHead);
    tabela.appendChild(thead);

    const tbody = document.createElement("tbody");

    dados.forEach((linha, index) => {
        const tr = document.createElement("tr");
        colunas.forEach(col => {
            const td = document.createElement("td");
            const input = document.createElement("input");
            input.dataset.rowIndex = index;
            input.dataset.coluna = col;

            let valor = linha[col] || "";

            if (col === "Preço" || col === "Estoque Atual") {
                input.type = "number";
                input.step = "any";
                input.min = 0;
            } else {
                input.type = "text";
            }
            input.value = valor;

            td.appendChild(input);
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });

    tabela.appendChild(tbody);
    container.appendChild(tabela);

    btnImportar.style.display = 'inline-block';
}

// Expor função globalmente (opcional)
window.abrirModalImportacaoLote = abrirModalImportacaoLote;

// Evento para enviar os dados editados para a API (com criação ou atualização)
document.addEventListener('click', async function(e) {
    if (e.target && e.target.id === "importarAgoraBtn") {
        const tabela = document.querySelector(".modal-importacao-lote-table");
        const linhas = tabela.querySelectorAll("tbody tr");
        if (!linhas.length) {
            Swal.fire('Erro', 'Nenhum dado encontrado para importar.', 'warning');
            return;
        }

        Swal.fire({
            title: 'Confirmação',
            text: `Você quer importar ${linhas.length} produtos?`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Sim, importar',
            cancelButtonText: 'Cancelar'
        }).then(async (result) => {
            if (!result.isConfirmed) return;

            let sucesso = 0;
            let erros = 0;

            for (const linha of linhas) {
                const inputs = linha.querySelectorAll('input');
                const item = {};
                inputs.forEach(input => {
                    item[input.dataset.coluna] = input.value.trim();
                });

                console.log("[Importação] Processando item:", item);

                if (!item["Nome"] || !item["Código"] || !item["Preço"]) {
                    console.warn("[Importação] Dados incompletos para o item:", item);
                    linha.style.backgroundColor = '#ffcccc';  // Marca a linha em vermelho claro
                    erros++;
                    continue;
                }

                // Primeira etapa: buscar se o produto já existe na API
                const existe = await buscarProdutoExistenteLote(item["Código"]);

                if (existe) {
                    // Atualiza apenas o estoque
                    const qtdAdicionar = parseInt(item["Estoque Atual"]) || 0;
                    const ok = await atualizarEstoqueExistenteLote(existe.uid, qtdAdicionar);
                    if (ok) {
                        linha.style.backgroundColor = '#ccffcc';  // verde claro
                        sucesso++;
                    } else {
                        linha.style.backgroundColor = '#ffcccc';
                        erros++;
                    }
                } else {
                    // Criar novo produto
                    const ok = await criarProdutoLote(item);
                    if (ok) {
                        linha.style.backgroundColor = '#ccffcc';  // verde claro
                        sucesso++;
                    } else {
                        linha.style.backgroundColor = '#ffcccc';
                        erros++;
                    }
                }
            }

            Swal.fire('Importação Finalizada', `✅ Sucesso: ${sucesso}\n❌ Erros: ${erros}`, 'info');
        });
    }
});

// Função para buscar se o produto já existe
async function buscarProdutoExistenteLote(codigo) {
    try {
        const url = `https://api.web.nextar.com.br/api/v1/product/2411349?page=0&size=1&search=${encodeURIComponent(codigo)}&filter=active`;
        const res = await fetchComToken(url);
        if (!res.ok) throw new Error(`Erro ${res.status}`);
        const dados = await res.json();
        return dados.content?.[0] || null;
    } catch (e) {
        console.error("[Importação] Erro ao buscar produto:", e.message);
        return null;
    }
}

// Função para atualizar estoque existente
async function atualizarEstoqueExistenteLote(uid, qtdAdicionar) {
    try {
        const urlGet = `https://api.web.nextar.com.br/api/v1/product/2411349/${uid}`;
        const resProduto = await fetchComToken(urlGet);
        if (!resProduto.ok) throw new Error(`Erro ${resProduto.status}`);
        const produto = await resProduto.json();

        produto.current_stock = (produto.current_stock ?? 0) + qtdAdicionar;
        produto.stock = produto.current_stock; // redundante, mas necessário

        const urlPut = `https://api.web.nextar.com.br/api/v1/product/2411349`;
        const resUpdate = await fetchComToken(urlPut, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(produto)
        });

        if (resUpdate.ok) {
            console.log(`[Importação] Estoque atualizado para UID: ${uid}`);
            return true;
        } else {
            const txt = await resUpdate.text();
            console.error(`[Importação] Erro ao atualizar estoque: ${txt}`);
            return false;
        }
    } catch (e) {
        console.error("[Importação] Falha ao atualizar estoque:", e.message);
        return false;
    }
}

// Função para criar novo produto
async function criarProdutoLote(item) {
    try {
        // Detectar qual loja está na categoria
        const categoriaTexto = (item["Categoria"] || "PeliculasLoja2").toLowerCase();
        let uidCategoria = categoriaUIDs.loja3;  // default loja3

        if (categoriaTexto.includes("loja1")) {
            uidCategoria = categoriaUIDs.loja1;
        } else if (categoriaTexto.includes("loja2")) {
            uidCategoria = categoriaUIDs.loja2;
        } else if (categoriaTexto.includes("loja3")) {
            uidCategoria = categoriaUIDs.loja3;
        }

        const categoriaPayload = {
            uid: uidCategoria,
            shopcode: "2411349",
            description: item["Categoria"] || "PeliculasLoja2",
            id: 0,  // opcional: mapeie IDs reais se quiser
            subcategories: []
        };

        const payload = {
            uid: crypto.randomUUID(),
            shopcode: "2411349",
            combo: false,
            unit_price: 0,
            stock: parseInt(item["Estoque Atual"]) || 0,
            stockmin: 5,
            active: true,
            profit_margin: 0,
            can_change_price: false,
            auto_price: false,
            price_promo: 0,
            prodtend: null,
            prodtbegin: null,
            published: false,
            promotional: false,
            fractional_sale: false,
            description: item["Nome"],
            code: item["Código"],
            'automatic-code': false,
            category: categoriaPayload,
            brand: null,
            price: parseFloat(item["Preço"]),
            cost_price: 0,
            stock_control: true,
            stockmax: 30,
            unit: null,
            combo_items: [],
            tax: null,
            no_tax: false,
            tax_use_global: false,
            default_markup: false,
            current_stock: parseInt(item["Estoque Atual"]) || 0,
            commission_percentage: 0,
            commission_profit: false,
            commission_use_global: true,
            supplier_uid: '',
            suppliers: [],
            photos: [],
            image: null,
            base64_images: []
        };

        const res = await fetchComToken(`https://api.web.nextar.com.br/api/v1/product/2411349`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            console.log(`[Importação] Produto criado com sucesso: ${item["Nome"]}`);
            return true;
        } else {
            const txt = await res.text();
            console.error(`[Importação] Erro ao criar produto: ${txt}`);
            return false;
        }
    } catch (e) {
        console.error("[Importação] Falha ao criar produto:", e.message);
        return false;
    }
}
