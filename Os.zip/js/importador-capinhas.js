
async function processarCapinhas() {
  const imagens = document.getElementById("inputMultiplasImagens").files;
  const margem = parseFloat(document.getElementById("margemLucroGlobal").value || 0);

  for (const img of imagens) {
    const base64 = await toBase64(img);
    console.log("📸 Imagem convertida para Base64.");

    const dadosOCR = await fazerOCR(base64);
    console.log("📄 Texto extraído pelo OCR:", dadosOCR);

    const modelo = extrairModelo(dadosOCR);
    const cor = extrairCor(dadosOCR);
    const preco = calcularPreco(dadosOCR, margem);

    console.log("🔍 Dados extraídos:", { modelo, cor, preco });

    adicionarNaTabela(modelo, cor, preco, base64);
  }
}

function toBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function adicionarNaTabela(modelo, cor, preco, base64) {
  const tbody = document.querySelector('#tabelaCapinhas tbody');
  const row = document.createElement('tr');
  row.innerHTML = `
    <td><img src="data:image/png;base64,${base64}" style="height: 60px;"></td>
    <td><input class="form-control" value="${modelo}"></td>
    <td><input class="form-control" value="${cor}"></td>
    <td><input class="form-control" value="${preco}"></td>
    <td><textarea class="form-control" style="display:none">${base64}</textarea></td>
  `;
  tbody.appendChild(row);
}

async function cadastrarCapinhas() {
  const linhas = document.querySelectorAll('#tabelaCapinhas tbody tr');
  const produtos = [...linhas].map(row => ({
    modelo: row.children[1].querySelector('input').value,
    cor: row.children[2].querySelector('input').value,
    preco: parseFloat(row.children[3].querySelector('input').value),
    imagemBase64: row.children[4].querySelector('textarea').value,
  }));

  console.log("📦 Enviando produtos para a API:", produtos);

  for (const p of produtos) {
    await fetch('https://seuendpoint/api/produtos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(p)
    });
  }

  Swal.fire('✅ Sucesso', 'Produtos cadastrados com sucesso!', 'success');
}

async function fazerOCR(base64) {
  try {
    const res = await fetch('http://localhost:3000/ocr', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ base64 })
    });

    const json = await res.json();
    if (json.error) {
      console.error('🚫 Erro do OCR:', json.error);
      return '';
    }

    return json.texto || '';
  } catch (err) {
    console.error('❌ Erro na requisição OCR (proxy local):', err);
    return '';
  }
}

function extrairModelo(texto) {
  const match = texto.match(/(A\d{2,}|[A-Z]{2,}\d{2,}|iPhone\s?\w+|Galaxy\s?[A-Z]?\d{1,3})/i);
  return match ? match[0].toUpperCase() : 'Modelo Desconhecido';
}

function extrairCor(texto) {
  const cores = ['Preto', 'Branco', 'Azul', 'Vermelho', 'Verde', 'Rosa', 'Roxo', 'Amarelo', 'Cinza', 'Dourado', 'Prata', 'Transparente'];
  for (let cor of cores) {
    if (texto.toLowerCase().includes(cor.toLowerCase())) {
      return cor;
    }
  }
  return 'Cor Desconhecida';
}

function calcularPreco(texto, margem) {
  const match = texto.replace(',', '.').match(/(\d+\.?\d{0,2})/g);
  if (match) {
    const valorBase = parseFloat(match[0]);
    const precoFinal = valorBase + (valorBase * (margem / 100));
    return precoFinal.toFixed(2);
  }
  return '0.00';
}
