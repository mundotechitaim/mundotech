// config.js

const shopCode = '2411349'; // Mesmo para todas as lojas
let token = ''; // Atualizado automaticamente
const email = 'mundotechitaim@gmail.com';
const senha = 'S@s@1509';

async function atualizarToken() {
  try {
    console.log('[INFO] Atualizando token...');
    const res = await fetch('https://api.auth.nextar.com.br/api/v1/authenticate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Token': 'aPbueYludOVnzmN0a891dG2rZW==' // Token público da Nextar
      },
      body: JSON.stringify({
        username: email,
        password: senha,
        origin: 3
      })
    });

    if (!res.ok) throw new Error('Falha ao autenticar');

    const data = await res.json();
    token = data.token;

    localStorage.setItem('nextar_token', token);
    console.log('[INFO] Novo token recebido.');
  } catch (err) {
    console.error('[ERRO] Não foi possível atualizar o token:', err.message);
  }
}

async function fetchComToken(url, options = {}, tentarNovamente = true) {
  if (!token) {
    const salvo = localStorage.getItem('nextar_token');
    if (salvo) token = salvo;
    else await atualizarToken();
  }

  token = token || localStorage.getItem('nextar_token'); // Segurança extra

  // Corrigir headers duplicados ou ausentes
  const headers = Object.assign({}, options.headers || {}, {
    'Authorization': `Bearer ${token}`,
    'Accept': 'application/json'
  });

  console.log('[DEBUG] Requisição para:', url);
  console.log('[DEBUG] Headers:', headers);

  try {
    const res = await fetch(url, { ...options, headers });

    // Token expirado? Reautentica apenas uma vez
    if (res.status === 401 && tentarNovamente) {
      console.warn('[AVISO] Token expirado. Atualizando...');
      await atualizarToken();
      return fetchComToken(url, options, false);
    }

    return res;
  } catch (err) {
    console.error('[ERRO] Falha na requisição:', err.message);
    throw err;
  }
}