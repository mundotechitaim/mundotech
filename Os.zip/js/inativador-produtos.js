// inativador-produtos-v4.js

console.log("[InativadorV4] Script carregado com SweetAlert2.");

// Configuração da senha mestre (mantida conforme solicitado)
const SENHA_MESTRE = "S@s@1602"; // ATENÇÃO: Senha hardcoded é insegura.
const COR_PRIMARIA_PROJETO = "#FF6600"; // Cor principal do seu projeto

// Criação e inserção do modal na página
(function criarModalInativadorV4() {
    const modalHtml = `
    <div id="modalInativarProdutos" class="modal-custom" style="display: none;">
        <div class="modal-custom-content">
            <div class="modal-custom-header">
                <div class="modal-custom-title-container">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-archive-fill modal-title-icon" viewBox="0 0 16 16">
                        <path d="M12.643 1.5H3.357C2.643 1.5 2 2.143 2 2.857v10.286c0 .714.643 1.357 1.357 1.357h9.286c.714 0 1.357-.643 1.357-1.357V2.857C14 2.143 13.357 1.5 12.643 1.5zM5.5 4a.5.5 0 0 1 .5.5V5h4v-.5a.5.5 0 0 1 1 0V5h.5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1 0-1H5v-.5a.5.5 0 0 1 .5-.5zM6 11.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5z"/>
                    </svg>
                    <h2>Inativar Produtos</h2>
                </div>
                <span class="close-modal-custom" id="fecharModalInativar">&times;</span>
            </div>
            <div class="modal-custom-body">
                <p class="modal-subtitle">Busque e gerencie a ativação de produtos do sistema Nextar.</p>
                <div class="form-group-custom">
                    <input type="text" id="termoBuscaInativar" class="form-control-custom" placeholder="Buscar por nome, código..." />
                    <button id="buscarInativarBtn" class="btn-custom btn-primary-custom">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
                        </svg>
                        Buscar
                    </button>
                </div>
                <button id="inativarTodosBtn" class="btn-custom btn-danger-custom btn-full-width-custom">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16">
                        <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z"/>
                    </svg>
                    Inativar Todos os Listados
                </button>
                <div id="resultadosInativarContainer">
                    <div id="loaderInativar" class="loader-custom" style="display: none;">
                        <div class="spinner-custom"></div>
                        Buscando produtos...
                    </div>
                    <div id="resultadosInativar" class="resultados-custom"></div>
                    <p id="avisoLimiteResultados" class="aviso-limite-custom" style="display: none;">
                        A busca exibiu os primeiros 100 resultados. Refine sua busca se não encontrou o produto desejado.
                    </p>
                </div>
            </div>
            <div class="modal-custom-footer">
                <span>Pressione Ctrl + Alt + A para reabrir</span>
            </div>
        </div>
    </div>
    <style>
        /* Estilos CSS da v3 são mantidos aqui, pois são extensos e já incorporam a cor primária e melhorias visuais.
           Certifique-se de que a variável --cor-primaria esteja definida como ${COR_PRIMARIA_PROJETO} no início do <style> block.
           Abaixo, apenas um trecho para exemplificar. O CSS completo da V3 deve ser inserido.
        */
        :root {
            --cor-primaria: ${COR_PRIMARIA_PROJETO};
            --cor-texto-primaria: #FFFFFF;
            --cor-danger: #dc3545; /* Vermelho para ações de perigo */
            --cor-success: #28a745; /* Verde para sucesso */
            --cor-secondary: #6c757d; /* Cinza para ações secundárias */
            --cor-background-modal: #fdfdfd;
            --cor-borda-suave: #e9ecef;
            --cor-texto-padrao: #343a40;
            --cor-texto-secundario: #495057;
        }
        .modal-custom {
            position: fixed; z-index: 1050; left: 0; top: 0;
            width: 100%; height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.65);
            display: flex; align-items: center; justify-content: center;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        }
        .modal-custom-content {
            background-color: var(--cor-background-modal);
            margin: auto; padding: 0;
            width: 90%; max-width: 750px;
            border-radius: 10px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
            animation: slideInV4 0.3s ease-out;
        }
        @keyframes slideInV4 { /* Renomeado para evitar conflito se v3 existir */
            from { transform: translateY(-30px) scale(0.98); opacity: 0; }
            to { transform: translateY(0) scale(1); opacity: 1; }
        }
        .modal-custom-header {
            background-color: var(--cor-primaria); color: var(--cor-texto-primaria);
            padding: 18px 25px;
            border-top-left-radius: 10px; border-top-right-radius: 10px;
            display: flex; justify-content: space-between; align-items: center;
        }
        .modal-custom-title-container {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .modal-title-icon { opacity: 0.9; }
        .modal-custom-header h2 { margin: 0; font-size: 1.4rem; font-weight: 500;}
        .modal-subtitle {
            font-size: 0.95rem; color: var(--cor-texto-secundario);
            margin-top: -5px; margin-bottom: 20px; text-align: left;
        }
        .close-modal-custom {
            color: var(--cor-texto-primaria); float: right; font-size: 30px; font-weight: bold;
            cursor: pointer; opacity: 0.8; line-height: 1;
        }
        .close-modal-custom:hover { opacity: 1; }
        .modal-custom-body { padding: 25px; }
        .modal-custom-footer {
            padding: 12px 25px; text-align: center; font-size: 0.85em;
            color: #888; border-top: 1px solid var(--cor-borda-suave);
            background-color: #f9f9f9;
            border-bottom-left-radius: 10px; border-bottom-right-radius: 10px;
        }
        .form-group-custom { display: flex; margin-bottom: 20px; gap: 10px; }
        .form-control-custom {
            flex-grow: 1; padding: 12px 15px; border: 1px solid #ced4da;
            border-radius: 6px; font-size: 1rem;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }
        .form-control-custom:focus {
            border-color: var(--cor-primaria);
            box-shadow: 0 0 0 0.2rem color-mix(in srgb, var(--cor-primaria) 25%, transparent); /* Mix com alfa */
            outline: none;
        }
        .btn-custom {
            padding: 12px 18px; border: none; border-radius: 6px;
            cursor: pointer; font-size: 1rem; font-weight: 500;
            transition: background-color 0.2s ease, opacity 0.2s ease, transform 0.1s ease;
            display: inline-flex; align-items: center; justify-content: center; gap: 8px;
        }
        .btn-custom:hover { transform: translateY(-1px); }
        .btn-custom:active { transform: translateY(0px); }
        .btn-primary-custom { background-color: var(--cor-primaria); color: var(--cor-texto-primaria); }
        .btn-primary-custom:hover { background-color: color-mix(in srgb, var(--cor-primaria) 90%, black); }
        .btn-danger-custom { background-color: var(--cor-danger); color: white; }
        .btn-danger-custom:hover { background-color: color-mix(in srgb, var(--cor-danger) 90%, black); }
        .btn-success-custom { background-color: var(--cor-success); color: white; }
        .btn-secondary-custom { background-color: var(--cor-secondary); color: white; }
        .btn-full-width-custom { width: 100%; justify-content: center; margin-bottom: 20px; }
        .btn-custom:disabled { opacity: 0.5; cursor: not-allowed; background-color: #ccc !important; transform: translateY(0); }
        #resultadosInativarContainer { margin-top: 20px; }
        .loader-custom {
            text-align: center; padding: 25px; font-size: 1.1em; color: var(--cor-primaria);
            background-color: #fff; border: 1px solid var(--cor-borda-suave); border-radius: 6px;
            display: flex; align-items: center; justify-content: center; gap: 10px;
        }
        .spinner-custom {
            width: 20px; height: 20px;
            border: 3px solid color-mix(in srgb, var(--cor-primaria) 30%, transparent);
            border-top-color: var(--cor-primaria);
            border-radius: 50%;
            animation: spinV4 0.8s linear infinite; /* Renomeado */
        }
        @keyframes spinV4 { to { transform: rotate(360deg); } } /* Renomeado */
        .resultados-custom {
            max-height: 380px; overflow-y: auto;
            border: 1px solid var(--cor-borda-suave); border-radius: 6px;
            background-color: #fff;
        }
        .produto-item-custom {
            border-bottom: 1px solid var(--cor-borda-suave); padding: 15px;
            display: flex; align-items: center; gap: 15px;
            transition: background-color 0.2s ease;
        }
        .produto-item-custom:last-child { border-bottom: none; }
        .produto-item-custom:hover { background-color: #f8f9fa; }
        .produto-thumbnail-custom {
            width: 60px; height: 60px;
            object-fit: cover;
            border-radius: 4px;
            border: 1px solid var(--cor-borda-suave);
            background-color: #f0f0f0;
            flex-shrink: 0; /* Impede que a imagem encolha */
        }
        .produto-thumbnail-placeholder {
             display: flex; align-items: center; justify-content: center;
             font-size: 1.8rem; color: #ccc;
             background-color: #e9ecef; /* Fundo para o placeholder SVG */
        }
        .produto-info-custom { flex-grow: 1; min-width: 0; /* Para o flex-grow funcionar corretamente com text-overflow */}
        .produto-info-custom strong {
            font-size: 1.1em; color: var(--cor-texto-padrao); display: block; margin-bottom: 2px;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis; /* Evitar quebra de nome longo */
        }
        .produto-info-custom small { color: var(--cor-texto-secundario); font-size: 0.88em; display: block; line-height: 1.4;}
        .produto-info-custom .code-cat { color: var(--cor-primaria); font-weight: 500; }
        .produto-info-custom .stock { color: var(--cor-success); font-weight: bold;}
        .aviso-limite-custom {
            font-size: 0.9em; color: var(--cor-texto-secundario); text-align: center;
            margin-top: 15px; padding: 10px; background-color: #fff3cd;
            border: 1px solid #ffeeba; border-radius: 4px;
        }
        .status-error-custom { color: var(--cor-danger); font-weight: bold; padding: 15px; }
        .swal-confirm-button {
             background-color: var(--cor-primaria) !important;
             color: var(--cor-texto-primaria) !important;
             margin-left: 10px !important;
        }
        .swal-cancel-button {
             background-color: var(--cor-secondary) !important;
             color: white !important;
        }
    </style>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHtml);

    const modalInativar = document.getElementById("modalInativarProdutos");
    const btnFecharModalInativar = document.getElementById("fecharModalInativar");
    const buscarBtn = document.getElementById("buscarInativarBtn");
    const inativarTodosBtn = document.getElementById("inativarTodosBtn");
    const resultadosDiv = document.getElementById("resultadosInativar");

    if (btnFecharModalInativar) btnFecharModalInativar.addEventListener('click', fecharModalInativar);
    if (buscarBtn) buscarBtn.addEventListener('click', buscarProdutosInativar);
    if (inativarTodosBtn) inativarTodosBtn.addEventListener('click', inativarTodosOsListados);
    
    if (resultadosDiv) {
        resultadosDiv.addEventListener('click', function(e) {
            const targetButton = e.target.closest('.btn-inativar-produto-individual');
            if (targetButton) {
                const uid = targetButton.getAttribute('data-uid');
                inativarProdutoIndividual(uid, targetButton);
            }
        });
    }
})();

function abrirModalInativar() {
    Swal.fire({
        title: 'Acesso Restrito',
        text: 'Digite a senha mestre para continuar:',
        input: 'password',
        inputPlaceholder: 'Senha...',
        confirmButtonText: 'Entrar',
        showCancelButton: true,
        cancelButtonText: 'Cancelar',
        inputAttributes: { autocapitalize: 'off', autocorrect: 'off' },
        customClass: {
            confirmButton: 'btn-custom swal-confirm-button',
            cancelButton: 'btn-custom swal-cancel-button'
        },
        buttonsStyling: false,
        preConfirm: (senha) => {
            if (senha !== SENHA_MESTRE) Swal.showValidationMessage('Senha incorreta!');
            return senha;
        }
    }).then((result) => {
        if (result.isConfirmed && result.value === SENHA_MESTRE) {
            console.log("[InativadorV4] Senha correta. Modal liberado.");
            const modal = document.getElementById("modalInativarProdutos");
            if (modal) {
                modal.style.display = 'flex';
                const termoInput = document.getElementById("termoBuscaInativar");
                if (termoInput) termoInput.focus();
            }
        } else {
            console.log("[InativadorV4] Acesso negado ou cancelado.");
        }
    });
}

function fecharModalInativar() {
    const modal = document.getElementById("modalInativarProdutos");
    if (modal) modal.style.display = 'none';
}

document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.altKey && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        abrirModalInativar();
    }
});

async function buscarProdutosInativar() {
    const termo = document.getElementById("termoBuscaInativar").value.trim();
    const resultDiv = document.getElementById("resultadosInativar");
    const loader = document.getElementById("loaderInativar");
    const avisoLimite = document.getElementById("avisoLimiteResultados");

    resultDiv.innerHTML = '';
    avisoLimite.style.display = 'none';
    loader.style.display = 'flex';

    if (typeof shopCode === 'undefined' || typeof fetchComToken === 'undefined') {
        loader.style.display = 'none';
        resultDiv.innerHTML = '<div class="produto-item-custom status-error-custom">Erro de configuração: shopCode ou fetchComToken não definidos.</div>';
        console.error("[InativadorV4] shopCode ou fetchComToken não estão definidos globalmente.");
        return;
    }

    const url = `https://api.web.nextar.com.br/api/v1/product/${shopCode}?page=0&size=100&sort=description&direction=asc&pdv=false&search=${encodeURIComponent(termo)}&filter=active&ts=${Date.now()}`;

    try {
        const res = await fetchComToken(url);
        if (!res.ok) {
            const errorData = await res.text();
            throw new Error(`Falha na API: ${res.status} - ${errorData}`);
        }
        const json = await res.json();
        loader.style.display = 'none';

        if (!json.content || !json.content.length) {
            resultDiv.innerHTML = '<div class="produto-item-custom" style="justify-content:center; color: var(--cor-texto-secundario);">Nenhum produto encontrado.</div>';
            return;
        }

        if (json.content.length === 100) avisoLimite.style.display = 'block';

        json.content.forEach(prod => {
            const estoqueAtual = (prod.current_stock != null ? prod.current_stock : prod.stock) ?? 0;
            const categoriaDesc = prod.category?.description || 'N/A';
            
            // CORREÇÃO AQUI: Acessa a URL da imagem conforme app-loja3.js
            const photoData = prod.photos && prod.photos.length > 0 ? prod.photos[0] : null;
            const imageUrl = photoData ? photoData.url : '';

            const div = document.createElement('div');
            div.className = "produto-item-custom";

            let imageHtml;
            const placeholderSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-image" viewBox="0 0 16 16"><path d="M6.002 5.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/><path d="M2.002 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2h-12zm12 1a1 1 0 0 1 1 1v6.5l-3.777-1.947a.5.5 0 0 0-.577.093l-3.71 3.71-2.66-1.772a.5.5 0 0 0-.63.062L1.002 12V3a1 1 0 0 1 1-1h12z"/></svg>`;

            if (imageUrl) {
                // Tenta carregar a imagem real, se falhar, mostra o placeholder SVG via JS
                imageHtml = `
                    <img src="${imageUrl}" alt="${prod.description || 'Produto'}" class="produto-thumbnail-custom" 
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="produto-thumbnail-custom produto-thumbnail-placeholder" style="display:none;">${placeholderSvg}</div>`;
            } else {
                // Se não há URL, mostra o placeholder SVG diretamente
                imageHtml = `<div class="produto-thumbnail-custom produto-thumbnail-placeholder">${placeholderSvg}</div>`;
            }

            div.innerHTML = `
                ${imageHtml}
                <div class="produto-info-custom">
                    <strong>${prod.description || 'Produto sem descrição'}</strong>
                    <small>
                        <span class="code-cat">Código:</span> ${prod.code || 'N/A'} |
                        <span class="code-cat">Categoria:</span> ${categoriaDesc} <br/>
                        <span class="stock">Estoque:</span> ${estoqueAtual}
                    </small>
                </div>
                <div>
                    <button class="btn-custom btn-danger-custom btn-inativar-produto-individual" data-uid="${prod.uid}">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
                            <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
                        </svg>
                        Inativar
                    </button>
                </div>
            `;
            resultDiv.appendChild(div);
        });

    } catch (e) {
        loader.style.display = 'none';
        resultDiv.innerHTML = `<div class="produto-item-custom status-error-custom">Erro ao buscar: ${e.message}</div>`;
        console.error("[InativadorV4] Erro em buscarProdutosInativar:", e);
    }
}

async function inativarProdutoIndividual(uid, btn) {
    btn.disabled = true;
    const originalButtonHTML = btn.innerHTML;
    btn.innerHTML = `<div class="spinner-custom" style="width:16px; height:16px; border-width:2px; border-top-color:white;"></div>Aguarde...`;

    try {
        const res = await fetchComToken(`https://api.web.nextar.com.br/api/v1/product/${shopCode}/inactivate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ shopcode: shopCode, uid })
        });

        if (res.ok) {
            btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16"><path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/></svg> Inativado`;
            btn.classList.remove('btn-danger-custom');
            btn.classList.add('btn-success-custom');
        } else {
            btn.innerHTML = originalButtonHTML;
            btn.disabled = false;
            const errorText = await res.text();
            console.error("[InativadorV4] Erro ao inativar:", errorText);
            Swal.fire('Erro', `Não foi possível inativar o produto (UID: ${uid}). Detalhes: ${errorText}`, 'error');
        }
    } catch (e) {
        btn.innerHTML = originalButtonHTML;
        btn.disabled = false;
        console.error("[InativadorV4] Falha na requisição de inativação:", e);
        Swal.fire('Falha na Requisição', `Ocorreu um erro de rede ou script (UID: ${uid}).`, 'error');
    }
}

async function inativarTodosOsListados() {
    const botoes = document.querySelectorAll(".btn-inativar-produto-individual:not(:disabled):not(.btn-success-custom)");
    if (!botoes.length) {
        return Swal.fire({
            title: 'Nenhuma Ação',
            text: 'Nenhum produto na lista para inativar ou todos já foram processados.',
            icon: 'info',
            confirmButtonText: 'OK',
            customClass: { confirmButton: 'btn-custom swal-confirm-button' },
            buttonsStyling: false
        });
    }

    const confirmationResult = await Swal.fire({
        title: `Confirmar Inativação em Massa`,
        text: `Você deseja tentar inativar ${botoes.length} produto(s) listado(s)?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sim, inativar listados',
        cancelButtonText: 'Cancelar',
        customClass: {
            confirmButton: 'btn-custom btn-danger-custom swal-confirm-button',
            cancelButton: 'btn-custom swal-cancel-button'
        },
        buttonsStyling: false
    });

    if (!confirmationResult.isConfirmed) return;

    let sucessos = 0; let falhas = 0;
    Swal.fire({
        title: 'Processando Inativações...',
        html: `Inativando ${botoes.length} produtos. Por favor, aguarde.<br><br><div class="loader-custom" style="margin: 0 auto; border:none; background:transparent;"><div class="spinner-custom"></div></div>`,
        allowOutsideClick: false, showConfirmButton: false,
    });

    for (const btn of botoes) {
        const uid = btn.getAttribute("data-uid");
        const originalButtonHTML = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = `<div class="spinner-custom" style="width:16px; height:16px; border-width:2px; border-top-color:white;"></div> Aguarde...`;
        try {
            const res = await fetchComToken(`https://api.web.nextar.com.br/api/v1/product/${shopCode}/inactivate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ shopcode: shopCode, uid })
            });
            if (res.ok) {
                btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">...</svg> Inativado`;
                btn.classList.remove('btn-danger-custom');
                btn.classList.add('btn-success-custom');
                sucessos++;
            } else {
                btn.innerHTML = originalButtonHTML; btn.disabled = false; falhas++;
                console.error(`[InativadorV4] Falha ao inativar UID ${uid} em lote: ${await res.text()}`);
            }
        } catch (e) {
            btn.innerHTML = originalButtonHTML; btn.disabled = false; falhas++;
            console.error(`[InativadorV4] Erro de rede/script ao inativar UID ${uid} em lote:`, e);
        }
    }
    Swal.close();
    let finalMessage = `Processamento concluído!<br><br>Sucessos: <b>${sucessos}</b><br>Falhas: <b>${falhas}</b>`;
    let finalIcon = falhas === 0 ? 'success' : (sucessos === 0 ? 'error' : 'warning');
    if (falhas > 0) finalMessage += `<br><br>Verifique o console para detalhes dos erros.`;
    Swal.fire({
        title: 'Resultado da Operação', html: finalMessage, icon: finalIcon, confirmButtonText: 'Entendido',
        customClass: { confirmButton: 'btn-custom swal-confirm-button' }, buttonsStyling: false
    });
}

// ----- ATENÇÃO: Definições Globais Necessárias -----
// const shopCode = 'SEU_CODIGO_LOJA_AQUI';
// async function fetchComToken(url, options = {}) { /* ...sua implementação... */ }
// Certifique-se de que SweetAlert2 está carregado: <script src=".../sweetalert2.all.min.js"></script>