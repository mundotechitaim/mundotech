document.addEventListener("DOMContentLoaded", () => {
    const pageContainer = document.querySelector(".page-container");
    const menuButtons = document.querySelectorAll(".menu-topo button[data-page]");

    // Função para carregar a página via fetch
    function loadPage(pageName) {
        const url = `partials/${pageName}.html`;
        console.log(`🔄 Carregando página: ${url}`);

        fetch(url)
            .then(response => {
                if (!response.ok) throw new Error(`Erro ao carregar ${url} (${response.status})`);
                return response.text();
            })
            .then(html => {
                pageContainer.innerHTML = html;
                console.log(`✅ Página ${pageName} carregada com sucesso.`);

                // 🔔 Opcional: Após carregar, podemos disparar eventos para inicializar scripts se precisar
                document.dispatchEvent(new CustomEvent("pageLoaded", { detail: { pageName } }));
            })
            .catch(err => {
                console.error(err);
                pageContainer.innerHTML = `<p class="text-center text-danger my-5">Erro ao carregar a página: ${pageName}</p>`;
            });
    }

    // 🚀 Carrega a página inicial (vendas) por padrão
    loadPage("vendas");

    // 🚦 Configura cliques do menu para trocar de página
    menuButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            const pageName = btn.dataset.page;
            loadPage(pageName);
        });
    });
});