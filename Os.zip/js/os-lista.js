// Constante da API - assumindo que está definida globalmente ou no topo do seu script
const apiBase = "https://www.mundotechip.com.br/index.php/api";

// ATENÇÃO: A variável senhasVendedores deve estar definida e acessível neste escopo.
// Exemplo:
// const senhasVendedores = {
//     "senha123": "Funcionário A",
//     "outrasenha": "Funcionário B",
//     // ... outras senhas e nomes de vendedores
// };

new Vue({
  el: "#lista-os-app",
  data: {
    ordens: [],
    carregando: false,
    erro: null,
    faturarModalVisible: false, // Controla a visibilidade do modal de faturamento
    faturando: false, // Indica se uma fatura está sendo processada
    pagamentoDescricao: '',
    pagamentoCliente: '',
    pagamentoValor: 0,
    pagamentoDesconto: 0,
    pagamentoDataEntrada: '',
    pagamentoDataRecebimento: '', // Data em que o pagamento foi recebido/confirmado
    pagamentoFormaAtual: '', // Forma de pagamento selecionada atualmente
    pagamentosLista: [], // Lista de pagamentos parciais/múltiplos para uma OS
    idOsSelecionada: null, // ID da Ordem de Serviço atualmente selecionada para uma ação
    retiradaModalVisible: false, // Controla a visibilidade do modal de retirada
    retiradaNome: '',
    retiradaDocumento: '',
    senhaRetirada: '',
    erroRetirada: '',
    osSelecionada: null, // Objeto da OS selecionada para ações como retorno ou retirada
    sugestoesServicos: [], // Lista de sugestões de serviços para autocomplete
    focusedServico: null, // Índice do serviço focado para exibição de sugestões
    senhaFaturamento: '', // Senha para autorizar o faturamento

    // Dados para edição de OS
    edicao: {
      idOs: null,
      descricaoProduto: '',
      defeito: '',
      status: '',
      valorTotal: 0,
      dataInicial: '',
      imei1: '',
      imei2: '',
      clientes_id: null,
      usuarios_id: null,
      servicos: [] // Lista de serviços associados à OS em edição
    },
    senhaEdicao: '', // Senha para autorizar a edição da OS
    erroEdicao: '', // Mensagem de erro para o modal de edição
    retornoDescricao: '', // Descrição para o modal de retorno técnico
    senhaRetorno: '', // Senha para autorizar o retorno técnico
  },
  methods: {
    /**
     * Retorna a data e hora atual no formato local 'YYYY-MM-DD HH:MM:SS'.
     * @returns {string} Data e hora formatada.
     */
    getDataHoraLocal() {
      const agora = new Date();
      // Ajusta para o fuso horário local, subtraindo o offset em minutos
      const fuso = new Date(agora.getTime() - (agora.getTimezoneOffset() * 60000));
      return `${fuso.getFullYear()}-${String(fuso.getMonth() + 1).padStart(2, '0')}-${String(fuso.getDate()).padStart(2, '0')} ${String(fuso.getHours()).padStart(2, '0')}:${String(fuso.getMinutes()).padStart(2, '0')}:${String(fuso.getSeconds()).padStart(2, '0')}`;
    },

  formatarDataHoraExata(dataOriginal) {
    if (!dataOriginal) return '---';
    try {
      const dt = new Date(dataOriginal);
      dt.setHours(dt.getHours() + 6); // 🔧 soma 6 horas
      return dt.toLocaleString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return dataOriginal;
    }
  },



    /**
     * Oculta a lista de sugestões de serviços após um pequeno atraso.
     * Usado para permitir o clique na sugestão antes que ela desapareça ao perder o foco do input.
     */
    ocultarSugestoesComAtraso() {
      setTimeout(() => {
        this.focusedServico = null; // Limpa o foco, escondendo as sugestões
      }, 200); // Atraso de 200ms
    },

  /**
   * Gera o HTML do recibo e o escreve em uma janela fornecida para impressão.
   * @param {Window} janela - A referência da janela (pop-up) onde o recibo será escrito.
   */
gerarRecibo(janela) {
  if (!janela) {
    console.error("A janela de recibo não foi fornecida ou é inválida.");
    alert("Erro ao preparar janela para gerar o recibo. Tente novamente.");
    return;
  }

  const totalFinal = this.pagamentosLista.reduce((soma, pg) => soma + parseFloat(pg.valor || 0), 0);
  const desconto = parseFloat(this.pagamentoDesconto) || 0;
  const valorComDesconto = totalFinal - desconto;

  const nomeFuncionario = this._nomeFuncionarioFaturou || (
    this.senhaFaturamento && senhasVendedores[this.senhaFaturamento]
      ? senhasVendedores[this.senhaFaturamento]
      : 'N/A'
  );

  const formatarNomeCliente = (nome) => {
    if (!nome) return 'N/A';
    return nome.toLowerCase().split(' ').map(p => p.charAt(0).toUpperCase() + p.slice(1)).join(' ');
  };

  const formatarDataRecebimentoComAjuste = (dataOriginal) => {
    if (!dataOriginal) return '---';
    try {
      const dt = new Date(dataOriginal);
      dt.setHours(dt.getHours() + 6); // 🔧 somar 6 horas
      return dt.toLocaleString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return dataOriginal;
    }
  };

  const html = `
    <div style="font-family: Arial, sans-serif; padding: 20px; width: 280px; font-size: 15px; border: 1px solid #ccc; box-shadow: 0 0 5px rgba(0,0,0,0.1);">
      <h3 style="text-align:center; margin-top:0; margin-bottom: 10px; font-size: 19px;">📄 Recibo de Faturamento</h3>
      <hr style="border: 0; border-top: 1px dashed #ccc; margin-bottom: 10px;">
      <strong>OS Nº:</strong> ${this.idOsSelecionada || 'N/A'}<br>
      <strong>Cliente:</strong> ${formatarNomeCliente(this.pagamentoCliente)}<br>
      <strong>Descrição:</strong> ${this.pagamentoDescricao || 'N/A'}<br>
      <strong>Recebimento:</strong> ${this.pagamentoDataRecebimento ? formatarDataRecebimentoComAjuste(this.pagamentoDataRecebimento) : this.getDataHoraLocal()}<br>
      <strong>Funcionário:</strong> ${nomeFuncionario}<br><br>

      <strong>Pagamentos:</strong><br>
      ${this.pagamentosLista.length > 0 ? 
        this.pagamentosLista.map(pg => `• ${pg.forma}: R$ ${parseFloat(pg.valor).toFixed(2)}`).join('<br>') : 
        'Nenhum pagamento listado.'
      }<br><br>

      <strong>Total Bruto:</strong> R$ ${totalFinal.toFixed(2)}<br>
      ${desconto > 0 ? `<strong>Desconto:</strong> R$ ${desconto.toFixed(2)}<br>` : ''}
      <strong>Valor Final:</strong> <b style="font-size: 17px;">R$ ${valorComDesconto.toFixed(2)}</b><br>

      <hr style="border: 0; border-top: 1px dashed #ccc; margin-top: 10px; margin-bottom: 10px;">
      <p style="font-size: 14px; text-align: justify;">
        Declaro que recebi o equipamento informado e estou de acordo com os serviços realizados e valores cobrados.
      </p>
      <br><br>
      ___________________________<br>
      <div style="text-align:center; font-size: 13px;">Assinatura do Cliente</div>

      <hr style="border: 0; border-top: 1px dashed #ccc; margin-top: 15px;">
      <div style="text-align:center; font-size: 12px;">Obrigado pela preferência!<br><small>Mundo Tech</small></div>
    </div>
  `;

  try {
    janela.document.open();
    janela.document.write(`
      <html>
      <head><title>Recibo OS ${this.idOsSelecionada || ''}</title></head>
      <body onload="window.print(); setTimeout(function() { window.close(); }, 100);" style="margin:0;">
        ${html}
      </body>
      </html>
    `);
    janela.document.close();
  } catch (e) {
    console.error("Erro ao escrever no documento da janela do recibo:", e);
    alert("Ocorreu um erro ao gerar o conteúdo do recibo.");
    if (janela && !janela.closed) {
      janela.close();
    }
  }
},



    /**
     * Busca os detalhes de uma OS para edição.
     * @param {object} os - O objeto da Ordem de Serviço a ser editada.
     */
    async editarOS(os) {
      try {
        const response = await fetch(`${apiBase}/os/detalhes/${os.idOs}`);
        const res = await response.json();

        if (!res.success || !res.dados) { // Verificação mais robusta dos dados
          alert(res.message || "Erro ao buscar dados da OS para edição.");
          return;
        }

        const dados = res.dados;
        this.edicao = {
          idOs: dados.idOs,
          descricaoProduto: dados.descricaoProduto || '',
          defeito: dados.defeito || '',
          status: dados.status || 'Em Andamento',
          valorTotal: parseFloat(dados.valorTotal) || 0,
          dataInicial: dados.dataInicial || '',
          imei1: dados.imei1 || '',
          imei2: dados.imei2 || '',
          clientes_id: dados.clientes_id || null, // Usar null para IDs ausentes
          usuarios_id: dados.usuarios_id || null, // Usar null para IDs ausentes
          servicos: Array.isArray(dados.servicos) ? dados.servicos.map(s => ({
            servico_id: s.servico_id ?? s.servicos_id ?? null, // Coalescência de nulo para IDs
            nome: s.nome || '',
            valor: parseFloat(s.valor || 0),
            quantidade: parseInt(s.quantidade || 1, 10) // Garantir que quantidade é inteiro
          })) : []
        };

        this.senhaEdicao = '';
        this.erroEdicao = '';
        $('#modalEditarOs').modal('show');
      } catch (err) {
        console.error("Erro na requisição ao buscar detalhes da OS:", err);
        alert("Erro de comunicação ao buscar dados da OS.");
      }
    },

    /**
     * Adiciona um novo item de serviço em branco à lista de serviços da OS em edição.
     */
    adicionarServico() {
      this.edicao.servicos.push({ servico_id: null, nome: '', valor: 0, quantidade: 1 });
    },

    /**
     * Remove um serviço da lista de serviços da OS em edição pelo índice.
     * @param {number} index - O índice do serviço a ser removido.
     */
    removerServico(index) {
      if (index >= 0 && index < this.edicao.servicos.length) {
        this.edicao.servicos.splice(index, 1);
      } else {
        console.warn("Tentativa de remover serviço com índice inválido:", index);
      }
    },

    /**
     * Busca sugestões de serviços com base no termo digitado.
     * @param {number} index - O índice do serviço na lista `this.edicao.servicos` que está sendo editado.
     */
    buscarServico(index) {
      const servicoAtual = this.edicao.servicos[index];
      if (!servicoAtual) return; // Checagem de segurança

      const termo = servicoAtual.nome;
      this.focusedServico = index; // Define o serviço focado para exibir sugestões

      if (!termo || termo.length < 2) { // Não busca com menos de 2 caracteres
        this.sugestoesServicos = [];
        return;
      }

      fetch(`${apiBase}/servicos/buscar?termo=${encodeURIComponent(termo)}`)
        .then(res => {
          if (!res.ok) throw new Error(`Erro HTTP: ${res.status}`);
          return res.json();
        })
        .then(lista => {
          this.sugestoesServicos = Array.isArray(lista) ? lista : [];
        })
        .catch(err => {
          console.error("Erro ao buscar sugestões de serviço:", err);
          this.sugestoesServicos = [];
        });
    },

    /**
     * Seleciona um serviço da lista de sugestões e preenche os dados no item de serviço correspondente.
     * @param {number} index - O índice do serviço na lista `this.edicao.servicos`.
     * @param {object} servico - O objeto do serviço selecionado da lista de sugestões.
     */
    selecionarServico(index, servico) {
      if (!this.edicao.servicos[index] || !servico) return;

      this.edicao.servicos[index].nome = servico.nome;
      this.edicao.servicos[index].valor = parseFloat(servico.preco);
      this.edicao.servicos[index].servico_id = servico.idServicos; // ou o ID correto do serviço
      this.sugestoesServicos = []; // Limpa sugestões
      this.focusedServico = null; // Limpa foco
    },

    /**
     * Salva as alterações feitas na Ordem de Serviço.
     */
    async salvarEdicaoOS() {
      // TODO: Considerar mover senhasValidas para uma configuração mais segura ou para 'data' se apropriado
      const senhaMestre = "Mundo1234"; // Exemplo - idealmente viria de config
      const senhasValidas = ["1234", "teste1", senhaMestre]; // Exemplo

      if (!this.senhaEdicao?.trim()) {
        this.erroEdicao = "Informe a senha do funcionário ou a senha mestre.";
        return;
      }

      // ATENÇÃO: A validação de senha aqui é feita no frontend.
      // Para segurança real, a senha (ou um token derivado dela) deveria ser validada no backend.
      if (!senhasValidas.includes(this.senhaEdicao)) {
        this.erroEdicao = "Senha inválida ou não autorizada.";
        return;
      }

      const servicosValidos = this.edicao.servicos.filter(s => s.servico_id && s.servico_id > 0 && s.nome?.trim() !== '');

      const payload = {
        descricaoProduto: this.edicao.descricaoProduto,
        defeito: this.edicao.defeito,
        status: this.edicao.status,
        valorTotal: parseFloat(this.edicao.valorTotal),
        dataInicial: this.edicao.dataInicial, // Garantir que está no formato esperado pelo backend
        imei1: this.edicao.imei1,
        imei2: this.edicao.imei2,
        clientes_id: this.edicao.clientes_id,
        usuarios_id: this.edicao.usuarios_id,
        servicos: servicosValidos.map(s => ({
          servico_id: s.servico_id,
          quantidade: parseInt(s.quantidade || 1, 10),
          valor: parseFloat(s.valor) || 0
        }))
      };

      console.log("[Payload de Edição Enviado]", JSON.stringify(payload, null, 2));

      try {
        const res = await fetch(`${apiBase}/os/editar/${this.edicao.idOs}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const data = await res.json();
        if (data.success) {
          $('#modalEditarOs').modal('hide');
          this.erroEdicao = '';
          this.carregarOrdens(); // Recarrega a lista de OS
          alert("Ordem de serviço atualizada com sucesso.");
        } else {
          this.erroEdicao = data.message || "Falha ao atualizar OS.";
          console.error("Erro ao salvar edição OS (resposta API):", data);
        }
      } catch (e) {
        this.erroEdicao = "Erro na comunicação com o servidor ao salvar edição.";
        console.error("[ERRO salvarEdicaoOS]", e);
      }
    },

    /**
     * Abre o modal para registrar um retorno técnico para uma OS.
     * @param {object} os - A Ordem de Serviço para a qual o retorno será registrado.
     */
    abrirModalRetorno(os) {
      this.osSelecionada = os;
      this.retornoDescricao = ''; // Limpa o campo de descrição
      this.senhaRetorno = '';     // Limpa o campo de senha
      $('#modalRetorno').modal('show');
    },

    /**
     * Confirma e imprime o termo de retorno técnico.
     */
    confirmarRetorno() {
      const senha = this.senhaRetorno;
      // ATENÇÃO: senhasVendedores deve estar acessível
      const funcionario = senha && senhasVendedores[senha] ? senhasVendedores[senha] : null;

      if (!funcionario) {
        alert("Senha inválida ou funcionário não encontrado.");
        return;
      }

      const os = this.osSelecionada;
      if (!os) {
        alert("Nenhuma OS selecionada para retorno.");
        return;
      }

      const descricaoRetorno = this.retornoDescricao?.trim() || '---';
      const dataHora = new Date();
      const dataHoraFormatada = dataHora.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });

      const entrada = new Date(os.dataInicial);
      const dias = Math.floor((dataHora - entrada) / (1000 * 60 * 60 * 24));

      const texto = `
        <div style="font-family: monospace; width: 280px; margin: 10px auto; font-size: 10px; line-height: 1.5; padding: 15px; border: 1px solid #333;">
            <div style="text-align: center; font-weight: bold; font-size: 14px;">MUNDO TECH</div>
            <div style="text-align: center; font-size: 12px; margin-bottom: 10px;">Retorno Técnico</div>
            <hr style="border: 0; border-top: 1px dashed #000; margin: 8px 0;" />

            <strong>OS Nº:</strong> ${os.idOs}<br>
            <strong>Cliente:</strong> ${this.formatarNome(os.nomeCliente)}<br>
            <strong>Equipamento:</strong><br>${this.limparDescricao(os.descricaoProduto)}<br><br>

            <strong>Entrada Original:</strong> ${this.formatarDataHora(os.dataInicial, false)}<br>
            <strong>Dias decorridos:</strong> ${dias} dia(s)<br><br>

            <strong>Defeito Inicial:</strong><br>
            ${this.limparDescricao(os.defeito || '---')}<br><br>

            <strong>Relato do Cliente (Retorno):</strong><br>
            ${descricaoRetorno}<br><br>

            <strong>Recebido por:</strong> ${funcionario}<br>
            <strong>Data do Retorno:</strong> ${dataHoraFormatada}<br>

            <hr style="border: 0; border-top: 1px dashed #000; margin: 8px 0;" />
            <strong>Observações do Técnico:</strong><br>
            ..................................................<br>
            ..................................................<br>
            ..................................................<br>

            <hr style="border: 0; border-top: 1px dashed #000; margin: 8px 0;" />
            <div style="text-align: center; font-size: 9px;">Obrigado! Analisaremos seu retorno.</div>
        </div>
      `;

      const win = window.open('', '_blank', 'width=320,height=480');
      if (win) {
        win.document.write(`
            <html>
            <head><title>Retorno Técnico OS ${os.idOs}</title></head>
            <body onload="window.print(); setTimeout(function() { window.close(); }, 100);" style="margin: 0;">
                ${texto}
            </body>
            </html>
        `);
        win.document.close();
        win.focus(); // Traz a janela para frente
      } else {
        alert("Não foi possível abrir a janela de impressão. Verifique se o bloqueador de pop-ups está desativado.");
      }
      $('#modalRetorno').modal('hide');
    },

    /**
     * Calcula os dias decorridos desde uma data inicial até hoje.
     * @param {string} dataInicialStr - A data inicial no formato 'YYYY-MM-DD' ou compatível com `new Date()`.
     * @returns {string} String formatada indicando o número de dias.
     */
    calcularDiasDecorridos(dataInicialStr) {
      if (!dataInicialStr) return 'Data inválida';
      const hoje = new Date();
      const inicio = new Date(dataInicialStr);
      if (isNaN(inicio.getTime())) return 'Data inválida';

      const diff = Math.floor((hoje - inicio) / (1000 * 60 * 60 * 24));
      return `${diff} dia(s)`;
    },

    /**
     * Carrega a lista de Ordens de Serviço da API.
     */
    carregarOrdens() {
      console.log('[carregarOrdens] Iniciando busca de OS...');
      this.carregando = true;
      this.erro = null;
      fetch(`${apiBase}/os/listar`)
        .then(response => {
          if (!response.ok) throw new Error(`Erro HTTP: ${response.status}`);
          return response.json();
        })
        .then(data => {
          console.log('[carregarOrdens] Dados recebidos:', data);
          if (Array.isArray(data)) {
            // Padroniza a descrição do produto para cada ordem
            this.ordens = data.map(ordem => ({
              ...ordem,
              descricaoProduto: this.padronizarModelo(ordem.descricaoProduto)
            }));
          } else {
            this.erro = "Erro: formato de dados inválido recebido do servidor.";
            console.error('[carregarOrdens] Formato inválido:', data);
            this.ordens = []; // Limpa as ordens em caso de erro de formato
          }
        })
        .catch(err => {
          console.error('[carregarOrdens] Falha na requisição ou processamento:', err);
          this.erro = `Falha ao carregar ordens: ${err.message}`;
          this.ordens = []; // Limpa as ordens em caso de erro
        })
        .finally(() => {
          this.carregando = false;
        });
    },

    /**
     * Padroniza o nome/modelo do produto, aplicando correções e capitalização.
     * @param {string} modelo - O nome/modelo do produto.
     * @returns {string} O nome/modelo padronizado.
     */
    padronizarModelo(modelo) {
      if (!modelo || typeof modelo !== 'string') return '';
      let modeloLower = modelo.toLowerCase().trim();

      const correcoes = { // Mapeamento de erros comuns para formas corretas
        'positivo twist tab spidey': 'Positivo Twist Tab Spidey',
        'tablet a7 lite t225': 'Tablet A7 Lite T225',
        'caixa de som inova kv-9792': 'Caixa De Som Inova KV-9792',
        'redimi 13 c': 'Redmi 13C',
        'motorola g42nayara': 'Motorola G42 Nayara', // Verificar se "Nayara" é parte do modelo ou anotação
        'moto g9 play / substituição do botão flex (volume + power)': 'Moto G9 Play',
        'samsung a14 / substituição da frontal + conector de carga': 'Samsung A14',
        'moto g8 play / substituição da frontal + conector de carga': 'Moto G8 Play',
        'iphone 11 branco': 'iPhone 11 Branco',
        'apple iphone 11': 'iPhone 11',
        'aphone 11': 'iPhone 11',
        'apple xs': 'iPhone XS',
        'xr': 'iPhone XR',
        'a 53': 'Samsung A53', // Adicionado Samsung para clareza
        'a03 core': 'Samsung A03 Core' // Adicionado Samsung para clareza
      };

      for (const chave in correcoes) {
        if (modeloLower.includes(chave)) {
          // Se uma correção mais específica for encontrada, use-a e retorne
          // Isso evita que substituições genéricas abaixo alterem uma correção específica
          return correcoes[chave];
        }
      }

      // Remove termos descritivos de serviço/peça que podem poluir o nome do modelo
      const palavrasIgnoradas = [
        'substituição', 'conector', 'de', 'carga', 'frontal', 'display',
        'bateria', 'botão', 'flex', 'volume', 'power', 'tela',
        'atendente:', 'atendente', 'retirada', 'analise', 'orçamento',
        'pelicula', 'capa', 'fonte', 'cabo', 'original', 'paralelo',
        'liga', 'não liga', 'desliga', 'touch', 'defeito', 'problema',
        'reparo', 'manutenção', 'placa', 'troca', 'serviço'
      ];

      palavrasIgnoradas.forEach(palavra => {
        // Regex para remover a palavra inteira, com ou sem acentos, e espaços ao redor
        // Usa \b para limites de palavra para evitar remover partes de palavras
        const regex = new RegExp(`\\b${palavra}\\b[\\s/]*`, 'gi');
        modeloLower = modeloLower.replace(regex, '');
      });

      // Remove caracteres especiais que não fazem parte do nome do modelo (exceto números e letras)
      modeloLower = modeloLower.replace(/[^a-z0-9\s\+\-\.]/gi, ' ').trim(); // Mantém +, -, .
      modeloLower = modeloLower.replace(/\s+/g, ' ').trim(); // Remove excesso de espaços

      if (!modeloLower) return 'Modelo Não Especificado';

      // Capitaliza cada palavra do modelo limpo
      return modeloLower
        .split(' ')
        .map(p => p.charAt(0).toUpperCase() + p.slice(1))
        .join(' ');
    },


    /**
     * Solicita a impressão de uma Ordem de Serviço específica.
     * @param {number|string} idOs - O ID da OS a ser impressa.
     */
    imprimir(idOs) {
      fetch(`${apiBase}/os/imprimir-os/${idOs}`)
        .then(res => {
            if (!res.ok) throw new Error(`Erro HTTP ${res.status} ao buscar dados para impressão.`);
            return res.json();
        })
        .then(res => {
          if (res.success && res.html) {
            const printWindow = window.open('', '_blank', 'width=800,height=600');
            if (printWindow) {
                printWindow.document.open();
                printWindow.document.write(res.html);
                printWindow.document.close();
                // Adiciona um pequeno timeout para garantir que o conteúdo foi renderizado antes de imprimir
                printWindow.onload = () => {
                    setTimeout(() => {
                        printWindow.print();
                        // Não fechar automaticamente, permitir que o usuário veja ou salve como PDF
                        // printWindow.close();
                    }, 100); // Ajuste o timeout conforme necessário
                };
            } else {
                alert('Não foi possível abrir a janela de impressão. Verifique o bloqueador de pop-ups.');
            }
          } else {
            alert(res.message || 'Erro ao gerar HTML para impressão.');
            console.error("Erro ao gerar impressão (resposta API):", res);
          }
        })
        .catch(err => {
            alert(`Erro ao acessar API de impressão: ${err.message}`);
            console.error("Erro na API de impressão:", err);
        });
    },

    /**
     * Prepara os dados e abre o modal para faturar uma Ordem de Serviço.
     * @param {object} os - O objeto da Ordem de Serviço a ser faturada.
     */
    faturar(os) {
    if (os.status === 'Faturado') {
        // Buscar dados completos da OS para gerar recibo
        fetch(`${apiBase}/os/detalhes/${os.idOs}`)
        .then(res => res.json())
        .then(res => {
            if (!res.success || !res.dados) {
            alert("Erro ao buscar dados da OS faturada.");
            return;
            }

            const dados = res.dados;

            const reciboWindow = window.open('', '_blank', 'width=350,height=550,scrollbars=yes,resizable=yes');
            if (!reciboWindow) {
            alert("Não foi possível abrir a janela do recibo. Verifique se o navegador está bloqueando pop-ups.");
            return;
            }

            // Preenche os dados corretos
            this.idOsSelecionada = dados.idOs;
            this.pagamentoDescricao = `Fatura de OS Nº: ${dados.idOs}`;
            this.pagamentoCliente = dados.nomeCliente;
            this.pagamentoValor = parseFloat(dados.valorTotal) || 0;
            this.pagamentoDesconto = parseFloat(dados.valor_desconto) || 0;
            this.pagamentoDataEntrada = dados.dataInicial || '';
            this.pagamentoDataRecebimento = dados.data_faturamento || this.getDataHoraLocal();
            this.senhaFaturamento = ''; // não há necessidade aqui

            // Preenche nome do funcionário a partir do backend
            const nomeFuncionario = dados.faturado_por_nome || 'N/A';
            this.pagamentosLista = Array.isArray(dados.pagamentos)
            ? dados.pagamentos.map(p => ({
                forma: p.forma_pgto,
                valor: parseFloat(p.valor)
                }))
            : [];

            // opcionalmente definir um campo auxiliar se quiser usar no recibo:
            this._nomeFuncionarioFaturou = nomeFuncionario;

            this.gerarRecibo(reciboWindow);
        })
        .catch(err => {
            console.error("Erro ao buscar detalhes da OS faturada:", err);
            alert("Erro ao carregar dados para gerar o recibo.");
        });

        return;
    }

    // Se não estiver faturada, abre o modal de faturamento normalmente
    this.pagamentoDescricao = `Fatura de OS Nº: ${os.idOs}`;
    this.pagamentoCliente = os.nomeCliente;
    this.pagamentoValor = parseFloat(os.valorTotal) || 0;
    this.pagamentoDesconto = parseFloat(os.valor_desconto) || 0;
    this.pagamentoDataEntrada = os.dataInicial || '';
    this.pagamentoDataRecebimento = os.dataFinal || this.getDataHoraLocal();
    this.pagamentosLista = [];
    this.idOsSelecionada = os.idOs;
    this.senhaFaturamento = '';
    this.faturarModalVisible = true;
    this.$nextTick(() => $('#faturarModal').modal('show'));
    },

    /**
     * Adiciona uma forma de pagamento à lista de pagamentos da OS.
     */
    adicionarPagamento() {
      const valorPagamento = parseFloat(this.pagamentoValor); // Referencia o valor do campo de valor do pagamento, não o total da OS
      if (!this.pagamentoFormaAtual || !valorPagamento || valorPagamento <= 0) {
        alert("Selecione uma forma de pagamento e informe um valor válido.");
        return;
      }
      this.pagamentosLista.push({
        forma: this.pagamentoFormaAtual,
        valor: valorPagamento // Usar o valor específico para esta forma de pagamento
      });
      // Opcional: Limpar campos após adicionar
      // this.pagamentoFormaAtual = '';
      // this.pagamentoValor = 0; // Se tiver um campo separado para valor do pagamento parcial
    },

    /**
     * Remove um pagamento da lista de pagamentos pelo índice.
     * @param {number} index - O índice do pagamento a ser removido.
     */
    removerPagamento(index) {
      if (index >= 0 && index < this.pagamentosLista.length) {
        this.pagamentosLista.splice(index, 1);
      }
    },

faturarConfirmado() {
  // ATENÇÃO: senhasVendedores deve estar acessível
  if (!this.senhaFaturamento || !(this.senhaFaturamento in senhasVendedores)) {
    alert('Senha incorreta ou funcionário não autorizado! Ação não permitida.');
    return;
  }

  const reciboWindow = window.open('', '_blank', 'width=350,height=550,scrollbars=yes,resizable=yes');
  if (!reciboWindow) {
    alert("Não foi possível abrir a janela para o recibo. Verifique se o seu navegador está bloqueando pop-ups.");
    return;
  }

  reciboWindow.document.write('<html><head><title>Gerando Recibo...</title></head><body><p>Por favor, aguarde enquanto o recibo é gerado...</p></body></html>');
  reciboWindow.document.close();

  const funcionarioNome = senhasVendedores[this.senhaFaturamento];
  const dataHoraFaturamento = this.getDataHoraLocal();

  const payload = {
    pagamentos: this.pagamentosLista,
    funcionarioFaturamento: funcionarioNome,
    dataHoraFaturamento: dataHoraFaturamento,
    valor_total_pago: parseFloat(this.pagamentoValor) || 0,
    valor_desconto_aplicado: this.pagamentoDesconto
  };

  this.faturando = true;

  fetch(`${apiBase}/faturar/${this.idOsSelecionada}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  .then(res => {
    if (!res.ok) {
      return res.json().then(errData => {
        throw new Error(errData.message || `Erro HTTP: ${res.status}`);
      }).catch(() => {
        throw new Error(`Erro HTTP: ${res.status}`);
      });
    }
    return res.json();
  })
  .then(res => {
    if (res.success) {
      alert('OS faturada com sucesso!');
      
      // Preenche temporariamente os dados para gerar o recibo
      this._nomeFuncionarioFaturou = funcionarioNome;
      this.pagamentoDataRecebimento = dataHoraFaturamento.substring(0, 10);

      // Gera recibo com os dados ainda disponíveis
      this.gerarRecibo(reciboWindow);

      // Só limpa os dados DEPOIS de imprimir
      this.fecharModalFaturar();
      this.carregarOrdens();
    } else {
      alert(res.message || 'Erro ao faturar OS. Resposta do servidor não indicou sucesso.');
      if (reciboWindow && !reciboWindow.closed) {
        reciboWindow.close();
      }
    }
  })
  .catch(err => {
    alert(`Erro na comunicação ou processamento do faturamento: ${err.message}`);
    console.error("Erro ao faturar OS:", err);
    if (reciboWindow && !reciboWindow.closed) {
      reciboWindow.close();
    }
  })
  .finally(() => {
    this.faturando = false;
  });
},

    /**
     * Abre o modal para registrar a retirada de um equipamento.
     * @param {object} os - A Ordem de Serviço do equipamento a ser retirado.
     */
    abrirTermoRetirada(os) {
      this.osSelecionada = os;
      this.retiradaNome = '';
      this.retiradaDocumento = '';
      this.senhaRetirada = '';
      this.erroRetirada = '';
      this.retiradaModalVisible = true;
      this.$nextTick(() => $('#retiradaModal').modal('show'));
    },

    /**
     * Confirma o registro da retirada e imprime o termo de autorização.
     */
    confirmarRetirada() {
      // ATENÇÃO: senhasVendedores deve estar acessível
      if (!this.senhaRetirada || !(this.senhaRetirada in senhasVendedores)) {
        this.erroRetirada = "Senha incorreta! Ação não autorizada.";
        return;
      }

      if (!this.retiradaNome?.trim() || !this.retiradaDocumento?.trim()) {
        this.erroRetirada = "Preencha o nome e o documento de quem está retirando.";
        return;
      }

      const nomeFuncionario = senhasVendedores[this.senhaRetirada];
      const payload = {
        nomeRetirante: this.retiradaNome,
        docRetirante: this.retiradaDocumento,
        // 'retirado_por_id' talvez deva ser o ID do funcionário que autorizou,
        // ou um ID fixo se não houver login de funcionário. Verificar lógica do backend.
        retirado_por_id: 1, // Exemplo, verificar qual ID usar
        autorizou: nomeFuncionario, // Nome do funcionário que autorizou com a senha
        dataHoraRetirada: this.getDataHoraLocal() // Adicionando data/hora da retirada
      };

      const idAtual = this.osSelecionada?.idOs;
      if (!idAtual) {
        this.erroRetirada = "ID da OS inválido ou OS não selecionada.";
        return;
      }

      fetch(`${apiBase}/os/registrar-retirada/${idAtual}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      .then(res => {
        if (!res.ok) throw new Error(res.statusText || `Erro HTTP ${res.status}`);
        return res.json();
      })
      .then(res => {
        if (res.success) {
          this.fecharModalRetirada();
          this.carregarOrdens(); // Recarrega a lista para atualizar status
          // Abre o termo de retirada em uma nova aba após um pequeno delay
          setTimeout(() => {
            const termoWindow = window.open(`${apiBase}/os/imprimir-autorizacao-retirada/${idAtual}`, '_blank');
            if(!termoWindow){
                alert("Não foi possível abrir o termo de retirada. Verifique o bloqueador de pop-ups.");
            }
          }, 300);
          alert("Retirada registrada com sucesso!");
        } else {
          this.erroRetirada = res.message || "Erro ao registrar retirada no servidor.";
          console.error("Erro ao registrar retirada (resposta API):", res);
        }
      })
      .catch(err => {
        this.erroRetirada = `Erro de comunicação ao registrar retirada: ${err.message}`;
        console.error("Erro na API ao registrar retirada:", err);
      });
    },

    /**
     * Cancela uma Ordem de Serviço.
     * @param {number|string} idOs - O ID da OS a ser cancelada.
     */
    cancelar(idOs) {
      if (!confirm(`Tem certeza que deseja cancelar a OS Nº ${idOs}? Esta ação não pode ser desfeita.`)) return;

      // Opcional: Pedir senha para cancelamento, similar ao faturamento/retirada
      // const senhaCancelamento = prompt("Digite a senha de administrador para cancelar:");
      // if (!senhaCancelamento || !senhasVendedores[senhaCancelamento]) { // ou uma senha mestre específica
      //    alert("Senha inválida ou cancelamento não autorizado.");
      //    return;
      // }

      fetch(`${apiBase}/os/cancelar/${idOs}`, {
         method: 'POST', // Ou PUT/PATCH dependendo da API RESTful design
         // headers: { 'Authorization': `Bearer ${token}` } // Se usar autenticação
      })
      .then(res => {
        if (!res.ok) throw new Error(`Erro ${res.status} ao cancelar OS.`);
        return res.json();
      })
      .then(data => {
        if (data.success) {
          alert(`OS Nº ${idOs} cancelada com sucesso.`);
          this.carregarOrdens(); // Recarrega a lista para refletir a mudança de status
        } else {
          alert(data.message || 'Erro ao cancelar OS no servidor.');
          console.error("Erro ao cancelar OS (resposta API):", data);
        }
      })
      .catch(err => {
        alert(`Erro de comunicação ao tentar cancelar OS: ${err.message}`);
        console.error("Erro na API ao cancelar OS:", err);
      });
    },

    // Métodos para fechar modais e limpar dados relacionados
    fecharModalRetirada() {
      $('#retiradaModal').modal('hide');
      this.retiradaModalVisible = false;
      this.retiradaNome = '';
      this.retiradaDocumento = '';
      this.senhaRetirada = '';
      this.erroRetirada = '';
      this.osSelecionada = null; // Limpa a OS selecionada
    },

    fecharModalFaturar() {
      $('#faturarModal').modal('hide');
      this.faturarModalVisible = false;
      this.pagamentoDescricao = '';
      this.pagamentoCliente = '';
      this.pagamentoValor = 0;
      this.pagamentoDesconto = 0;
      this.pagamentoDataEntrada = '';
      this.pagamentoDataRecebimento = '';
      this.pagamentoFormaAtual = '';
      this.pagamentosLista = [];
      this.idOsSelecionada = null;
      this.senhaFaturamento = '';
      this._nomeFuncionarioFaturou = null; // <- limpa o nome do funcionário
    },

    // Funções utilitárias de formatação
    /**
     * Formata um nome para ter a primeira letra de cada palavra em maiúsculo.
     * @param {string} nome - O nome a ser formatado.
     * @returns {string} O nome formatado.
     */
    formatarNome(nome) {
      if (!nome || typeof nome !== 'string') return '';
      return nome.toLowerCase().split(' ').map(p => p.charAt(0).toUpperCase() + p.slice(1)).join(' ');
    },

    /**
     * Remove tags HTML de uma string, retornando apenas o texto.
     * @param {string} html - A string HTML.
     * @returns {string} O texto extraído.
     */
    limparDescricao(html) {
      if (!html || typeof html !== 'string') return '';
      const div = document.createElement("div");
      div.innerHTML = html;
      return div.textContent || div.innerText || '';
    },

    /**
     * Formata uma string de data 'YYYY-MM-DD...' para 'DD/MM/YYYY'.
     * @param {string} dataStr - A string de data (pode conter hora, mas será ignorada).
     * @returns {string} A data formatada ou '-' se inválida.
     */
    formatarData(dataStr) {
      if (!dataStr) return '-';
      // Tenta extrair apenas a parte da data, caso venha com hora
      const dataApenas = dataStr.substring(0,10);
      const partes = dataApenas.split("-");
      if (partes.length === 3) {
        const [ano, mes, dia] = partes;
        if (ano && mes && dia && ano.length === 4) { // Validação básica
            return `${dia}/${mes}/${ano}`;
        }
      }
      return '-'; // Retorna padrão se o formato não for o esperado
    },

    /**
     * Formata uma string de data e hora para 'DD/MM/YYYY HH:MM'.
     * @param {string} dataStr - A string de data e hora (ex: 'YYYY-MM-DD HH:MM:SS').
     * @param {boolean} [aplicarFuso=true] - Se deve aplicar um ajuste de fuso horário (-3 horas).
     * @returns {string} A data e hora formatada ou '---' se inválida.
     */
    formatarDataHora(dataStr, aplicarFuso = true) {
      if (!dataStr || dataStr === '0000-00-00 00:00:00') return '---';

      const dataISO = dataStr.includes('T') ? dataStr : dataStr.replace(' ', 'T');
      const data = new Date(dataISO);

      if (isNaN(data.getTime()) || data.getFullYear() < 1971) {
        return typeof dataStr === 'string' && dataStr.length >= 10
          ? this.formatarData(dataStr.substring(0, 10)) + (dataStr.length > 10 ? dataStr.substring(10) : '')
          : '---';
      }

      const temFusoNaString = /([\+\-]\d{2}:\d{2}|Z)$/i.test(dataStr);
      if (aplicarFuso && !temFusoNaString) {
        data.setHours(data.getHours() - 3);
      }

      const dia = String(data.getDate()).padStart(2, '0');
      const mes = String(data.getMonth() + 1).padStart(2, '0');
      const ano = data.getFullYear();
      const hora = String(data.getHours()).padStart(2, '0');
      const min = String(data.getMinutes()).padStart(2, '0');

      return `${dia}/${mes}/${ano} ${hora}:${min}`;
    },

    formatarDataHoraMais3(dataStr) {
    if (!dataStr || dataStr === '0000-00-00 00:00:00') return '---';

    const dataISO = dataStr.includes('T') ? dataStr : dataStr.replace(' ', 'T');
    const data = new Date(dataISO);

    if (isNaN(data.getTime()) || data.getFullYear() < 1971) return '---';

    // ✅ SOMA +3 HORAS
    data.setHours(data.getHours() + 3);

    const dia = String(data.getDate()).padStart(2, '0');
    const mes = String(data.getMonth() + 1).padStart(2, '0');
    const ano = data.getFullYear();
    const hora = String(data.getHours()).padStart(2, '0');
    const min = String(data.getMinutes()).padStart(2, '0');

    return `${dia}/${mes}/${ano} ${hora}:${min}`;
  },

    /**
     * Formata um valor numérico como moeda brasileira (BRL).
     * @param {number|string} valor - O valor a ser formatado.
     * @returns {string} O valor formatado como moeda.
     */
    formatarMoeda(valor) {
      const num = parseFloat(valor);
      return isNaN(num) ? 'R$ 0,00' : num.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    },

    /**
     * Retorna uma classe CSS de "badge" com base no status da OS.
     * @param {string} status - O status da Ordem de Serviço.
     * @returns {string} A classe CSS correspondente.
     */
    statusClasse(status) {
      switch (status) {
        case 'Faturado': return 'badge badge-success';
        case 'Cancelado': return 'badge badge-danger';
        case 'Em Andamento': return 'badge badge-warning'; // Pode ser 'Em Análise', 'Aguardando Peça' etc.
        case 'Orçamento': return 'badge badge-info'; // Mudado para 'info' para diferenciar de 'warning'
        case 'Concluído': return 'badge badge-primary'; // Exemplo de outro status
        case 'Aguardando Retirada': return 'badge badge-dark'; // Exemplo
        default: return 'badge badge-light'; // Status desconhecido ou padrão
      }
    }
  },
  /**
   * Hook `mounted`: Chamado após a instância Vue ter sido montada no DOM.
   * Ideal para buscar dados iniciais.
   */
  mounted() {
    console.log('[Vue Mounted] Aplicativo de Lista de OS inicializado.');
    this.carregarOrdens(); // Carrega as ordens de serviço ao iniciar o componente
  }
});