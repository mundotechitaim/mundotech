/**
 * ui-interactions.js
 *
 * Gerencia as interações da interface do usuário (UI), como navegação,
 * modais, busca, galeria, e manipulação de eventos.
 * Coordena chamadas para funções de lógica de negócios (como as de estoque-alertas.js e app-loja3.js).
 *
 * Depende de:
 * - DOM HTML com IDs e classes específicas (conforme index.html ajustado).
 * - Funções Globais Expostas por outros scripts:
 * - De estoque-alertas.js: copiarMensagemGlobalComSenha, resolverAlertaLocal, toggleAlertasEstoque,
 * exibirAlertasPersistentes, alertasPersistentes (variável global)
 * - De app-loja3.js: adicionarCarrinho, removerItem, alterarEstoque, registrarPerda,
 * abrirGaleria, anteriorGaleria, proximaGaleria, iniciarTransferenciaEstoque (ou similar),
 * buscarProdutos, enviarVenda, gerarPDFRecibo
 * - De config.js: shopCode, lojaAtual, fetchComToken (usadas em buscarSugestoes)
 */

document.addEventListener('DOMContentLoaded', () => {
    console.log("[ui-interactions.js] DOM carregado. Inicializando UI...");

    // --- Seletores de Elementos do DOM ---
    // Seletores principais da estrutura
    const menuTopo = document.querySelector('.menu-topo');
    const pageContainer = document.querySelector('.page-container');
    const pages = document.querySelectorAll('.page');
    const contadorAlertasSpan = document.getElementById('contadorAlertas');

    // Busca
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    const sugestoesDiv = document.getElementById('sugestoes');

    // Vendas e Carrinho
    const resultDiv = document.getElementById('result'); // Container dos resultados da busca
    const carrinhoDiv = document.getElementById('carrinho'); // Container dos itens do carrinho
    const painelCapinhasDiv = document.getElementById('painelCapinhas'); // Container do painel de transferências

    // Alertas (Dentro da #pagina-alertas)
    const alertasEstoqueListagemDiv = document.getElementById('alertasEstoqueListagem'); // Lista detalhada
    const alertasEstoqueMinimoDiv = document.getElementById('alertasEstoqueMinimo');   // Seção de alertas locais

    // Recibo
    const reciboVendaDiv = document.getElementById('reciboVenda');
    const reciboConteudoDiv = document.getElementById('reciboConteudo');
    const btnGerarPDF = document.getElementById('btnGerarPDF');
    const btnImprimirRecibo = document.getElementById('btnImprimirRecibo');
    const btnFecharRecibo = document.getElementById('btnFecharRecibo');

    // Modal Finalizar Venda
    const modalFinalizar = document.getElementById('modalFinalizar');
    const formaPagamentoSelect = document.getElementById('formaPagamento');
    const valorRecebidoInput = document.getElementById('valorRecebido');
    const valorTrocoDiv = document.getElementById('valorTroco');
    const btnConfirmarVenda = document.getElementById('btnConfirmarVenda');
    const btnCancelarVenda = document.getElementById('btnCancelarVenda');
    const btnAbrirModalFinalizar = document.getElementById('btnAbrirModalFinalizar');

    // Modal Imagem Simples
    const modalImagem = document.getElementById('modalImagem');
    const imagemModalExibida = document.getElementById('imagemModalExibida');
    const btnFecharModalImagem = document.getElementById('btnFecharModalImagem');

    // Modal Galeria
    const modalGaleria = document.getElementById('modalGaleria');
    const imagemAtualGaleria = document.getElementById('imagemAtualGaleria');
    const nomeProdutoGaleria = document.getElementById('nomeProdutoGaleria');
    const btnFecharGaleria = document.getElementById('btnFecharGaleria');
    const btnAnteriorGaleria = document.getElementById('btnAnteriorGaleria');
    const btnProximaGaleria = document.getElementById('btnProximaGaleria');
    const botaoTransferirEstoque = document.getElementById('botaoTransferirEstoque');

    // --- Estado da UI ---
    let zoomAtivo = false;

    // --- Funções de Interação da UI ---

    // Torna as funções modais globais para que outros scripts possam chamá-las
    window.openModal = function(modalElement) {
        if (modalElement) {
            console.log("[UI] Abrindo modal:", modalElement.id);
            modalElement.classList.add('active');
            modalElement.style.display = 'block'; // <-- ADICIONE ISSO
            const firstInput = modalElement.querySelector('input, select, textarea, button');
            if (firstInput) setTimeout(() => firstInput.focus(), 50);
        } else {
            console.warn("[UI] Tentativa de abrir modal nulo ou não encontrado.");
        }
    };
    
    
    window.closeModal = function(modalElement) {
        if (modalElement) {
            console.log("[UI] Fechando modal:", modalElement.id);
            modalElement.classList.remove('active');
            modalElement.style.display = 'none'; // <-- ADICIONE ISSO TAMBÉM
        } else {
            console.warn("[UI] Tentativa de fechar modal nulo ou não encontrado.");
        }
    };
    

/**
 * Alterna a visibilidade das páginas principais da aplicação.
 * @param {string} paginaId ID da página a ser mostrada (sem o prefixo 'pagina-').
 */
function irParaPagina(paginaId) {
    console.debug(`[UI] Navegando para página: ${paginaId}`);

    // Mostra a página correta e esconde as demais
    pages.forEach(page => {
        page.classList.toggle('active', page.id === `pagina-${paginaId}`);
    });

    // Lógica ao entrar na página de Alertas
    if (paginaId === 'alertas') {
        if (typeof window.exibirPainelDeAlertas === 'function') {
            window.exibirPainelDeAlertas();
        } else {
            console.warn("[UI] Função global window.exibirPainelDeAlertas não encontrada.");
        }

        // ATUALIZADO AQUI:
        if (window.estoqueAlertas && typeof window.estoqueAlertas.exibirAlertas === 'function') {
            window.estoqueAlertas.exibirAlertas();
        } else {
            console.warn("[UI] Função window.estoqueAlertas.exibirAlertas não encontrada.");
        }
    }

    // Lógica ao entrar na página de Pendências de OS
    if (paginaId === 'os-alertas') {
        if (typeof window.carregarAlertasOS === 'function') {
            window.carregarAlertasOS();
        } else {
            console.warn("[UI] Função global carregarAlertasOS não encontrada.");
        }
    }
    // Adicione outras páginas se necessário
}


/**
 * Atualiza o contador de alertas no menu superior.
 * (Exposta globalmente para ser chamada por estoque-alertas.js).
 */
window.atualizarContadorAlertasUI = function() {
    try {
        // ATUALIZADO AQUI:
        if (window.estoqueAlertas && typeof window.estoqueAlertas.getAlertasLocaisAtivos === 'function') {
            const alertasLocais = window.estoqueAlertas.getAlertasLocaisAtivos();
            const total = Object.keys(alertasLocais || {}).length;
            console.debug(`[UI] Atualizando contador de alertas para: ${total}`);
            if (contadorAlertasSpan) {
                contadorAlertasSpan.innerText = total;
                contadorAlertasSpan.style.display = total > 0 ? 'inline-block' : 'none';
            } else {
                console.warn("[UI] Span do contador de alertas (contadorAlertasSpan) não encontrado no DOM.");
            }
        } else {
            console.warn("[UI] Interface window.estoqueAlertas.getAlertasLocaisAtivos não encontrada para atualizar contador.");
            if (contadorAlertasSpan) {
                contadorAlertasSpan.innerText = '?';
                contadorAlertasSpan.style.display = 'inline-block';
            }
        }
    } catch (e) {
        console.error("[UI] Erro ao acessar alertas para contador:", e);
        if (contadorAlertasSpan) {
            contadorAlertasSpan.innerText = 'E';
            contadorAlertasSpan.style.display = 'inline-block';
        }
    }
}

    /**
     * Exibe o painel com a LISTA DETALHADA de alertas na página '#pagina-alertas'.
     * Preenche a div '#alertasEstoqueListagemDiv'.
     * (Exposta globalmente para ser chamada por estoque-alertas.js).
     */
    window.exibirPainelDeAlertas = function() {
        if (!alertasEstoqueListagemDiv) {
            console.warn("[UI] Elemento #alertasEstoqueListagemDiv não encontrado.");
            return;
        }
    
        // Remove todo o conteúdo porque vamos deixar vazio
        alertasEstoqueListagemDiv.innerHTML = '';
    
        console.log("[UI] Lista Detalhada de Alertas foi desativada e está oculta.");
    };
    
    
    /**
     * Lógica de busca de sugestões ao digitar no input.
     */
    async function buscarSugestoes() {
         if (!searchInput || !sugestoesDiv) return;
        const termo = searchInput.value.trim().toLowerCase().normalize("NFD").replace(/\u0300-\u036f/g, '');

        if (termo.length < 2) {
            sugestoesDiv.innerHTML = ""; sugestoesDiv.style.display = 'none'; return;
        }

        console.debug(`[UI] Buscando sugestões para: "${termo}"`);
        sugestoesDiv.innerHTML = `<div class="sugestao-loading">Buscando...</div>`;
        sugestoesDiv.style.display = 'block';

        try {
            if (typeof shopCode === 'undefined' || typeof lojaAtual === 'undefined' || typeof fetchComToken !== 'function') {
                 throw new Error("'shopCode', 'lojaAtual' ou 'fetchComToken' não definidos.");
            }
            const url = `https://api.web.nextar.com.br/api/v1/product/${shopCode}?page=0&size=10&sort=description&direction=asc&pdv=false&filter=active&search=${encodeURIComponent(termo)}`;
            const resposta = await fetchComToken(url);
            if (!resposta.ok) throw new Error(`API respondeu com status ${resposta.status}`);
            const dados = await resposta.json();
            const lojaAtualNorm = lojaAtual.toLowerCase();

            const encontrados = (dados.content || []).filter(p =>
                (p.current_stock ?? 0) > 0 &&
                (p.category?.description || '').toLowerCase().includes(lojaAtualNorm)
            );

            if (encontrados.length === 0) {
                 sugestoesDiv.innerHTML = `<div class="sugestao-vazia">Nenhum produto encontrado para "${termo}".</div>`; return;
            }

            sugestoesDiv.innerHTML = encontrados.map(p => {
                const img = p.photos?.[0]?.url || 'img/placeholder.png';
                const estoque = p.current_stock ?? 0;
                const escapedDescription = p.description.replace(/'/g, "\\'").replace(/"/g, "&quot;");
                return `
                    <div class="suggestion-item" data-description="${escapedDescription}" style="/* Estilos inline mantidos para exemplo */ display:flex; align-items:center; padding:6px 10px; cursor:pointer; border-bottom:1px solid #eee;">
                        <img src="${img}" alt="" style="width:32px; height:32px; object-fit:contain; margin-right:10px; border-radius:4px; border: 1px solid #eee;">
                        <div><strong>${p.description}</strong><br><small>Estoque: ${estoque}</small></div>
                    </div>`;
            }).join('');

        } catch (erro) {
            console.error("[UI] Erro ao buscar sugestões:", erro);
            sugestoesDiv.innerHTML = `<div class="sugestao-erro">Erro ao buscar (${erro.message}).</div>`;
        }
    }

    /**
     * Processa a seleção de uma sugestão da lista.
     */
    function selecionarSugestao(texto) {
        console.log(`[UI] Sugestão selecionada: ${texto}`);
        const termoBusca = texto; // Usar o texto exato da sugestão para a busca principal
        if (searchInput) searchInput.value = termoBusca;
        if (sugestoesDiv) { sugestoesDiv.innerHTML = ""; sugestoesDiv.style.display = 'none'; }

        if (typeof buscarProdutos === 'function') { // Função de app-loja3.js
            buscarProdutos(termoBusca);
        } else { console.warn('[UI] Função global buscarProdutos() não encontrada.'); }
    }

    /** Calcula e exibe o troco no modal de finalizar venda. */
    function atualizarTroco() {
        if (!valorRecebidoInput || !valorTrocoDiv) return;
        const totalCarrinhoElement = document.querySelector('#carrinhoSidebar .total-carrinho strong');
        let totalVenda = 0;
        if (totalCarrinhoElement) { totalVenda = parseFloat(totalCarrinhoElement.textContent?.replace(/[^0-9,.]/g, '').replace(',', '.')) || 0; }
        else { console.warn("[UI] Elemento total do carrinho não encontrado."); }

        const recebido = parseFloat(valorRecebidoInput.value) || 0;
        const troco = recebido - totalVenda;

        if (recebido <= 0) { valorTrocoDiv.innerHTML = ''; }
        else if (troco < 0) { valorTrocoDiv.innerHTML = `<span style="color: red;">Faltam: R$ ${Math.abs(troco).toFixed(2)}</span>`; }
        else { valorTrocoDiv.innerHTML = `Troco: R$ ${troco.toFixed(2)}`; }
    }

    /** Abre o modal de imagem simples com a URL fornecida. */
    function abrirModalImagemSimples(imageUrl) {
        const modalImagem = document.getElementById('imagemModal');  // PEGA O MODAL CORRETO
        const imagemModalExibida = document.getElementById('imagemModalSrc');

        if (modalImagem && imagemModalExibida) {
            imagemModalExibida.src = imageUrl || 'img/placeholder.png';
            imagemModalExibida.alt = "Imagem ampliada";
            
            // Atualizar link de download também
            const btnDownload = document.getElementById('btnDownloadImagem');
            if (btnDownload) {
                btnDownload.href = imageUrl || '#';
            }

            // Usando Bootstrap para abrir:
            var myModal = new bootstrap.Modal(modalImagem);
            myModal.show();
        }
    }


    /** Fecha o modal de imagem simples (chamada pelo listener). */
    function fecharModalImagem() {
         console.debug("[UI] Fechando modal de imagem simples.");
         closeModal(modalImagem); // Fecha usando a classe 'active'
    }

    /** Fecha o modal da galeria e reseta o zoom (chamada pelo listener). */
    function fecharGaleria() {
        console.debug("[UI] Fechando modal da galeria.");
        closeModal(modalGaleria);
        zoomAtivo = false;
        if (imagemAtualGaleria) imagemAtualGaleria.classList.remove('zoomed');
    }

    /** Alterna o zoom na imagem da galeria. */
    function toggleZoom() {
        if (!imagemAtualGaleria) return;
        zoomAtivo = !zoomAtivo;
        imagemAtualGaleria.classList.toggle('zoomed', zoomAtivo);
        imagemAtualGaleria.style.cursor = zoomAtivo ? 'zoom-out' : 'zoom-in';
    }


    // --- Event Listeners ---

    // Navegação Principal
    if (menuTopo) {
        menuTopo.addEventListener('click', (event) => {
            const button = event.target.closest('button[data-page]');
            if (button?.dataset?.page) irParaPagina(button.dataset.page);
        });
    }

    // Busca e Sugestões
    if (searchInput) {
        searchInput.addEventListener('input', buscarSugestoes); // Considerar debounce aqui
        searchInput.addEventListener('keydown', (e) => {
            if (e.key === "Enter") {
                e.preventDefault();
                if (sugestoesDiv) { sugestoesDiv.innerHTML = ""; sugestoesDiv.style.display = 'none'; }
                if (typeof buscarProdutos === 'function') buscarProdutos(searchInput.value);
                else console.warn('[UI] Função global buscarProdutos() não encontrada.');
            }
        });
    }
    if (sugestoesDiv) { // Listener para clique em sugestão
        sugestoesDiv.addEventListener('click', (event) => {
            const item = event.target.closest('.suggestion-item[data-description]');
            if (item?.dataset?.description) selecionarSugestao(item.dataset.description);
        });
     }
    document.addEventListener('click', (event) => { // Fechar sugestões ao clicar fora
        if (sugestoesDiv && searchInput && !sugestoesDiv.contains(event.target) && event.target !== searchInput && sugestoesDiv.style.display !== 'none') {
            sugestoesDiv.innerHTML = ""; sugestoesDiv.style.display = 'none';
        }
    });

    // Ações na Seção de Alertas Locais (#alertasEstoqueMinimoDiv)
    if (alertasEstoqueMinimoDiv) {
        alertasEstoqueMinimoDiv.addEventListener('click', (event) => {
            const trigger = event.target.closest('button[data-action], span[data-action="toggle-alertas"]');
            if (!trigger?.dataset?.action) return;

            const action = trigger.dataset.action;
            const alertaId = trigger.dataset.alertaId;
            const alertaJson = trigger.dataset.alerta;
            console.log(`[UI] Ação SEÇÃO ALERTAS LOCAIS: ${action}`);

            try {
                if (action === 'copiar-global' && alertaJson) {
                    const alerta = JSON.parse(alertaJson.replace(/&quot;/g, '"'));
                    if (typeof copiarMensagemGlobalComSenha === 'function') copiarMensagemGlobalComSenha(alerta);
                    else console.warn("Função global copiarMensagemGlobalComSenha não encontrada.");
                } else if (action === 'resolver-local' && alertaId) {
                    if (typeof resolverAlertaLocal === 'function') resolverAlertaLocal(alertaId);
                    else console.warn("Função global resolverAlertaLocal não encontrada.");
                } else if (action === 'toggle-alertas') {
                    if (typeof toggleAlertasEstoque === 'function') toggleAlertasEstoque();
                    else console.warn("Função global toggleAlertasEstoque não encontrada.");
                }
            } catch (e) { console.error(`[UI] Erro ao processar ação ${action} (alertas locais):`, e); }
        });
    }

    // Ações na Lista Detalhada de Alertas (#alertasEstoqueListagemDiv)
     if (alertasEstoqueListagemDiv) {
         alertasEstoqueListagemDiv.addEventListener('click', (event) => {
             const button = event.target.closest('button[data-action]');
             if (!button?.dataset?.action) return;

             const action = button.dataset.action;
             const alertaId = button.dataset.alertaId;
             const alertaJson = button.dataset.alerta;
             console.log(`[UI] Ação LISTA ALERTAS: ${action}`);

              try {
                 if (action === 'copiar-global' && alertaJson) {
                     const alerta = JSON.parse(alertaJson.replace(/&quot;/g, '"'));
                     if (typeof copiarMensagemGlobalComSenha === 'function') copiarMensagemGlobalComSenha(alerta);
                     else console.warn("Função global copiarMensagemGlobalComSenha não encontrada.");
                 } else if (action === 'resolver-local' && alertaId) {
                      if (typeof resolverAlertaLocal === 'function') resolverAlertaLocal(alertaId);
                      else console.warn("Função global resolverAlertaLocal não encontrada.");
                 }
             } catch (e) { console.error(`[UI] Erro ao processar ação ${action} (lista alertas):`, e); }
         });
     }

    // Ações nos Resultados da Busca (#resultDiv) - Delegação
    if (resultDiv) {
        resultDiv.addEventListener('click', (event) => {
            const button = event.target.closest('button[data-action]');
            if (!button?.dataset?.action) return; // Sai se não for um botão de ação

            const action = button.dataset.action;
            const produtoJson = button.dataset.produto;
            const imageUrl = button.dataset.url; // Para ação 'ver-foto'
            console.log(`[UI] Ação RESULTADOS BUSCA: ${action}`);

            let produto = null;
            if (produtoJson) {
                try {
                    produto = JSON.parse(produtoJson.replace(/&quot;/g, '"'));
                } catch (e) {
                    console.error("[UI] Erro ao parsear JSON do produto:", e);
                    alert("Erro ao processar dados do produto.");
                    return;
                }
            }

            switch (action) {
                case 'adicionar-carrinho':
                    if (produto && typeof adicionarCarrinho === 'function') adicionarCarrinho(produto);
                    else console.warn("Função global adicionarCarrinho ou produto inválido.");
                    break;
                case 'ver-foto':
                    if (imageUrl) abrirModalImagemSimples(imageUrl);
                    else console.warn("URL da imagem não encontrada para ação ver-foto.");
                    break;
                case 'registrar-perda':
                    if (produto && typeof registrarPerda === 'function') registrarPerda(produto);
                    else console.warn("Função global registrarPerda ou produto inválido.");
                    break;
                case 'alterar-estoque':
                    if (produto && typeof alterarEstoque === 'function') alterarEstoque(produto);
                    else console.warn("Função global alterarEstoque ou produto inválido.");
                    break;
                default:
                    console.warn(`[UI] Ação desconhecida nos resultados: ${action}`);
            }
        });
    }

    // Ações no Carrinho (#carrinhoDiv) - Delegação
    if (carrinhoDiv) {
         carrinhoDiv.addEventListener('click', (event) => {
             const button = event.target.closest('button[data-action="remover-item"]');
             if (!button?.dataset?.index) return; // Sai se não for botão remover ou não tiver index

             const index = parseInt(button.dataset.index, 10);
             console.log(`[UI] Ação CARRINHO: remover-item, index: ${index}`);

             if (!isNaN(index) && typeof removerItem === 'function') {
                 removerItem(index);
             } else {
                 console.warn("Função global removerItem ou índice inválido.");
             }
         });
    }

     // Ações no Painel de Transferências (#painelCapinhasDiv) - Delegação
     if (painelCapinhasDiv) {
        painelCapinhasDiv.addEventListener('click', (event) => {
             const button = event.target.closest('button[data-action="abrir-galeria"]');
             if (!button?.dataset?.galeriaId) return;

             const galeriaId = parseInt(button.dataset.galeriaId, 10);
             console.log(`[UI] Ação PAINEL TRANSFER: abrir-galeria, ID: ${galeriaId}`);

             if (!isNaN(galeriaId) && typeof abrirGaleria === 'function') {
                 abrirGaleria(galeriaId);
             } else {
                 console.warn("Função global abrirGaleria ou ID de galeria inválido.");
             }
         });
     }


    // Modal Finalizar Venda
    if (btnAbrirModalFinalizar) {
        btnAbrirModalFinalizar.addEventListener('click', () => {
             if(valorRecebidoInput) valorRecebidoInput.value = '';
             if(valorTrocoDiv) valorTrocoDiv.innerHTML = '';
             openModal(modalFinalizar);
        });
    }
    if (btnCancelarVenda) btnCancelarVenda.addEventListener('click', () => closeModal(modalFinalizar));
    if (valorRecebidoInput) valorRecebidoInput.addEventListener('input', atualizarTroco);
    if (btnConfirmarVenda) {
        btnConfirmarVenda.addEventListener('click', () => {
            console.log("[UI] Botão Confirmar Venda clicado.");
            if (typeof enviarVenda === 'function') enviarVenda();
            else console.warn("[UI] Função global enviarVenda() não encontrada.");
        });
    }

    // Recibo
    if (btnFecharRecibo) btnFecharRecibo.addEventListener('click', () => {
        if (!reciboVendaDiv) return;
        reciboVendaDiv.style.display = 'none';
        reciboVendaDiv.classList.remove('active');
      });
      
    if (btnImprimirRecibo) btnImprimirRecibo.addEventListener('click', () => window.print());
    if (btnGerarPDF) {
         btnGerarPDF.addEventListener('click', () => {
             console.log("[UI] Botão Gerar PDF clicado.");
             if(typeof gerarPDFRecibo === 'function' && reciboConteudoDiv) gerarPDFRecibo(reciboConteudoDiv);
             else console.warn("[UI] Função global gerarPDFRecibo() ou div de conteúdo do recibo não encontrada.");
         });
    }

    // Modal Imagem Simples - Listener de Fechar
    if (btnFecharModalImagem) {
        btnFecharModalImagem.addEventListener('click', fecharModalImagem); // Chama a função local deste script
    }
    // Listener para ABRIR é adicionado dinamicamente ou via delegação em #resultDiv

    // Modal Galeria
    if (btnFecharGaleria) btnFecharGaleria.addEventListener('click', fecharGaleria); // Chama a função local
    if (imagemAtualGaleria) imagemAtualGaleria.addEventListener('click', toggleZoom); // Chama a função local
    if (btnAnteriorGaleria) {
        btnAnteriorGaleria.addEventListener('click', () => {
            if (typeof anteriorGaleria === 'function') anteriorGaleria();
            else console.warn("[UI] Função global anteriorGaleria() não encontrada.");
        });
    }
     if (btnProximaGaleria) {
        btnProximaGaleria.addEventListener('click', () => {
            if (typeof proximaGaleria === 'function') proximaGaleria();
            else console.warn("[UI] Função global proximaGaleria() não encontrada.");
        });
    }
     if (botaoTransferirEstoque) { // Botão dentro da galeria - listener já adicionado dinamicamente em app-loja3.js::atualizarGaleria
        // Poderia adicionar um listener genérico aqui se o onclick dinâmico for removido, mas manter o onclick dinâmico pode ser mais simples neste caso específico.
        console.debug("[UI] Botão de transferir estoque na galeria será tratado pelo onclick dinâmico em app-loja3.js.")
     }
    // Listener para ABRIR é adicionado dinamicamente ou via delegação em painelCapinhasDiv

    // --- Inicialização da UI ---
    console.log("[UI] Configurando estado inicial...");
    irParaPagina('vendas'); // Define a página inicial
    window.atualizarContadorAlertasUI(); // Atualiza o contador no início

    console.log("[ui-interactions.js] UI inicializada e pronta.");

}); // Fim do DOMContentLoaded

console.log("[ui-interactions.js] Script carregado.");