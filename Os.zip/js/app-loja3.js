// js/app-loja3.js

// --- Configurações e Variáveis Globais do Módulo ---
const lojaCategoria = 'PeliculasLoja3'; // Categoria da loja atual no Nextar
const lojaAtual = lojaCategoria.replace("Peliculas", "").toLowerCase(); // Ex: 'loja3'

// Mapeamento de UIDs de Categoria (Verifique se estão corretos)
const categoriaUIDs = {
    loja1: "DA1582E5-0249-4843-8BDE-C937313ADED1",
    loja2: "F3843A95-1BC2-4751-B0BB-541F099A4597",
    loja3: "BEB6ED33-B771-4FE9-B994-E447A074EEBB"
    // Adicione outras lojas se necessário
};

// Senhas (Considerar uma forma mais segura se a aplicação crescer)
const senhasVendedores = {
    "1602": "Gislanio",
    "2504": "Nayara",
    "2468": "Grazi",
    "7777": "Lucas",
    "9125": "Cícero",
    "2802": "Beatriz",
    "1401": "Gustavo Barbosa",
    "1322": "Viviane",
    "1234": "Victória",
    "2030": "Vivian",
    "2006": "Gleyse",
    "1021": "Danilo Teles",
    "1409": "Giovanna"
    // Adicione outros vendedores
};

// Estado da Aplicação (Carrinho, Galeria, etc.)
let carrinho = [];
let galeriaItens = []; // Itens atualmente exibidos na galeria modal
let indiceAtual = 0; // Índice do item atual na galeria modal
const galeriasSalvas = []; // Armazena dados para diferentes galerias (ex: por modelo)


// --- Funções de Lógica de Negócios (Carrinho, Venda, Estoque, etc.) ---

/** Exibe um alerta temporário na tela. */
function mostrarAlerta(texto, tipo = 'info') { // tipo pode ser 'info', 'success', 'error'
    const alertaDiv = document.getElementById("alertaCarrinho");
    if (!alertaDiv) return;
    alertaDiv.textContent = texto;
    alertaDiv.className = `alerta-carrinho ${tipo}`; // Adiciona classe para estilização opcional
    alertaDiv.style.display = "block";
    setTimeout(() => {
        alertaDiv.style.display = "none";
        alertaDiv.className = 'alerta-carrinho'; // Reseta classe
    }, 2500); // Aumentei um pouco o tempo
}

/** Adiciona um produto ao carrinho ou incrementa quantidade. */
function adicionarCarrinho(prod) {
    if (!prod || !prod.uid) {
        console.error("[adicionarCarrinho] Produto inválido:", prod);
        mostrarAlerta("Erro ao adicionar produto.", "error");
        return;
    }
    try {
        const existente = carrinho.find(p => p.uid === prod.uid);
        if (existente) {
            existente.qty += 1;
        } else {
            // Adiciona apenas os dados essenciais ao carrinho
            carrinho.push({
                uid: prod.uid,
                description: prod.description,
                price: prod.price ?? 0, // Garante um valor padrão
                code: prod.code,
                // Adicione outros campos se forem necessários para a venda/recibo
                qty: 1
            });
        }
        renderCarrinho();
        mostrarAlerta(`${prod.description} adicionado!`, "success");
    } catch (error) {
        console.error("[adicionarCarrinho] Erro:", error);
        mostrarAlerta("Erro ao processar adição ao carrinho.", "error");
    }
}

/** Remove um item do carrinho pelo índice. */
function removerItem(index) {
    if (index >= 0 && index < carrinho.length) {
        const itemRemovido = carrinho.splice(index, 1);
        console.log("[removerItem] Item removido:", itemRemovido[0]?.description);
        renderCarrinho();
        mostrarAlerta("Item removido do carrinho.", "info");
    } else {
        console.error("[removerItem] Índice inválido:", index);
    }
}

/** Renderiza o conteúdo do carrinho na barra lateral. */
function renderCarrinho() {
    const container = document.getElementById('carrinho');
    const totalCarrinhoElement = document.querySelector('#carrinhoSidebar .total-carrinho strong'); // Seletor do total

    if (!container || !totalCarrinhoElement) {
        console.error("[renderCarrinho] Elementos do carrinho não encontrados no DOM.");
        return;
    }

    container.innerHTML = ''; // Limpa antes de renderizar
    let total = 0;

    if (carrinho.length === 0) {
        container.innerHTML = '<p>Carrinho vazio.</p>';
    } else {
        carrinho.forEach((item, i) => {
            const subtotal = (item.price ?? 0) * item.qty;
            total += subtotal;
            // ** REMOVIDO onclick, adicionado data-* **
            container.innerHTML += `
                <div class="cart-item">
                    <span class="item-name">${item.description}</span>
                    <span class="item-qty">Qtd: ${item.qty}</span>
                    <span class="item-subtotal">Sub: R$ ${subtotal.toFixed(2)}</span>
                    <button class="btn-remove-item" data-action="remover-item" data-index="${i}" title="Remover Item">✖</button>
                </div>
            `;
        });
    }
    // Atualiza o total exibido
    totalCarrinhoElement.textContent = `R$ ${total.toFixed(2)}`;
}


/** Abre a galeria modal com os dados de um modelo específico. */
function abrirGaleria(idGaleria) {
    const dados = galeriasSalvas[idGaleria];
    console.debug("[abrirGaleria] Abrindo galeria ID:", idGaleria, dados);

    if (!dados || !Array.isArray(dados) || dados.length === 0) {
        console.error("[abrirGaleria] Nenhum dado válido para abrir galeria ID:", idGaleria);
        mostrarAlerta("Não há imagens ou produtos para exibir nesta galeria.", "error");
        return;
    }

    // Filtra itens para mostrar apenas os de OUTRAS lojas com estoque > 0
    galeriaItens = dados.filter(item => {
        const origemDesc = item.origem?.category?.description?.toLowerCase() || '';
        const temEstoque = (item.quantidade ?? 0) > 0;
        return temEstoque && origemDesc && !origemDesc.includes(lojaAtual); // Verifica se NÃO é da loja atual
    });

    if (galeriaItens.length === 0) {
        mostrarAlerta("Nenhum produto disponível em outras lojas para este modelo.", "info");
        // Não precisa chamar fecharGaleria(), apenas não abre
        return;
    }

    indiceAtual = 0; // Reseta o índice

    // Usa a função de UI-interactions para abrir o modal
    if (typeof openModal === 'function') {
        const modalElement = document.getElementById("modalGaleria");
        if (modalElement) {
             atualizarGaleria(); // Prepara o conteúdo antes de mostrar
             openModal(modalElement);
        } else {
             console.error("[abrirGaleria] Elemento #modalGaleria não encontrado.");
        }
    } else {
        console.error("[abrirGaleria] Função global openModal() não encontrada.");
    }
}

/** Atualiza o conteúdo da galeria modal com base no índice atual. */
function atualizarGaleria() {
    console.groupCollapsed(`[atualizarGaleria] Iniciando atualização (índiceAtual: ${indiceAtual})`);

    const imgElement = document.getElementById("imagemAtualGaleria");
    const nomeElement = document.getElementById("nomeProdutoGaleria");
    const botaoTransferir = document.getElementById("botaoTransferirEstoque"); // Botão agora é único

    console.log("[Checagem de Elementos]");
    console.log("imgElement:", imgElement);
    console.log("nomeElement:", nomeElement);
    console.log("botaoTransferir:", botaoTransferir);

    if (!imgElement || !nomeElement || !botaoTransferir) {
        console.error("[ERRO] Elementos essenciais da galeria NÃO encontrados no DOM.");
        console.trace();  // Mostra stack trace para entender onde foi chamado
        console.groupEnd();
        return;
    }

    if (galeriaItens.length === 0 || indiceAtual < 0 || indiceAtual >= galeriaItens.length) {
        console.warn(`[AVISO] Índice ou itens da galeria inválidos. IndiceAtual: ${indiceAtual}, TotalItens: ${galeriaItens.length}`);
        
        // Atualiza o visual para placeholder
        imgElement.src = 'img/placeholder.png';
        imgElement.alt = 'Erro ao carregar item';
        nomeElement.innerHTML = 'Erro ao carregar item.';
        botaoTransferir.style.display = 'none'; // Esconde botão se der erro

        console.groupEnd();
        return;
    }

    const itemAtual = galeriaItens[indiceAtual];
    console.debug("[Item Atual]", itemAtual);

    // Atualiza imagem e nome do produto
    const novaSrc = itemAtual.foto || 'img/placeholder.png';
    imgElement.src = novaSrc;
    imgElement.alt = itemAtual.nome || 'Imagem do produto';

    console.log(`Imagem definida: ${novaSrc}`);
    console.log(`Alt definida: ${imgElement.alt}`);

    // Formata a origem para exibição
    let origemHtml = 'Origem indisponível';
    if (itemAtual.origem?.category?.description) {
        const lojaOrigemDesc = itemAtual.origem.category.description;
        origemHtml = `Origem: ${lojaOrigemDesc.replace(/Peliculas/i, '').replace(/loja/i, 'Loja ').trim()}`;
    }
    console.log(`Origem formatada: ${origemHtml}`);

    nomeElement.innerHTML = `
        <strong>${itemAtual.nome || 'Nome indisponível'}</strong><br/>
        <small>Preço: R$ ${(itemAtual.preco ?? 0).toFixed(2)}</small><br/>
        <small>Disponível: ${itemAtual.quantidade ?? 0}</small><br/>
        <small>${origemHtml}</small>
    `;

    console.log("Conteúdo de nomeProdutoGaleria atualizado.");

    // Configura o botão de transferir com os dados do item atual
    try {
        console.log("Removendo listeners antigos do botão transferir...");
        const novoBotao = botaoTransferir.cloneNode(true); // Clona para limpar event listeners antigos
        botaoTransferir.parentNode.replaceChild(novoBotao, botaoTransferir);
        
        console.log("Adicionando novo evento de clique ao botão transferir...");
        novoBotao.onclick = () => {
            console.info(`[AÇÃO] Botão transferir clicado para o item:`, itemAtual);
            transferirEstoque(itemAtual);
        };

        novoBotao.style.display = 'inline-block'; // Garante que está visível
        console.log("Botão transferir configurado e visível.");
    } catch (e) {
        console.error("[ERRO] Problema ao configurar o botão transferir:", e);
    }

    console.groupEnd();
}


/** Navega para a próxima imagem na galeria. */
function proximaGaleria() {
    if (!galeriaItens || galeriaItens.length === 0) return;
    indiceAtual++;
    if (indiceAtual >= galeriaItens.length) {
        indiceAtual = 0; // Volta para o início
    }
    atualizarGaleria();
}

/** Navega para a imagem anterior na galeria. */
function anteriorGaleria() {
    if (!galeriaItens || galeriaItens.length === 0) return;
    indiceAtual--;
    if (indiceAtual < 0) {
        indiceAtual = galeriaItens.length - 1; // Volta para o final
    }
    atualizarGaleria();
}

/** Busca produtos na API baseado no termo de pesquisa. */
async function buscarProdutos(termoPesquisa = null) {
    const termoBruto = termoPesquisa ?? document.getElementById('searchInput')?.value.trim();
    const resultDiv = document.getElementById('result');

    if (!resultDiv) {
        console.error("[buscarProdutos] Div de resultados #result não encontrada.");
        return;
    }
    if (!termoBruto) {
        resultDiv.innerHTML = '<p>Digite algo para buscar.</p>';
        return;
    }

    resultDiv.innerHTML = '<p>Buscando produtos...</p>';
    console.log(`[buscarProdutos] Buscando por: "${termoBruto}"`);

    const lojasParaConsultar = ['PeliculasLoja1', 'PeliculasLoja2', 'PeliculasLoja3'];
    const encontradosTodasLojas = [];

    try {
        if (typeof shopCode === 'undefined' || typeof fetchComToken !== 'function') {
            throw new Error("'shopCode' ou 'fetchComToken' não definidos globalmente.");
        }

        for (const categoriaLojaAPI of lojasParaConsultar) { // Renomeado para evitar conflito com 'lojaCategoria' global
            const url = `https://api.web.nextar.com.br/api/v1/product/${shopCode}?page=0&size=200&sort=description&direction=asc&pdv=false&filter=active&search=${encodeURIComponent(termoBruto)}&ts=${Date.now()}`;
            console.debug(`[buscarProdutos] Consultando: ${categoriaLojaAPI} | URL: ${url}`);

            const res = await fetchComToken(url, {});
            if (!res.ok) {
                console.warn(`[buscarProdutos] Falha ao buscar em ${categoriaLojaAPI}: Status ${res.status}`);
                continue;
            }
            const json = await res.json();

            const filtrados = (json.content || []).filter(p => {
                const estoqueAtual = p.current_stock != null ? p.current_stock : p.stock;
                // Verifica se a categoria do produto na API corresponde à categoria da loja que estamos consultando no loop
                const categoriaOk = p.category?.description === categoriaLojaAPI;
                const estoqueOk = (estoqueAtual ?? 0) > 0;
                const ativoOk = p.active === true || String(p.active).toLowerCase() === 'true';
            
                // console.debug(`[buscarProdutos] Produto: ${p.description} | Categoria API: ${p.category?.description} | Estoque: ${estoqueAtual} | Loja Esperada no Loop: ${categoriaLojaAPI} | Ativo: ${p.active} => CategoriaOK: ${categoriaOk}, EstoqueOK: ${estoqueOk}, AtivoOK: ${ativoOk}`);
            
                return categoriaOk && estoqueOk && ativoOk;
            });
            
            console.debug(`[buscarProdutos] ${filtrados.length} produtos válidos encontrados em ${categoriaLojaAPI}.`);

            filtrados.forEach(p => {
                p._origemLoja = categoriaLojaAPI;
                encontradosTodasLojas.push(p);

                // Se o produto encontrado é da loja atual (definida globalmente como 'lojaCategoria')
                // E se você QUER que app-loja3.js dispare uma verificação de alerta local IMEDIATAMENTE:
                if (categoriaLojaAPI === lojaCategoria) {
                    if (window.estoqueAlertas && typeof window.estoqueAlertas.verificarEstoqueMinimoParaLoja === 'function') {
                        // Chama a função exposta por estoque-alertas.js
                        window.estoqueAlertas.verificarEstoqueMinimoParaLoja(p);
                    } else {
                        // Se não quiser essa chamada imediata, pode remover este bloco if,
                        // pois estoque-alertas.js já fará isso em seu próprio ciclo.
                        console.warn(`[buscarProdutos] Interface window.estoqueAlertas.verificarEstoqueMinimoParaLoja não encontrada. A verificação de estoque local para "${p.description}" dependerá do ciclo de estoque-alertas.js.`);
                    }
                }
            });
        }

        console.log(`[buscarProdutos] Total encontrado em todas lojas: ${encontradosTodasLojas.length}`);
        todosProdutosDisponiveis = encontradosTodasLojas;

        const produtosVisiveisLojaAtual = encontradosTodasLojas.filter(p => p._origemLoja === lojaCategoria);

        if (produtosVisiveisLojaAtual.length === 0) {
            resultDiv.innerHTML = `<p>Nenhum produto encontrado para "${termoBruto}" nesta loja (${lojaAtual}).</p>`;
            if (typeof exibirPainelCapinhas === 'function') {
                exibirPainelCapinhas(encontradosTodasLojas);
            }
            return;
        }

        resultDiv.innerHTML = '';

        produtosVisiveisLojaAtual.forEach(prod => {
            const nome = (prod.description || '')
                .normalize("NFD")
                .replace(/\p{Diacritic}/gu, '')
                .toLowerCase();
        
            let corBorda = '#ccc';
            let imagem = 'padrao.png';
        
            if (nome.includes('vidro')) {
                if (nome.includes('privacidade')) {
                    corBorda = '#6c757d';
                    imagem = '3d-vidro-privacidade.png';
                } else if (nome.includes('3d')) {
                    corBorda = '#1e90ff';
                    imagem = '3d-vidro.png';
                } else {
                    corBorda = '#1e90ff';
                    imagem = 'vidro.png';
                }
            } else if (nome.includes('ceramica')) {
                if (nome.includes('privacidade')) {
                    corBorda = '#6c757d';
                    imagem = 'ceramica-privacidade.png';
                } else if (nome.includes('fosca')) {
                    corBorda = '#6c757d';
                    imagem = 'ceramica-fosca.png';
                } else {
                    corBorda = '#28a745';
                    imagem = 'ceramica.png';
                }
            } else if (nome.includes('estampada')) {
                corBorda = '#d63384';
                imagem = 'estampada.png';
            }

            const imageUrl = prod.photos?.[0]?.url;
            const produtoJsonEscapado = JSON.stringify(prod).replace(/"/g, '"'); // Corrigido para "

            const nomeProdutoLower = (prod.description || '').toLowerCase();
            const isPelícula = nomeProdutoLower.includes('pelicula') || nomeProdutoLower.includes('película');

            resultDiv.innerHTML += `
            <div class="product" style="border-left: 5px solid ${corBorda}">
                <div class="product-thumbnail-wrapper">
                    ${
                        imageUrl
                        ? `<img src="${imageUrl}" alt="${prod.description || 'Produto'}" class="product-thumbnail"/>`
                        : `<img src="img/tipos-peliculas/${imagem}" alt="Tipo Película" class="product-thumbnail"/>`
                    }
                </div>
                <strong class="product-name">${prod.description || 'Produto sem descrição'}</strong>
                <span class="product-code">Código: ${prod.code || 'N/A'}</span>
                <span class="product-price">Preço: R$ ${(prod.price ?? 0).toFixed(2)}</span>
                <span class="product-stock">Estoque: ${(prod.current_stock != null ? prod.current_stock : prod.stock) ?? 0}</span>
                <div class="product-actions">
                    <button class="btn-action btn-add-cart" data-action="adicionar-carrinho" data-produto='${produtoJsonEscapado}'>🛒 Add</button>
                    ${imageUrl ? `<button class="btn-action btn-view-image" data-action="ver-foto" data-url="${imageUrl}">📷 Ver</button>` : ''}
                    ${isPelícula ? `<button class="btn-action btn-register-loss" data-action="registrar-perda" data-produto='${produtoJsonEscapado}'>🗑️ Perda</button>` : ''}
                    <button class="btn-action btn-edit-stock" data-action="alterar-estoque" data-produto='${produtoJsonEscapado}'>✏️ Estoque</button>
                </div>
            </div>
            `;
        });

        if (typeof exibirPainelCapinhas === 'function') {
            exibirPainelCapinhas(encontradosTodasLojas);
        }

        if (typeof exibirAlertasPersistentes === 'function') {
            exibirAlertasPersistentes();
        }

    } catch (err) {
        resultDiv.innerHTML = `<p class="error-message">Erro ao buscar produtos: ${err.message}</p>`;
        console.error("[buscarProdutos] Erro fatal durante a busca:", err);
    }
}

/** Extrai um nome de modelo padronizado da descrição do produto. */
function extrairModelo(nomeProduto) {
    if (!nomeProduto) return null;

    let modelo = nomeProduto.normalize("NFD").replace(/[\u0300-\u036f]/g, ""); // Remove acentos
    modelo = modelo.toLowerCase().trim();

    // Remove termos genéricos comuns (ajuste a lista conforme necessário)
    const termosRemover = [
        'pelicula', 'vidro', '3d', '9d', 'ceramica', 'hidrogel', 'privacidade', 'fosca',
        'capinha', 'capa', 'case', 'protetor', 'tpu', 'silicone', 'anti impacto', 'transparente',
        'estampada', 'preta', 'black', 'para', 'de', 'celular', 'smartphone',
        // Adicione variações como 'película', 'cerâmica' se a normalização não pegar
    ];
    termosRemover.forEach(term => {
        modelo = modelo.replace(new RegExp(`\\b${term}\\b`, 'gi'), '');
    });

    // Remove caracteres especiais restantes e normaliza espaços
    modelo = modelo.replace(/[^a-z0-9\s]/gi, '').replace(/\s+/g, ' ').trim();

    // Tenta capitalizar o resultado (ex: "moto g22" -> "Moto G22")
    return modelo.split(' ')
                 .map(palavra => palavra.charAt(0).toUpperCase() + palavra.slice(1))
                 .join(' ')
                 .trim();
}

/** Exibe o painel de produtos disponíveis para transferência. */
function exibirPainelCapinhas(produtos) {
    const painel = document.getElementById("painelCapinhas");
    if (!painel) return;

    painel.innerHTML = ''; // Limpa painel anterior

    // Termos para identificar produtos que podem ter visualização/transferência
    const termosVisuais = ["capinha", "película", "vidro", "estampada", "fosca", "case", "ceramica", "carregador", "fone", "headset", "fone de ouvido"];
    const agrupadosPorModelo = {};
    const imagensUnicasPorModelo = {}; // Para evitar duplicatas visuais se o nome for levemente diferente

    // Função para limpar URL e usar como chave
    const limparURL = (url = '') => url.replace(/^https?:\/\//, '').replace(/\?.*$/, '').toLowerCase().trim();

    // Agrupa produtos por modelo extraído
    produtos.forEach(prod => {
        const nomeBase = (prod.description || "").toLowerCase();
        const contemTermo = termosVisuais.some(termo => nomeBase.includes(termo));
        if (!contemTermo) return; // Pula se não for um item visual/transferível

        const modelo = extrairModelo(prod.description);
        if (!modelo) return; // Pula se não conseguir extrair modelo

        if (!agrupadosPorModelo[modelo]) {
            agrupadosPorModelo[modelo] = [];
            imagensUnicasPorModelo[modelo] = new Set();
        }
        agrupadosPorModelo[modelo].push(prod);

        // Adiciona URL limpa da imagem ao Set para controle
        const fotoUrlLimpa = limparURL(prod.photos?.[0]?.url);
        if (fotoUrlLimpa) {
            imagensUnicasPorModelo[modelo].add(fotoUrlLimpa);
        }
    });

    let totalModelosParaTransferir = 0;
    let htmlPainel = '';

    // Processa cada modelo agrupado
    Object.entries(agrupadosPorModelo).forEach(([modelo, listaProdutos]) => {
        // Verifica se existe ALGUM produto deste modelo em OUTRA loja com estoque
        const temEstoqueOutraLoja = listaProdutos.some(p =>
            (p.category?.description || "").toLowerCase() !== lojaCategoria.toLowerCase() &&  // compara exato com lojaCategoria
            ((p.current_stock != null ? p.current_stock : p.stock) ?? 0) > 0
        );        

        // Se não há estoque em outra loja para este modelo, PULA
        if (!temEstoqueOutraLoja) return;

        totalModelosParaTransferir++; // Conta apenas modelos que têm estoque fora

        // Prepara os dados para a galeria deste modelo
        const galeriaDados = listaProdutos
            // Mapeia para o formato esperado pela galeria
            .map(produto => ({
                foto: produto.photos?.[0]?.url, // Deixa a URL original aqui
                nome: produto.description,
                quantidade: (produto.current_stock != null ? produto.current_stock : produto.stock) ?? 0,
                preco: produto.price ?? 0,
                origem: produto, // Guarda o objeto produto original da loja de origem
                // 'destino' é removido, pois a criação/atualização será feita na transferência
            }))
            // Filtra para remover itens sem quantidade (já feito antes, mas garante)
            .filter(item => item.quantidade > 0);

        // Se não sobrou nenhum item após mapear (improvável, mas seguro)
        if (galeriaDados.length === 0) return;

        // Armazena os dados da galeria e obtém um ID único
        const idGaleria = galeriasSalvas.length;
        galeriasSalvas.push(galeriaDados);

        // Encontra uma imagem representativa para o botão (a primeira com foto)
        const imagemRepresentativa = galeriaDados.find(g => g.foto)?.foto || 'img/placeholder.png';

        // ** REMOVIDO onclick, adicionado data-* **
        htmlPainel += `
            <div class="painel-item">
                <img src="${imagemRepresentativa}" alt="${modelo}" class="painel-item-img"/>
                <button class="btn-ver-produto" data-action="abrir-galeria" data-galeria-id="${idGaleria}">
                    ${modelo} (Ver Opções)
                </button>
            </div>
        `;
    }); // Fim do loop Object.entries

    // Adiciona cabeçalho se houver modelos para transferir
    if (totalModelosParaTransferir > 0) {
        painel.innerHTML = `
            <div class="painel-header">
                <strong>${totalModelosParaTransferir} modelos com estoque em outras lojas:</strong>
            </div>
            <div class="painel-grid"> ${htmlPainel}
            </div>`;
    } else {
        painel.innerHTML = '<p>Nenhum item encontrado em outras lojas para transferência no momento.</p>';
    }
}


/** Permite alterar o estoque de um produto (requer senha). */
async function alterarEstoque(produto) {
    if (!produto || !produto.uid) return alert("Produto inválido.");

    const senha = prompt(`ALTERAR ESTOQUE de "${produto.description}":\nDigite a senha do vendedor:`);
    if (!senha) return; // Cancelou
    const vendedor = senhasVendedores[senha];
    if (!vendedor) return alert("Senha inválida.");

    const novaQuantidadeStr = prompt(`Estoque atual: ${produto.current_stock ?? 0}\nDigite a NOVA quantidade total:`);
    // Permite '0' mas não negativo ou inválido
    if (novaQuantidadeStr === null || novaQuantidadeStr.trim() === '' || isNaN(parseInt(novaQuantidadeStr)) || parseInt(novaQuantidadeStr) < 0) {
        return alert("Quantidade inválida.");
    }
    const novaQuantidade = parseInt(novaQuantidadeStr);

    const confirmar = confirm(`Confirma alteração do estoque de "${produto.description}" para ${novaQuantidade}?\nResponsável: ${vendedor}`);
    if (!confirmar) return;

    console.log(`[alterarEstoque] Tentando alterar ${produto.uid} para ${novaQuantidade}...`);
    try {
        // 1. Busca o produto atual para garantir que temos todos os campos necessários para o PUT
         const urlGet = `https://api.web.nextar.com.br/api/v1/product/${shopCode}/${produto.uid}?_=${Date.now()}`;
         const resProduto = await fetchComToken(urlGet);
         if (!resProduto.ok) throw new Error(`Erro ${resProduto.status} ao buscar dados atuais do produto.`);
         const produtoAtualCompleto = await resProduto.json();

         // 2. Atualiza apenas os campos de estoque
         produtoAtualCompleto.current_stock = novaQuantidade;
         produtoAtualCompleto.stock = novaQuantidade; // API Nextar geralmente usa ambos

         // 3. Envia o objeto COMPLETO de volta via PUT
         const urlPut = `https://api.web.nextar.com.br/api/v1/product/${shopCode}`;
         const resUpdate = await fetchComToken(urlPut, {
             method: "PUT",
             headers: { "Content-Type": "application/json" },
             body: JSON.stringify(produtoAtualCompleto) // Envia o objeto completo atualizado
         });

         if (!resUpdate.ok) {
             const erroTxt = await resUpdate.text();
             console.error("[alterarEstoque] Erro da API:", erroTxt);
             throw new Error(`Erro ${resUpdate.status} ao atualizar estoque na API.`);
         }

         alert("Estoque atualizado com sucesso!");
         console.log(`[alterarEstoque] Estoque de ${produto.uid} atualizado para ${novaQuantidade}.`);
         // Reexecuta a busca atual para refletir a mudança na tela
         setTimeout(() => buscarProdutos(), 600);

    } catch (err) {
        console.error("[alterarEstoque] Erro:", err);
        alert(`Erro ao alterar estoque: ${err.message}`);
    }
}

/** Realiza a transferência de estoque entre lojas (requer senha). */
async function transferirEstoque(dadosTransferencia) {
    console.debug("[transferirEstoque] Iniciando transferência...");
    console.debug("[transferirEstoque] Dados recebidos:", dadosTransferencia);

    const produtoOrigem = dadosTransferencia.origem;

    if (!produtoOrigem || !produtoOrigem.uid || !produtoOrigem.category?.description) {
        alert("Erro interno: Dados do produto de origem inválidos.");
        console.error("[transferirEstoque] Dados de origem inválidos:", produtoOrigem);
        return;
    }

    const lojaOrigemDesc = produtoOrigem.category.description;
    const lojaOrigemNome = lojaOrigemDesc.replace(/Peliculas/i, '').replace(/loja/i, 'Loja ').trim();

    // ✅ Ajuste: estoque correto usando fallback para stock se current_stock não existir
    const estoqueOrigem = (produtoOrigem.current_stock != null ? produtoOrigem.current_stock : produtoOrigem.stock) ?? 0;

    const quantidadeStr = prompt(
        `Transferir de ${lojaOrigemNome} para ${lojaAtual.toUpperCase()}:\n\n` +
        `Produto: ${produtoOrigem.description}\n` +
        `Estoque Origem: ${estoqueOrigem}\n\n` +
        `Quantas unidades deseja transferir?`
    );
    if (quantidadeStr === null) return;

    const quantidade = parseInt(quantidadeStr);
    if (isNaN(quantidade) || quantidade <= 0) {
        return alert("Quantidade inválida.");
    }
    if (quantidade > estoqueOrigem) {
        return alert(`Quantidade (${quantidade}) maior que estoque disponível na ${lojaOrigemNome} (${estoqueOrigem}).`);
    }

    const senha = prompt("Digite a senha do vendedor para confirmar:");
    if (!senha) return;
    const vendedor = senhasVendedores[senha];
    if (!vendedor) {
        return alert("Senha inválida. Operação cancelada.");
    }

    const confirmar = confirm(
        `CONFIRMAR TRANSFERÊNCIA:\n\n` +
        `${quantidade}x "${produtoOrigem.description}"\n` +
        `De: ${lojaOrigemNome}\n` +
        `Para: ${lojaAtual.toUpperCase()}\n\n` +
        `Responsável: ${vendedor}\n\nProsseguir?`
    );
    if (!confirmar) return;

    console.log(`[transferirEstoque] Transferindo ${quantidade} de ${produtoOrigem.uid} (${lojaOrigemDesc}) para ${lojaCategoria}...`);

    try {
        let produtoDestino = null;
        const urlBuscaDestino = `https://api.web.nextar.com.br/api/v1/product/${shopCode}?page=0&size=50&search=${encodeURIComponent(produtoOrigem.description)}&filter=active`;
        const resBusca = await fetchComToken(urlBuscaDestino);
        if (resBusca.ok) {
            const dadosBusca = await resBusca.json();
            const produtosEncontrados = (dadosBusca.content || []).filter(p => {
                const descMatch = p.description?.trim().toLowerCase() === produtoOrigem.description.trim().toLowerCase();
                const codeMatch = p.code && produtoOrigem.code ? p.code.trim() === produtoOrigem.code.trim() : true;
                const categoriaMatch = p.category?.description?.trim().toLowerCase() === lojaCategoria.trim().toLowerCase();
                return p.active && descMatch && codeMatch && categoriaMatch;
            });

            if (produtosEncontrados.length > 0) {
                produtoDestino = produtosEncontrados[0];
            }
        }
        console.debug("[transferirEstoque] Produto destino encontrado:", produtoDestino);

        if (!produtoDestino) {
            console.log(`[transferirEstoque] Produto "${produtoOrigem.description}" não encontrado na loja destino (${lojaCategoria}). Criando...`);
            const novoProdutoDestino = {
                description: produtoOrigem.description,
                code: produtoOrigem.code || '',
                active: true,
                stock_control: true,
                current_stock: 0,
                stock: 0,
                cost_price: produtoOrigem.cost_price ?? 0,
                price: produtoOrigem.price ?? 0,
                shopcode: shopCode,
                combo: false,
                unit_price: produtoOrigem.price ?? 0,
                published: false,
                promotional: false,
                fractional_sale: false,
                can_change_price: produtoOrigem.can_change_price ?? false,
                auto_price: false,
                profit_margin: produtoOrigem.profit_margin ?? 0,
                category: {
                    uid: categoriaUIDs[lojaAtual],
                    description: lojaCategoria
                },
                tax_use_global: true,
                no_tax: false,
                suppliers: [],
                photos: produtoOrigem.photos || []
            };
            console.debug("[transferirEstoque] Objeto para criar produto destino:", novoProdutoDestino);

            const urlCriar = `https://api.web.nextar.com.br/api/v1/product/${shopCode}`;
            const resCriar = await fetchComToken(urlCriar, {
                method: 'POST',
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(novoProdutoDestino)
            });

            const rawText = await resCriar.text();
            console.debug("[transferirEstoque] Produto criado na loja destino (raw):", rawText);

            let uidCriado;
            try {
                uidCriado = JSON.parse(rawText);
            } catch (e) {
                uidCriado = { uid: rawText.trim().replace(/^"|"$/g, '') };
            }
            console.log("[transferirEstoque] Produto criado na loja destino:", uidCriado);

            const urlGetNovo = `https://api.web.nextar.com.br/api/v1/product/${shopCode}/${uidCriado.uid || uidCriado}`;
            const resGetNovo = await fetchComToken(urlGetNovo);
            if (!resGetNovo.ok) throw new Error("Erro ao buscar produto recém-criado.");
            produtoDestino = await resGetNovo.json();

        } else {
            console.log(`[transferirEstoque] Produto "${produtoDestino.description}" encontrado na loja destino. Buscando estado atual...`);
            const urlGetExistente = `https://api.web.nextar.com.br/api/v1/product/${shopCode}/${produtoDestino.uid}`;
            const resGetExistente = await fetchComToken(urlGetExistente);
            if (!resGetExistente.ok) throw new Error(`Erro ${resGetExistente.status} ao buscar estado atual do produto destino.`);
            produtoDestino = await resGetExistente.json();
        }

        // Atualizar estoque origem (💡 reforça usando fallback também)
        console.log(`[transferirEstoque] Atualizando estoque origem (${produtoOrigem.uid})...`);
        const urlGetOrigem = `https://api.web.nextar.com.br/api/v1/product/${shopCode}/${produtoOrigem.uid}`;
        const resGetOrigem = await fetchComToken(urlGetOrigem);
        if (!resGetOrigem.ok) throw new Error(`Erro ${resGetOrigem.status} ao buscar estado atual da origem.`);
        const produtoOrigemAtualizado = await resGetOrigem.json();

        const estoqueOrigemAtual = (produtoOrigemAtualizado.current_stock != null ? produtoOrigemAtualizado.current_stock : produtoOrigemAtualizado.stock) ?? 0;
        if (quantidade > estoqueOrigemAtual) {
            throw new Error(`Estoque na origem mudou (${estoqueOrigemAtual}). Quantidade (${quantidade}) indisponível.`);
        }

        produtoOrigemAtualizado.current_stock = estoqueOrigemAtual - quantidade;
        produtoOrigemAtualizado.stock = estoqueOrigemAtual - quantidade;

        const urlPutOrigem = `https://api.web.nextar.com.br/api/v1/product/${shopCode}`;
        const resOrigem = await fetchComToken(urlPutOrigem, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(produtoOrigemAtualizado)
        });
        if (!resOrigem.ok) {
            const erroTxt = await resOrigem.text();
            console.error("[transferirEstoque] Erro API ao atualizar origem:", erroTxt);
            throw new Error(`Erro ${resOrigem.status} ao baixar estoque na origem.`);
        }
        console.log("[transferirEstoque] Estoque origem atualizado com sucesso.");

        // Atualizar estoque destino
        console.log(`[transferirEstoque] Atualizando estoque destino (${produtoDestino.uid})...`);
        const estoqueDestinoAtual = (produtoDestino.current_stock != null ? produtoDestino.current_stock : produtoDestino.stock) ?? 0;
        produtoDestino.current_stock = estoqueDestinoAtual + quantidade;
        produtoDestino.stock = estoqueDestinoAtual + quantidade;

        const urlPutDestino = `https://api.web.nextar.com.br/api/v1/product/${shopCode}`;
        const resDestino = await fetchComToken(urlPutDestino, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(produtoDestino)
        });
        if (!resDestino.ok) {
            const erroTxt = await resDestino.text();
            console.error("[transferirEstoque] Erro API ao atualizar destino:", erroTxt);
            throw new Error(`Erro ${resDestino.status} ao somar estoque no destino.`);
        }
        console.log("[transferirEstoque] Estoque destino atualizado com sucesso.");

        alert("Transferência realizada com sucesso!");
        if (typeof fecharGaleria === 'function') {
            fecharGaleria();
        } else {
            document.getElementById("modalGaleria").style.display = "none";
        }
        buscarProdutos();

    } catch (erro) {
        console.error("[transferirEstoque] Erro durante a transferência:", erro);
        alert(`Erro na transferência: ${erro.message}\nVerifique o console para mais detalhes.`);
    }
}

/** Registra uma perda de produto como uma venda de valor zero. */
async function registrarPerda(prod) {
    if (!prod || !prod.uid) return alert("Produto inválido.");

    const senha = prompt(`REGISTRAR PERDA de "${prod.description}":\nDigite a senha do vendedor:`);
    if (!senha) return;
    const vendedor = senhasVendedores[senha];
    if (!vendedor) return alert("Senha inválida.");

    const confirmar = confirm(`Confirmar registro de PERDA para 1 unidade de "${prod.description}"?\nResponsável: ${vendedor}`);
    if (!confirmar) return;

    // Prepara o corpo da "venda" com valor zero
    const perdaProduto = [{
        ...prod, // Inclui dados do produto original
        qty: 1, // Quantidade da perda
        final_value: 0, // Valor zero
        gross_value: 0,
        net_value: 0,
        payd: 0,
        stock_control: true // Garante que o estoque será baixado
    }];

    const bodyVendaPerda = {
        canceled: false,
        customer: null, // Sem cliente
        date: new Date().toISOString(), // Data atual
        deliver: false,
        devolution: false,
        discount: 0,
        final_value: 0, // Valor total zero
        gross_value: 0,
        net_value: 0,
        obs: `REGISTRO DE PERDA - Vendedor: ${vendedor}`, // Observação clara
        origin: 3, // Origem PDV
        payd: 0,
        payments: [], // Sem pagamentos
        pending_payment: false,
        percentage_discount: 0,
        percentual_sale: false,
        products: perdaProduto, // Array com o produto perdido
        qty: 1, // Quantidade total de itens (1 neste caso)
        seller: { // Usar um vendedor padrão ou buscar dinamicamente se necessário
            uid: "D184A0DC-3A17-44EC-A306-89634F61B257", // UID do usuário "Administrador" (exemplo)
            name: "Administrador",
            username: "admin"
        },
        shopcode: shopCode,
        status: 3, // Status concluído
        tax: { exempt: false, exempt_value: 0, included: 0, to_include: 0 },
        used_credit: 0
    };

    console.log("[registrarPerda] Enviando registro de perda:", bodyVendaPerda);
    try {
        const url = `https://api.web.nextar.com.br/api/v1/sale/${shopCode}`;
        const res = await fetchComToken(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyVendaPerda)
        });

        if (res.ok) {
            alert("Perda registrada com sucesso no sistema.");
            console.log("[registrarPerda] Perda registrada:", await res.json());
            buscarProdutos(); // Atualiza a visualização
        } else {
            const erroTxt = await res.text();
            console.error("[registrarPerda] Erro API:", erroTxt);
            throw new Error(`Erro ${res.status} ao registrar perda.`);
        }
    } catch (e) {
        console.error("[registrarPerda] Erro:", e);
        alert(`Erro ao registrar perda: ${e.message}`);
    }
}

async function enviarVenda() {
    if (!carrinho.length) return alert("O carrinho está vazio.");

    const tipoPagamentoElement = document.getElementById("formaPagamento");
    const valorRecebidoElement = document.getElementById("valorRecebido");

    if (!tipoPagamentoElement || !valorRecebidoElement) {
        return alert("Erro: Elementos do modal não encontrados.");
    }

    const tipo = parseInt(tipoPagamentoElement.value);
    const total = carrinho.reduce((s, i) => s + (i.price ?? 0) * i.qty, 0);
    const recebido = parseFloat(valorRecebidoElement.value || 0);
    const troco = recebido - total;

    if (isNaN(tipo)) return alert("Selecione uma forma de pagamento.");
    if (recebido < total && tipo === 0) {
        return alert("Valor recebido é menor que o total da venda.");
    }

    const senha = prompt("FINALIZAR VENDA: Digite a senha do vendedor:");
    if (!senha) return;
    const nomeVendedorLogado = senhasVendedores[senha];
    if (!nomeVendedorLogado) return alert("Senha inválida. Venda cancelada.");

    const produtosParaVenda = carrinho.map(p => ({
        uid: p.uid,
        description: p.description,
        code: p.code,
        qty: p.qty,
        price: p.price ?? 0,
        final_value: p.price ?? 0,
        gross_value: p.price ?? 0,
        net_value: p.price ?? 0,
        payd: (p.price ?? 0) * p.qty,
        stock_control: true
    }));

    const formaPagamentoDesc = tipoPagamentoElement.options[tipoPagamentoElement.selectedIndex].text;

    const pagamentos = [{
        change: (tipo === 0 && troco > 0) ? troco : 0,
        description: formaPagamentoDesc,
        image: tipo === 5 ? 8 : 0,
        type: tipo,
        uid: crypto.randomUUID(),
        value: total,
        uid_payment: crypto.randomUUID()
    }];

    const bodyVenda = {
        canceled: false,
        customer: null,
        date: new Date().toISOString(),
        deliver: false,
        devolution: false,
        discount: 0,
        final_value: total,
        gross_value: total,
        net_value: total,
        obs: `Vendedor: ${nomeVendedorLogado}`,
        origin: 3,
        payd: total,
        payments: pagamentos,
        pending_payment: false,
        percentage_discount: 0,
        percentual_sale: false,
        products: produtosParaVenda,
        qty: produtosParaVenda.reduce((s, p) => s + p.qty, 0),
        seller: {
            uid: "D184A0DC-3A17-44EC-A306-89634F61B257",
            name: "Administrador",
            username: "admin"
        },
        shopcode: shopCode,
        status: 3,
        tax: { exempt: false, exempt_value: 0, included: 0, to_include: 0 },
        used_credit: 0
    };

    console.log("[enviarVenda] Enviando dados da venda:", bodyVenda);
    try {
        const url = `https://api.web.nextar.com.br/api/v1/sale/${shopCode}`;
        const res = await fetchComToken(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyVenda)
        });

        if (res.ok) {
            const retornoVenda = await res.json();
            const uidVenda = retornoVenda.uid;
            console.log("[enviarVenda] Venda realizada com sucesso:", uidVenda, retornoVenda);

            // NOVO BLOCO → Gravação no backend Node.js/MySQL
            const dataVenda = new Date().toISOString().slice(0, 19).replace('T', ' ');
            const valorTotal = total;
            const formaPagamento = formaPagamentoDesc;
            const vendedorNome = nomeVendedorLogado;
            
            try {
                const resLocal = await fetch('http://localhost:3000/vendas', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        data_venda: dataVenda,
                        valor_total: valorTotal,
                        forma_pagamento: formaPagamento,
                        vendedor: vendedorNome
                    })
                });
            
                if (!resLocal.ok) {
                    const errorText = await resLocal.text();
                    console.error("[enviarVenda → backend] Erro:", errorText);
                } else {
                    console.log("[enviarVenda → backend] Venda gravada no banco MySQL com sucesso.");
                }
            } catch (err) {
                console.error("[enviarVenda → backend] Erro de rede:", err);
            }            
            // FIM BLOCO NOVO

            alert("Venda realizada com sucesso!");
            carrinho = [];
            renderCarrinho();

            if (typeof closeModal === 'function') {
                const modalElement = document.getElementById("modalFinalizar");
                if (modalElement) closeModal(modalElement);
            } else {
                document.getElementById("modalFinalizar").style.display = "none";
            }

            mostrarRecibo(produtosParaVenda, total, formaPagamentoDesc, nomeVendedorLogado);

            const btnPDF = document.getElementById("btnGerarPDF");
            const reciboDiv = document.getElementById("reciboVenda");
            if (btnPDF && reciboDiv && typeof html2pdf === 'function') {
                const novoBtnPDF = btnPDF.cloneNode(true);
                btnPDF.parentNode.replaceChild(novoBtnPDF, btnPDF);
                novoBtnPDF.style.display = "inline-block";
                novoBtnPDF.onclick = () => {
                    console.log(`[UI] Gerando PDF para recibo ${uidVenda}...`);
                    reciboDiv.style.display = "block";
                    const optPDF = {
                        margin: 10,
                        filename: `recibo_venda_${uidVenda || Date.now()}.pdf`,
                        image: { type: 'jpeg', quality: 0.98 },
                        html2canvas: { scale: 2, useCORS: true },
                        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
                    };
                    html2pdf().set(optPDF).from(reciboDiv).save().then(() => {
                        console.log("[UI] PDF Gerado.");
                    }).catch(err => {
                        console.error("[UI] Erro ao gerar PDF:", err);
                    });
                };
            }

            window.scrollTo({ top: 0, behavior: "smooth" });

        } else {
            const erroTxt = await res.text();
            console.error("[enviarVenda] Erro API:", erroTxt);
            alert(`Erro ao finalizar venda: ${erroTxt} (Status: ${res.status})`);
        }
    } catch (e) {
        console.error("[enviarVenda] Erro de rede ou processamento:", e);
        alert(`Erro de rede ou processamento ao enviar venda: ${e.message}`);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const btnTermico = document.getElementById("btnReciboTermico");
    if (btnTermico) {
        btnTermico.addEventListener("click", imprimirReciboTermico);
    }
});

function imprimirReciboTermico() {
    const reciboDiv = document.getElementById("reciboConteudo");
    if (!reciboDiv) return alert("Recibo não encontrado.");

    const texto = gerarTextoReciboTermico(reciboDiv);

    const janela = window.open('', '_blank');
    janela.document.write(`
        <html>
        <head>
            <title>Recibo Térmico</title>
            <style>
                @media print {
                    body {
                        width: 58mm;
                        margin: 0;
                        padding: 0;
                        font-family: monospace;
                        font-size: 14px;
                        text-align: center;
                    }
                    pre {
                        white-space: pre-wrap;
                        word-break: break-word;
                        padding: 10px;
                    }
                }

                body {
                    width: 58mm;
                    margin: 0;
                    padding: 0;
                    font-family: monospace;
                    font-size: 14px;
                    text-align: center;
                }

                pre {
                    white-space: pre-wrap;
                    word-break: break-word;
                    padding: 10px;
                }
            </style>
        </head>
        <body>
            <pre>${texto}</pre>
        </body>
        </html>
    `);

    janela.document.close();
    janela.focus();
    janela.print();
    // janela.close(); // Remova esta linha caso precise de depuração
}

function gerarTextoReciboTermico(container) {
    const linhas = [];

    const empresa = "MUNDO TECH";
    const razao = "MUNDO TECH COMERCIO E\nSERVIÇOS LTDA - ME";
    const cnpj = "CNPJ: 24.596.084/0001-36";
    const endereco = "R Severino Batista de\nMenezes, 10";
    const local = "Jd Aimore - São Paulo - SP";
    const cep = "CEP: 08110-410";
    const separador = "------------------------------";

    const dataHora = new Date().toLocaleString('pt-BR');
    const vendedor = container.querySelector("p:nth-of-type(3)")?.textContent?.replace("Vendedor: ", "").trim() || "N/A";
    const formaPagamento = container.querySelector("p:nth-of-type(4)")?.textContent?.replace("Pagamento: ", "").trim() || "N/A";

    // Cabeçalho
    linhas.push(empresa);
    linhas.push(razao);
    linhas.push(cnpj);
    linhas.push(endereco);
    linhas.push(local);
    linhas.push(cep);
    linhas.push(separador);

    // Dados da venda
    linhas.push(`Data: ${dataHora}`);
    linhas.push(`Vendedor: ${vendedor}`);
    linhas.push(`Pagamento: ${formaPagamento}`);
    linhas.push(separador);

    // Itens
    linhas.push("Itens:");
    container.querySelectorAll("ul li").forEach(item => {
        linhas.push(item.textContent.trim());
    });

    // Total
    const total = container.querySelector(".recibo-total")?.textContent || "Total: R$ 0,00";
    linhas.push(separador);
    linhas.push(total);
    linhas.push(separador);

    // Rodapé
    linhas.push("Obrigado pela preferência!");
    linhas.push(" ");

    return linhas.join("\n");
}


function imprimirCanhoto(codigo, data, vendedor, valor, pagamento, produtos) {
    const janela = window.open('', 'PRINT', 'height=600,width=800');
    janela.document.write(`<html><head><title>2ª Via de Canhoto</title></head><body>`);
    janela.document.write(`<h2>2ª Via de Canhoto</h2>`);
    janela.document.write(`<p><strong>Código:</strong> ${codigo}</p>`);
    janela.document.write(`<p><strong>Data:</strong> ${data}</p>`);
    janela.document.write(`<p><strong>Vendedor:</strong> ${vendedor}</p>`);
    janela.document.write(`<p><strong>Valor:</strong> ${valor}</p>`);
    janela.document.write(`<p><strong>Pagamento:</strong> ${pagamento}</p>`);
    janela.document.write(`<p><strong>Produtos:</strong> ${produtos}</p>`);
    janela.document.write(`<p>Obrigado pela compra!</p>`);
    janela.document.write(`</body></html>`);
    janela.document.close();
    janela.focus();
    janela.print();
    janela.close();
}




/** Mostra o recibo da venda na barra lateral. */
function mostrarRecibo(produtos, total, formaPagamento, vendedor = "N/A") {
    const divConteudo = document.getElementById("reciboConteudo");
    const divRecibo = document.getElementById("reciboVenda");
    if (!divConteudo || !divRecibo) return;

    const dataHora = new Date().toLocaleString('pt-BR');
    let html = `
        <div class="recibo-header">Mundo Tech</div>
        <p>----------------------------------------</p>
        <p>Data: ${dataHora}</p>
        <p>Vendedor: ${vendedor}</p>
        <p>Pagamento: ${formaPagamento}</p>
        <p>----------------------------------------</p>
        <p><strong>Itens:</strong></p>
        <ul>
    `;
    produtos.forEach(p => {
        html += `<li>${p.qty}x ${p.description} ..... R$ ${(p.price * p.qty).toFixed(2)}</li>`;
    });
    html += `
        </ul>
        <p>----------------------------------------</p>
        <p><strong class="recibo-total">Total: R$ ${total.toFixed(2)}</strong></p>
        <p>----------------------------------------</p>
        <p class="recibo-footer">Obrigado pela preferência!</p>
    `;
    divConteudo.innerHTML = html;
    divRecibo.classList.add("active");
    divRecibo.style.display = "block";  // <-- força aparecer
  }


/** Retorna o nome do arquivo de imagem miniatura baseado no nome do produto. */
function obterImagemMiniatura(produtoNome) {
    if (!produtoNome) return null;
    const nome = produtoNome.toLowerCase();
    // Prioridade para combinações
    if (nome.includes('3d') && (nome.includes('privacidade') || nome.includes('fosca'))) return 'fosca-privacidade.png'; // 3D Privacidade/Fosca
    if (nome.includes('privacidade')) return 'fosca-privacidade.png'; // Privacidade (pode ser fosca ou não)
    if (nome.includes('black') && nome.includes('ceramica')) return 'ceramica-black.png'; // Cerâmica Black
    if (nome.includes('fosca') && nome.includes('ceramica')) return 'ceramica-fosca.png'; // Cerâmica Fosca
    // Tipos individuais
    if (nome.includes('3d')) return '3d-vidro.png'; // Qualquer 3D (geralmente vidro)
    if (nome.includes('black')) return 'ceramica-black.png'; // Qualquer Black (geralmente cerâmica)
    if (nome.includes('fosca')) return 'ceramica-fosca.png'; // Qualquer Fosca (geralmente cerâmica)
    if (nome.includes('ceramica')) return 'ceramica.png'; // Cerâmica comum
    if (nome.includes('vidro')) return 'vidro.png'; // Vidro comum (não 3D)
    // Adicione mais regras se necessário
    return null; // Nenhuma miniatura encontrada
}


// --- Inicialização Específica do Módulo (se necessário) ---
document.addEventListener('DOMContentLoaded', () => {
    console.log("[app-loja3.js] DOM carregado.");
    // Adiciona listener ao botão de busca principal, se ele não for tratado em ui-interactions
    const searchButton = document.getElementById('searchBtn');
    if (searchButton) {
        searchButton.addEventListener('click', () => buscarProdutos()); // Chama buscarProdutos sem argumento
    }
    renderCarrinho(); // Renderiza o carrinho inicial (vazio)
    // Outras inicializações, como carregar produtos iniciais, podem ir aqui
    // buscarProdutos(" "); // Exemplo: buscar tudo inicialmente? Cuidado com performance.
});

document.addEventListener("click", function(event) {
    const target = event.target;
    if (target.matches("[data-action='abrir-galeria']")) {
        const idGaleria = parseInt(target.getAttribute("data-galeria-id"));
        console.log("[UI] Clique em abrir-galeria, ID:", idGaleria);
        if (!isNaN(idGaleria)) {
            abrirGaleria(idGaleria);
        } else {
            console.warn("[UI] ID da galeria inválido ou não encontrado no atributo.");
        }
    }
});


console.log("[app-loja3.js] Script carregado.");