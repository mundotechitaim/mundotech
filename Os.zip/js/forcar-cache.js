// js/forcar-cache.js

document.addEventListener('DOMContentLoaded', () => {
    console.log("[FORÇAR CACHE] Script iniciado.");

    // Criar botão flutuante
    const botao = document.createElement('button');
    botao.id = 'btnForcarAtualizacao';
    botao.title = 'Forçar atualização (limpa cache e recarrega)';
    botao.innerHTML = '🔄'; // Ícone simples

    // Estilos flutuantes
    botao.style.position = 'fixed';
    botao.style.bottom = '20px';
    botao.style.left = '20px';    
    botao.style.zIndex = '9999';
    botao.style.padding = '12px 16px';
    botao.style.fontSize = '20px';
    botao.style.borderRadius = '50%';
    botao.style.border = 'none';
    botao.style.backgroundColor = '#ff5722';
    botao.style.color = '#fff';
    botao.style.cursor = 'pointer';
    botao.style.boxShadow = '0 2px 6px rgba(0,0,0,0.3)';
    botao.style.transition = 'transform 0.2s';

    // Efeito hover
    botao.addEventListener('mouseover', () => {
        botao.style.transform = 'scale(1.1)';
    });
    botao.addEventListener('mouseout', () => {
        botao.style.transform = 'scale(1)';
    });

    document.body.appendChild(botao);

    // Função para forçar atualização
    const forcarAtualizacao = async () => {
        console.log("[FORÇAR CACHE] Tentando limpar caches...");

        // Tentativa de limpar caches (se suportado)
        if ('caches' in window) {
            try {
                const names = await caches.keys();
                await Promise.all(names.map(name => caches.delete(name)));
                console.log("[FORÇAR CACHE] Caches excluídos com sucesso.");
            } catch (e) {
                console.warn("[FORÇAR CACHE] Falha ao limpar caches:", e);
            }
        } else {
            console.warn("[FORÇAR CACHE] API de Cache não suportada.");
        }

        // Recarregar com cache-buster
        const novaURL = window.location.href.split('?')[0] + '?updated=' + new Date().getTime();
        console.log("[FORÇAR CACHE] Recarregando para:", novaURL);
        window.location.href = novaURL;
    };

    botao.addEventListener('click', () => {
        if (confirm("Tem certeza que quer forçar atualização?\nIsso vai limpar cache (se possível) e recarregar a página.")) {
            forcarAtualizacao();
        }
    });
});
