// js/precos-feature.js

/**
 * Initializes the Price Consultation and Management Feature.
 * Handles fetching, displaying, editing, and adding prices for parts.
 */
function initPrecosFeature() {
    console.log("[Preços Feature V2] Inicializando...");

    // --- Configuration and Constants ---
    const PRECOS_PHP_PATH = 'precos.php'; // Adjust if necessary
    const COR_PRIMARIA = '#007bff';
    const COR_SECUNDARIA = '#6c757d';
    const COR_PERIGO = '#dc3545';
    const COR_SUCESSO = '#28a745';
    const COR_DESTAQUE_LINHA = '#fff3cd';

    const tecnicos = {
        '2411': 'Luiz',
        '3108': 'Alexandre',
        '1602': 'Lano'
    };

    const defaultCategories = [
        { text: 'Preço Frontal', value: 'Preco Frontal' },
        { text: 'Conector de Carga', value: 'Conector de Carga' },
        { text: 'Preço Bateria', value: 'Preco Bateria' },
        { text: 'Tampa Traseira', value: 'Tampa Traseira' }
    ];

    const categoryColumnIndex = {
        'Preco Frontal': 2,
        'Conector de Carga': 3,
        'Preco Bateria': 4,
        'Tampa Traseira': 5
    };

    // --- DOM Element Selectors ---
    const featureContainer = document.getElementById("pagina-precos");
    if (featureContainer) {
        featureContainer.classList.add("price-feature-container");
    }

    const searchInput = document.getElementById("priceSearchInput");
    const categorySelect = document.getElementById("priceCategory");
    const modelInput = document.getElementById("priceModelInput");
    const priceInput = document.getElementById("priceValueInput");
    const updateBtn = document.getElementById("priceUpdateBtn");
    const tableBody = document.querySelector('#priceListTable tbody');

    // --- Dynamic CSS Injection ---
    const estilosCSS = `
        :root {
            --cor-primaria: ${COR_PRIMARIA};
            --cor-secundaria: ${COR_SECUNDARIA};
            --cor-perigo: ${COR_PERIGO};
            --cor-sucesso: ${COR_SUCESSO};
            --cor-texto-claro: #fff;
            --cor-texto-escuro: #333;
            --cor-borda: #dee2e6;
            --cor-fundo-feature: #f4f7f9;
            --cor-fundo-tabela-header: #e9ecef;
            --cor-destaque-linha: ${COR_DESTAQUE_LINHA};
            --sombra-padrao: 0 2px 8px rgba(0,0,0,0.1);
        }

        .price-feature-container {
            padding: 25px;
            background-color: var(--cor-fundo-feature);
            border-radius: 8px;
        }

        .price-controls-form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            box-shadow: var(--sombra-padrao);
        }

        .price-controls-form .form-row-flex {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: flex-end;
        }

        .price-controls-form .form-group {
            flex: 1;
            min-width: 180px;
            display: flex;
            flex-direction: column;
        }

        .price-controls-form label {
            margin-bottom: .3rem;
            font-weight: 500;
            color: #555;
            font-size: 0.9rem;
        }

        .price-controls-form .form-control,
        .price-controls-form .custom-select {
            padding: 0.6rem 0.75rem;
            border: 1px solid var(--cor-borda);
            border-radius: 5px;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
            font-size: 0.95rem;
        }
        .price-controls-form .form-control:focus,
        .price-controls-form .custom-select:focus {
            border-color: var(--cor-primaria);
            box-shadow: 0 0 0 0.2rem color-mix(in srgb, var(--cor-primaria) 25%, transparent);
            outline: none;
        }

        .price-controls-form .btn-update-price {
            background-color: var(--cor-primaria);
            color: var(--cor-texto-claro);
            border: none;
            padding: 0.6rem 1rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.2s ease, transform 0.1s ease;
            font-weight: 500;
            height: fit-content;
        }
        .price-controls-form .btn-update-price:hover {
            background-color: color-mix(in srgb, var(--cor-primaria) 85%, black);
            transform: translateY(-1px);
        }
        .price-controls-form .btn-update-price:active {
            transform: translateY(0);
        }
        .price-controls-form .btn-update-price svg {
            margin-right: 8px;
        }

        #priceSearchInput {
            margin-bottom: 15px;
            padding: 0.75rem;
            border-radius: 5px;
            border: 1px solid var(--cor-borda);
        }

        .price-table-container {
            background-color: #fff;
            padding: 10px;
            border-radius: 8px;
            box-shadow: var(--sombra-padrao);
            overflow-x: auto;
        }

        #priceListTable {
            margin-bottom: 0;
        }
        #priceListTable thead th {
            background-color: var(--cor-fundo-tabela-header);
            color: var(--cor-texto-escuro);
            font-weight: 600;
            border-bottom-width: 2px;
        }
        #priceListTable tbody td {
            vertical-align: middle;
            transition: background-color 0.3s ease;
        }
        #priceListTable tbody tr:hover td {
            background-color: #f1f3f5;
        }
        #priceListTable .editable-price {
            cursor: pointer;
            font-weight: 500;
        }
        #priceListTable .editable-price:hover {
            color: var(--cor-primaria);
            text-decoration: underline;
        }
        #priceListTable .brand-icon {
            margin-right: 8px;
            font-size: 1.1em;
        }
        .brand-samsung { color: #1256cc; }
        .brand-apple { color: #555; }
        .brand-motorola { color: #e20000; }
        .brand-lg { color: #a50034; }
        .brand-xiaomi { color: #ff6900; }

        #priceListTable .price-action-btn,
        #priceListTable .btn-delete-row {
            padding: 0.25rem 0.5rem;
            font-size: 0.8rem;
            margin: 2px;
            border: 1px solid transparent;
            transition: all 0.2s ease;
        }
         #priceListTable .price-action-btn {
            background-color: transparent;
            border-color: var(--cor-secundaria);
            color: var(--cor-secundaria);
        }
        #priceListTable .price-action-btn:hover {
            background-color: var(--cor-secundaria);
            color: var(--cor-texto-claro);
        }
        #priceListTable .btn-delete-row {
            background-color: transparent;
            border-color: var(--cor-perigo);
            color: var(--cor-perigo);
        }
        #priceListTable .btn-delete-row:hover {
            background-color: var(--cor-perigo);
            color: var(--cor-texto-claro);
        }
        #priceListTable .btn-delete-row svg,
        #priceListTable .price-action-btn svg {
            width: 1em; height: 1em; vertical-align: -0.125em;
        }

        .loading-overlay {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background-color: rgba(255,255,255,0.8);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 1050;
            transition: opacity 0.3s ease;
            opacity: 0;
            pointer-events: none;
        }
        .loading-overlay.visible {
            opacity: 1;
            pointer-events: auto;
        }
        .spinner {
            width: 50px; height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid var(--cor-primaria);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 15px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .highlight-row {
            animation: highlightAnimation 2s ease;
        }
        @keyframes highlightAnimation {
            0% { background-color: var(--cor-destaque-linha); }
            100% { background-color: transparent; }
        }
    `;
    const styleSheet = document.createElement("style");
    styleSheet.type = "text/css";
    styleSheet.innerText = estilosCSS;
    document.head.appendChild(styleSheet);

    // --- Dynamic Category Select Population ---
    if (categorySelect) {
        categorySelect.innerHTML = '<option value="">Selecione a categoria...</option>';
        defaultCategories.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat.value;
            opt.textContent = cat.text;
            categorySelect.appendChild(opt);
        });
    }

    // --- Essential Element Check ---
    if (!featureContainer || !tableBody || !searchInput || !updateBtn || !categorySelect || !modelInput || !priceInput) {
        console.error("[Preços Feature] Erro: Um ou mais elementos essenciais não encontrados no DOM.");
        if (featureContainer) {
            featureContainer.innerHTML = "<p class='text-danger p-3'>Erro crítico: A página de consulta de preços não pôde ser carregada. Verifique o console.</p>";
        }
        return;
    }

    // --- Application State ---
    let data = []; // Stores price data
    let isLoading = false;

    // --- UI Helper Functions ---

    /**
     * Shows or hides the loading overlay.
     * @param {boolean} show - True to show, false to hide.
     */
    function showLoading(show) {
        isLoading = show;
        let overlay = document.getElementById('featureLoadingOverlay');
        if (show) {
            if (!overlay) {
                overlay = document.createElement('div');
                overlay.id = 'featureLoadingOverlay';
                overlay.className = 'loading-overlay';
                overlay.innerHTML = '<div class="spinner"></div><p>Processando...</p>';
                document.body.appendChild(overlay);
            }
            overlay.classList.add('visible');
            if (updateBtn) updateBtn.disabled = true;
            if (searchInput) searchInput.disabled = true;
        } else {
            if (overlay) {
                overlay.classList.remove('visible');
            }
            if (updateBtn) updateBtn.disabled = false;
            if (searchInput) searchInput.disabled = false;
        }
    }

    /**
     * Highlights a specific row in the table and scrolls it into view.
     * @param {number} rowIndex - The index of the row to highlight.
     */
    function highlightRow(rowIndex) {
        if (rowIndex !== -1 && rowIndex < tableBody.rows.length) {
            const rowElement = tableBody.rows[rowIndex];
            if (rowElement) {
                rowElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                rowElement.classList.add('highlight-row');
                setTimeout(() => {
                    rowElement.classList.remove('highlight-row');
                }, 2000);
            }
        }
    }

    // --- Data Manipulation Functions ---

    /**
     * Fetches price data from the server.
     * @async
     */
    async function fetchPrices() {
        console.log("[Preços Feature] Buscando preços do servidor...");
        showLoading(true);
        tableBody.innerHTML = `<tr><td colspan="7" class="text-center py-5">Carregando dados...</td></tr>`;

        try {
            const response = await fetch(PRECOS_PHP_PATH + `?ts=${Date.now()}`); // ts for cache busting
            if (!response.ok) {
                throw new Error(`Erro HTTP: ${response.status} - ${response.statusText}`);
            }
            const prices = await response.json();
            data = Array.isArray(prices) ? prices : []; // Ensure data is an array
            console.log("✅ [Preços Feature] Preços carregados:", data.length, "registros.");
            populateTable();
        } catch (error) {
            console.error("❌ [Preços Feature] Erro ao carregar preços:", error);
            data = []; // Reset data on error
            tableBody.innerHTML = `<tr><td colspan="7" class="text-center text-danger py-5">Erro ao carregar preços: ${error.message}</td></tr>`;
        } finally {
            showLoading(false);
        }
    }

    /**
     * Saves the current price data to the server.
     * @async
     */
    async function saveData() {
        console.log("💾 [Preços Feature] Enviando dados para salvar...");
        showLoading(true);
        try {
            const response = await fetch(PRECOS_PHP_PATH, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            if (result.success) {
                console.log("✔️ [Preços Feature] Dados salvos no servidor com sucesso.");
                // Consider using a more user-friendly notification (e.g., SweetAlert2)
            } else {
                console.error("❌ [Preços Feature] Erro ao salvar no servidor:", result.message);
                alert(`Erro ao salvar os dados no servidor: ${result.message || 'Erro desconhecido.'}`);
            }
        } catch (error) {
            console.error("❌ [Preços Feature] Erro na requisição para salvar:", error);
            alert(`Erro de rede ao tentar salvar os dados: ${error.message}`);
        } finally {
            showLoading(false);
        }
    }

    /**
     * Formats a raw price value into a displayable string (e.g., "R$ 150,00").
     * @param {string|number} value - The raw price value.
     * @returns {string} The formatted price string, or "R$ NaN" if invalid.
     */
    function formatPrice(value) {
        const priceStr = String(value).replace(/[^\d,.]/g, "").replace(",", ".");
        const priceNum = parseFloat(priceStr);
        if (isNaN(priceNum)) {
            return "R$ NaN";
        }
        return `R$ ${priceNum.toFixed(2).replace(".", ",")}`;
    }

    /**
     * Gets the Font Awesome icon class based on the brand name.
     * @param {string} [brandName=''] - The name of the brand.
     * @returns {string} The CSS class for the brand icon, or an empty string.
     */
    function getBrandIconClass(brandName = '') {
        const brand = String(brandName).toUpperCase(); // Ensure brandName is a string
        if (brand.includes('SAMSUNG')) return 'fab fa-android brand-samsung';
        if (brand.includes('IPHONE') || brand.includes('IPAD')) return 'fab fa-apple brand-apple';
        if (brand.includes('MOTOROLA')) return 'fas fa-mobile-alt brand-motorola'; // Generic mobile for others
        if (brand.includes('LG')) return 'fas fa-mobile-alt brand-lg';
        if (brand.includes('XIAOMI')) return 'fas fa-mobile-alt brand-xiaomi';
        return ''; // No specific icon
    }

    /**
     * Tries to guess the brand from the model name.
     * @param {string} modelName - The model name.
     * @returns {string} The guessed brand name or "N/A".
     */
    function guessBrandFromModel(modelName) {
        const modelUpper = String(modelName).toUpperCase();
        if (modelUpper.startsWith("A") || modelUpper.startsWith("S") || modelUpper.startsWith("M") || modelUpper.startsWith("J") || modelUpper.includes("GALAXY")) return "SAMSUNG";
        if (modelUpper.includes("IPHONE") || modelUpper.includes("IPAD")) return "IPHONE";
        if (modelUpper.startsWith("MOTO") || modelUpper.startsWith("G ") || modelUpper.startsWith("E ") || modelUpper.startsWith("EDGE")) return "MOTOROLA";
        if (modelUpper.startsWith("REDMI") || modelUpper.startsWith("NOTE") || modelUpper.startsWith("POCO") || modelUpper.startsWith("MI ")) return "XIAOMI";
        if (modelUpper.startsWith("K")) return "LG";
        return "N/A";
    }

    // --- Business Logic and Interaction Functions ---

    /**
     * Prompts for a technician's password and validates it.
     * @returns {string|null} The technician's name if valid, otherwise null.
     */
    function validarSenha() {
        const senha = prompt("🔐 Digite a senha do técnico para continuar:");
        if (senha === null) { // User pressed Cancel or Esc
            console.log("🔒 Ação cancelada pelo usuário (senha não inserida).");
            return null;
        }
        if (tecnicos[senha]) {
            console.log(`✅ Acesso autorizado: ${tecnicos[senha]}`);
            return tecnicos[senha];
        } else {
            alert("❌ Senha inválida. Ação cancelada.");
            return null;
        }
    }

    /**
     * Populates the HTML table with the current price data.
     */
    function populateTable() {
        console.log("[Preços Feature] Populando tabela...");
        tableBody.innerHTML = ""; // Clear existing rows

        if (!Array.isArray(data) || data.length === 0) {
            tableBody.innerHTML = `<tr><td colspan="7" class="text-center py-4">Nenhum preço cadastrado.</td></tr>`;
            return;
        }

        const editIconSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16"><path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/><path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/></svg>`;
        const deleteIconSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16"><path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z"/></svg>`;

        data.forEach((item, index) => {
            if (!Array.isArray(item)) {
                console.warn(`[Preços Feature] Ignorando linha ${index}: não é um array. Conteúdo:`, item);
                return;
            }
            // Ensure row has at least 6 columns, padding with '-' if necessary
            while (item.length < 6) item.push('-');

            const row = tableBody.insertRow();

            // Columns 0 (Brand) and 1 (Model)
            for (let i = 0; i < 2; i++) {
                const cell = row.insertCell();
                const cellValue = item[i] ?? ''; // Default to empty string if null/undefined
                cell.textContent = cellValue;
                if (i === 0) { // Brand column
                    const iconClass = getBrandIconClass(cellValue);
                    if (iconClass) {
                        cell.innerHTML = `<i class="${iconClass} brand-icon"></i> ${cellValue}`;
                    }
                }
            }

            // Price category columns (2 to 5)
            for (let cellIdx = 2; cellIdx < 6; cellIdx++) {
                const cell = row.insertCell();
                const priceValue = item[cellIdx] ?? '-'; // Default to '-'
                cell.textContent = priceValue;
                cell.classList.add("editable-price");
                cell.dataset.index = index;
                cell.dataset.cellIndex = cellIdx;
            }

            // Actions column
            const actionCell = row.insertCell();
            actionCell.classList.add('text-center');

            // Add edit buttons for each price category
            Object.entries(categoryColumnIndex).forEach(([categoryName, catCellIdx]) => {
                const editBtn = document.createElement('button');
                editBtn.innerHTML = editIconSVG;
                editBtn.title = `Editar ${categoryName}`;
                editBtn.classList.add("btn", "btn-sm", "price-action-btn");
                editBtn.dataset.action = "editar-preco-direto";
                editBtn.dataset.index = index;
                editBtn.dataset.cellIndex = catCellIdx;
                actionCell.appendChild(editBtn);
            });

            // Add delete button for the row
            const deleteBtn = document.createElement('button');
            deleteBtn.innerHTML = deleteIconSVG;
            deleteBtn.title = 'Excluir Linha';
            deleteBtn.classList.add("btn", "btn-sm", "btn-delete-row");
            deleteBtn.dataset.action = "excluir-linha";
            deleteBtn.dataset.index = index;
            actionCell.appendChild(deleteBtn);
        });
    }

    /**
     * Handles editing a specific price cell.
     * @param {number} index - The row index.
     * @param {number} cellIndex - The cell (column) index for the price.
     */
    function editPrice(index, cellIndex) {
        const tecnico = validarSenha();
        if (!tecnico) return;

        if (index < 0 || index >= data.length || !data[index] || cellIndex < 2 || cellIndex >= data[index].length) {
            console.error("[Preços Feature] Índice inválido para edição:", index, cellIndex);
            alert("Erro: Não foi possível editar o preço. Dados inválidos.");
            return;
        }

        const currentPrice = data[index][cellIndex] ?? '';
        const modelName = data[index][1] ?? 'Modelo Desconhecido';
        const columnName = Object.keys(categoryColumnIndex).find(key => categoryColumnIndex[key] === cellIndex) || `Coluna ${cellIndex + 1}`;

        console.log(`✏️ [${tecnico}] Editando "${columnName}" para "${modelName}" (Linha ${index + 1}, Col ${cellIndex + 1})`);
        const newPriceRaw = prompt(
            `Editar ${columnName} para "${modelName}":\nValor atual: ${currentPrice}\n\nDigite o novo valor (ou deixe vazio para '-', ou 'Não Trabalhamos'):`,
            currentPrice.toString().replace(/R\$\s*/, '').replace(',', '.') // Pre-fill with numeric value
        );

        if (newPriceRaw === null) { // User cancelled
            console.log("[Preços Feature] Edição cancelada.");
            return;
        }

        let formattedNewPrice;
        const trimmedPrice = newPriceRaw.trim();
        if (trimmedPrice === '' || trimmedPrice.toLowerCase() === 'não trabalhamos' || trimmedPrice === '-') {
            formattedNewPrice = trimmedPrice === '' ? '-' : 'Não Trabalhamos';
        } else {
            formattedNewPrice = formatPrice(trimmedPrice);
            if (formattedNewPrice.includes("NaN")) {
                alert("⚠️ Valor inválido. Insira um número (ex: 150 ou 150,00) ou um texto válido ('-', 'Não Trabalhamos').");
                return;
            }
        }

        data[index][cellIndex] = formattedNewPrice;
        console.log(`✅ [${tecnico}] Preço atualizado para: ${formattedNewPrice}`);
        saveData().then(() => {
            populateTable();
            highlightRow(index);
        });
    }

    /**
     * Handles deleting a row from the price list.
     * @param {number} index - The index of the row to delete.
     */
    function deleteRow(index) {
        const tecnico = validarSenha();
        if (!tecnico) return;

        if (index < 0 || index >= data.length) {
            console.error("[Preços Feature] Índice inválido para exclusão:", index);
            alert("Erro: Não foi possível excluir. Linha não encontrada.");
            return;
        }

        const modelNameToDelete = data[index][1] ?? 'esta linha';
        if (!confirm(`Tem certeza que deseja excluir o modelo "${modelNameToDelete}" da lista?`)) {
            console.log("[Preços Feature] Exclusão cancelada pelo usuário.");
            return;
        }

        console.log(`🗑️ [${tecnico}] Excluindo linha ${index + 1}:`, data[index]);
        data.splice(index, 1);
        saveData().then(populateTable); // Save and then update the table
    }

    /**
     * Updates an existing price or adds a new price entry.
     */
    function updateOrAddPrice() {
        const tecnico = validarSenha();
        if (!tecnico) return;

        const model = modelInput.value.trim().toUpperCase();
        const priceRaw = priceInput.value.trim();
        const category = categorySelect.value;

        if (!model || !priceRaw || !category) {
            alert("⚠️ Por favor, preencha Categoria, Modelo e Novo Preço.");
            return;
        }

        const columnIndex = categoryColumnIndex[category];
        if (columnIndex === undefined) {
            alert("⚠️ Categoria de preço inválida selecionada.");
            return;
        }

        let formattedNewPrice;
        if (priceRaw === '' || priceRaw.toLowerCase() === 'não trabalhamos' || priceRaw === '-') {
            formattedNewPrice = priceRaw === '' ? '-' : 'Não Trabalhamos';
        } else {
            formattedNewPrice = formatPrice(priceRaw);
            if (formattedNewPrice.includes("NaN")) {
                alert("⚠️ Valor de preço inválido. Insira um número (ex: 150 ou 150,00) ou texto válido.");
                return;
            }
        }

        let foundRowIndex = data.findIndex(row => Array.isArray(row) && row[1] && row[1].toUpperCase() === model);
        let updatedRowVisualIndex = -1;

        if (foundRowIndex !== -1) {
            console.log(`[${tecnico}] Modelo "${model}" encontrado. Atualizando ${category}.`);
            while (data[foundRowIndex].length <= columnIndex) data[foundRowIndex].push('-'); // Ensure column exists
            data[foundRowIndex][columnIndex] = formattedNewPrice;
            updatedRowVisualIndex = foundRowIndex;
        } else {
            console.log(`[${tecnico}] Modelo "${model}" não encontrado. Adicionando nova linha.`);
            const brand = guessBrandFromModel(model);
            const newRow = [brand, model, '-', '-', '-', '-']; // Initialize with defaults
            newRow[columnIndex] = formattedNewPrice;
            data.push(newRow);
            updatedRowVisualIndex = data.length - 1;
        }

        saveData().then(() => {
            populateTable();
            modelInput.value = ''; // Clear inputs after successful operation
            priceInput.value = '';
            categorySelect.selectedIndex = 0;
            modelInput.focus();
            if (updatedRowVisualIndex !== -1) {
                highlightRow(updatedRowVisualIndex);
            }
        });
    }

    // --- Event Listeners ---
    searchInput.addEventListener("keyup", function () {
        const filter = this.value.toLowerCase();
        const rows = tableBody.rows;
        for (let i = 0; i < rows.length; i++) {
            const rowText = rows[i].textContent || rows[i].innerText || "";
            rows[i].style.display = rowText.toLowerCase().includes(filter) ? "" : "none";
        }
    });

    updateBtn.addEventListener("click", updateOrAddPrice);

    tableBody.addEventListener("click", function (event) {
        if (isLoading) return; // Prevent actions while loading

        const target = event.target.closest('button, td.editable-price');
        if (!target) return;

        const action = target.dataset.action || (target.classList.contains('editable-price') ? 'editar-preco-direto' : null);
        const rowIndex = parseInt(target.dataset.index, 10);
        const cellIndex = parseInt(target.dataset.cellIndex, 10); // For price cells or edit buttons

        if (isNaN(rowIndex)) return; // Row index is essential

        switch (action) {
            case "editar-preco-direto":
                if (!isNaN(cellIndex)) {
                    editPrice(rowIndex, cellIndex);
                }
                break;
            case "excluir-linha":
                deleteRow(rowIndex);
                break;
        }
    });

    // --- Initialization ---
    fetchPrices();

} // End of initPrecosFeature

// --- Entry Point ---
// Initialize the feature only if the specific page container is present.
if (document.getElementById('pagina-precos')) {
    // Ensure DOM is fully loaded before initializing, especially if script is in <head>
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initPrecosFeature);
    } else {
        initPrecosFeature();
    }
} else {
    console.log("[Preços Feature V2] Elemento #pagina-precos não encontrado. Feature não inicializada.");
}

// To allow external calls if ever needed (optional)
// window.initPrecosFeature = initPrecosFeature;

console.log("[precos-feature.js V2] Script carregado e pronto.");