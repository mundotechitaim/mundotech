// js/carrinho.js

const Carrinho = (() => {
    // --- Estado Interno do Módulo ---
    let itensCarrinho = []; // Renomeado para evitar conflito com o ID 'carrinho'

    // --- Referências a Elementos DOM (obtidas quando necessário) ---
    // É melhor obter os elementos dentro das funções que os usam,
    // ou passá-los como argumentos, para garantir que existam quando chamados.

    // --- Funções Auxiliares (Dependências) ---
    // Assume que mostrarAlerta está disponível globalmente (de app-loja3.js por enquanto)
    // Idealmente, isso também seria modularizado ou injetado como dependência.
    const mostrarAlerta = window.mostrarAlerta;

    // --- Funções Principais do Módulo ---

    /** Renderiza o conteúdo do carrinho na barra lateral. */
    function render() {
        const container = document.getElementById('carrinho');
        const totalCarrinhoElement = document.querySelector('#carrinhoSidebar #valorTotalCarrinho'); // ID correto do total

        if (!container || !totalCarrinhoElement) {
            console.error("[Carrinho.render] Elementos do carrinho não encontrados no DOM.");
            return 0; // Retorna 0 se não puder renderizar
        }

        container.innerHTML = ''; // Limpa antes de renderizar
        let total = 0;

        if (itensCarrinho.length === 0) {
            container.innerHTML = '<p style="padding: 10px; text-align: center; color: #6c757d;">Carrinho vazio.</p>';
        } else {
            itensCarrinho.forEach((item, i) => {
                const subtotal = (item.price ?? 0) * item.qty;
                total += subtotal;
                // Adiciona data-* para a ação de remover
                container.innerHTML += `
                    <div class="cart-item">
                        <span class="item-name">${item.description}</span>
                        <span class="item-qty">Qtd: ${item.qty}</span>
                        <span class="item-subtotal">Sub: R$ ${subtotal.toFixed(2).replace('.', ',')}</span>
                        <button class="btn-remove-item" data-action="remover-item-carrinho" data-index="${i}" title="Remover Item">✖</button>
                    </div>
                `;
            });
        }
        // Atualiza o total exibido
        totalCarrinhoElement.textContent = `R$ ${total.toFixed(2).replace('.', ',')}`;
        console.debug("[Carrinho.render] Carrinho renderizado. Total:", total);
        return total; // Retorna o total calculado
    }

    /** Adiciona um produto ao carrinho ou incrementa quantidade. */
    function adicionar(prod) {
        if (!prod || !prod.uid) {
            console.error("[Carrinho.adicionar] Produto inválido:", prod);
            if (mostrarAlerta) mostrarAlerta("Erro ao adicionar produto.", "error");
            return;
        }
        try {
            const existente = itensCarrinho.find(p => p.uid === prod.uid);
            if (existente) {
                // Verifica estoque ANTES de adicionar mais (se a informação de estoque estiver no 'prod')
                const estoqueDisponivel = prod.current_stock ?? Infinity; // Se não tiver estoque, assume infinito
                if (existente.qty < estoqueDisponivel) {
                     existente.qty += 1;
                     if (mostrarAlerta) mostrarAlerta(`${prod.description} adicionado!`, "success");
                } else {
                    if (mostrarAlerta) mostrarAlerta(`Estoque máximo de ${prod.description} atingido no carrinho.`, "warning");
                    return; // Não adiciona se estoque esgotou
                }

            } else {
                // Adiciona apenas os dados essenciais ao carrinho
                 const estoqueDisponivel = prod.current_stock ?? Infinity;
                 if (1 <= estoqueDisponivel) { // Verifica se há estoque para o primeiro item
                    itensCarrinho.push({
                        uid: prod.uid,
                        description: prod.description,
                        price: prod.price ?? 0,
                        code: prod.code,
                        // Adicione outros campos se forem necessários para a venda/recibo
                        qty: 1
                    });
                     if (mostrarAlerta) mostrarAlerta(`${prod.description} adicionado!`, "success");
                 } else {
                     if (mostrarAlerta) mostrarAlerta(`Produto ${prod.description} sem estoque.`, "error");
                     return; // Não adiciona se não tem estoque inicial
                 }

            }
            render(); // Atualiza a UI
            console.debug("[Carrinho.adicionar] Item adicionado/incrementado:", prod.description, itensCarrinho);
        } catch (error) {
            console.error("[Carrinho.adicionar] Erro:", error);
            if (mostrarAlerta) mostrarAlerta("Erro ao processar adição ao carrinho.", "error");
        }
    }

    /** Remove um item do carrinho pelo índice. */
    function remover(index) {
         const idx = parseInt(index, 10); // Garante que é número
        if (!isNaN(idx) && idx >= 0 && idx < itensCarrinho.length) {
            const itemRemovido = itensCarrinho.splice(idx, 1);
            console.debug("[Carrinho.remover] Item removido:", itemRemovido[0]?.description);
            render(); // Atualiza a UI
            if (mostrarAlerta) mostrarAlerta("Item removido do carrinho.", "info");
        } else {
            console.error("[Carrinho.remover] Índice inválido:", index);
        }
    }

    /** Limpa todos os itens do carrinho. */
    function limpar() {
        itensCarrinho = [];
        console.debug("[Carrinho.limpar] Carrinho limpo.");
        render();
    }

    /** Retorna uma cópia dos itens atuais do carrinho */
    function getItens() {
        // Retorna uma cópia para evitar modificação externa direta do array original
        return JSON.parse(JSON.stringify(itensCarrinho));
    }

    // --- API Pública do Módulo ---
    // Expõe as funções que precisam ser acessadas de fora
    return {
        adicionar: adicionar,
        remover: remover,
        render: render,
        limpar: limpar,
        getItens: getItens
    };

})(); // Executa a IIFE e atribui o resultado a Carrinho

console.log("[carrinho.js] Módulo Carrinho inicializado.");