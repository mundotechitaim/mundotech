<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Recebe email e senha do frontend
$data = json_decode(file_get_contents("php://input"), true);
if (!isset($data['email']) || !isset($data['senha'])) {
    echo json_encode(["success" => false, "error" => "Credenciais inválidas"]);
    exit;
}

$cookieFile = __DIR__ . '/cookie.txt';

// 1. Primeiro acesso: GET na tela de login para pegar cookies e token
$ch1 = curl_init("https://www.mundotechip.com.br/index.php/login");
curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch1, CURLOPT_COOKIEJAR, $cookieFile);
curl_setopt($ch1, CURLOPT_COOKIEFILE, $cookieFile);
curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, false); // Só em localhost
curl_exec($ch1);
curl_close($ch1);

// 2. Lê o token do cookie salvo
$token = null;
if (file_exists($cookieFile)) {
    $lines = file($cookieFile);
    foreach ($lines as $line) {
        if (stripos($line, 'MAPOS_COOKIE') !== false) {
            $parts = preg_split('/\s+/', trim($line));
            $token = $parts[count($parts) - 1];
            break;
        }
    }
}

if (!$token) {
    echo json_encode(["success" => false, "error" => "Token MAPOS não encontrado"]);
    exit;
}

// 3. Faz o login POST
$postData = http_build_query([
    "MAPOS_TOKEN" => $token,
    "email" => $data['email'],
    "senha" => $data['senha']
]);

$ch2 = curl_init("https://www.mundotechip.com.br/index.php/login/verificarLogin?ajax=true");
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch2, CURLOPT_POSTFIELDS, $postData);
curl_setopt($ch2, CURLOPT_POST, true);
curl_setopt($ch2, CURLOPT_COOKIEFILE, $cookieFile);
curl_setopt($ch2, CURLOPT_COOKIEJAR, $cookieFile);
curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch2, CURLOPT_HTTPHEADER, [
    'Content-Type: application/x-www-form-urlencoded',
    'X-Requested-With: XMLHttpRequest'
]);

$resposta = curl_exec($ch2);
$http_code = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
curl_close($ch2);

// 4. Valida retorno
if ($http_code === 200 && strpos($resposta, '"result":true') !== false) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode([
        "success" => false,
        "error" => "Erro ao fazer login",
        "http_code" => $http_code,
        "resposta" => $resposta
    ]);
}
