const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(bodyParser.json({ limit: '20mb' }));

// Configuração banco
const db = mysql.createConnection({
    host: 'auth-db1198.hstgr.io',
    user: 'u632764491_PDV',
    password: 'S@s@1509',
    database: 'u632764491_PDV'
});

db.connect(err => {
    if (err) throw err;
    console.log('✅ Conectado ao MySQL');
});

app.get('/', (req, res) => {
    res.send('🚀 API do PDV Mundo Tech rodando!');
});

// Produtos
app.get('/produtos', (req, res) => {
    db.query('SELECT * FROM produtos', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.post('/produtos', (req, res) => {
    const { uid, descricao, codigo_barras, preco, estoque, categoria, imagem_base64 } = req.body;
    if (!uid || !descricao || preco == null || estoque == null) {
        return res.status(400).json({ error: 'Campos obrigatórios faltando' });
    }
    const sql = 'INSERT INTO produtos (uid, descricao, codigo_barras, preco, estoque, categoria, imagem_base64) VALUES (?, ?, ?, ?, ?, ?, ?)';
    db.query(sql, [uid, descricao, codigo_barras, preco, estoque, categoria, imagem_base64], (err, result) => {
        if (err) return res.status(500).send(err);
        res.json({ id: result.insertId });
    });
});

app.put('/produtos/:uid', (req, res) => {
    const { uid } = req.params;
    const { descricao, codigo_barras, preco, estoque, categoria, imagem_base64 } = req.body;
    const sql = 'UPDATE produtos SET descricao=?, codigo_barras=?, preco=?, estoque=?, categoria=?, imagem_base64=? WHERE uid=?';
    db.query(sql, [descricao, codigo_barras, preco, estoque, categoria, imagem_base64, uid], (err) => {
        if (err) return res.status(500).send(err);
        res.send('Produto atualizado');
    });
});

// Vendas
app.post('/vendas', (req, res) => {
    console.log("[DEBUG vendas POST] body recebido:", req.body);
    const { data_venda, valor_total, forma_pagamento, vendedor } = req.body;

    if (!data_venda || !valor_total || !forma_pagamento || !vendedor) {
        return res.status(400).json({ error: 'Campos obrigatórios faltando' });
    }

    const sql = 'INSERT INTO vendas (data_venda, valor_total, forma_pagamento, vendedor) VALUES (?, ?, ?, ?)';
    db.query(sql, [data_venda, valor_total, forma_pagamento, vendedor], (err, result) => {
        if (err) return res.status(500).send(err);
        res.json({ id: result.insertId });
    });
});


app.post('/vendas/:venda_id/itens', (req, res) => {
    const { venda_id } = req.params;
    const { produto_uid, quantidade, preco_unitario } = req.body;
    const sql = 'INSERT INTO vendas_itens (venda_id, produto_uid, quantidade, preco_unitario) VALUES (?, ?, ?, ?)';
    db.query(sql, [venda_id, produto_uid, quantidade, preco_unitario], (err, result) => {
        if (err) return res.status(500).send(err);
        res.json({ id: result.insertId });
    });
});

// Relatórios de Vendas
app.get('/relatorios/vendas/diario', (req, res) => {
    const sql = `
        SELECT DATE(data_venda) as data, COUNT(*) as qtd_vendas, SUM(valor_total) as total_vendas
        FROM vendas
        GROUP BY DATE(data_venda)
        ORDER BY DATE(data_venda) DESC
        LIMIT 30
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.get('/relatorios/vendas/mensal', (req, res) => {
    const sql = `
        SELECT DATE_FORMAT(data_venda, '%Y-%m') AS mes, COUNT(*) AS qtd_vendas, SUM(valor_total) AS total_vendas
        FROM vendas
        GROUP BY mes
        ORDER BY mes DESC
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.get('/relatorios/vendas/formas-pagamento', (req, res) => {
    const sql = `
        SELECT forma_pagamento, COUNT(*) AS qtd, SUM(valor_total) AS total
        FROM vendas
        GROUP BY forma_pagamento
        ORDER BY total DESC
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.get('/relatorios/vendas/vendedores', (req, res) => {
    const sql = `
        SELECT vendedor, COUNT(*) AS qtd, SUM(valor_total) AS total
        FROM vendas
        GROUP BY vendedor
        ORDER BY total DESC
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.get('/relatorios/vendas/ticket-medio', (req, res) => {
    const sql = `
        SELECT AVG(valor_total) AS ticket_medio, SUM(valor_total)/COUNT(DISTINCT vendedor) AS ticket_medio_por_vendedor
        FROM vendas
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results[0]);
    });
});

// Ordem de Serviço
app.post('/ordem-servico', (req, res) => {
    const { cliente_nome, cliente_cpf, cliente_celular, cliente_endereco, descricao_produto, defeito, observacoes, laudo_tecnico, status, data_inicial, data_final, garantia, valor_total } = req.body;
    const sql = 'INSERT INTO ordem_servico (cliente_nome, cliente_cpf, cliente_celular, cliente_endereco, descricao_produto, defeito, observacoes, laudo_tecnico, status, data_inicial, data_final, garantia, valor_total) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
    db.query(sql, [cliente_nome, cliente_cpf, cliente_celular, cliente_endereco, descricao_produto, defeito, observacoes, laudo_tecnico, status, data_inicial, data_final, garantia, valor_total], (err, result) => {
        if (err) return res.status(500).send(err);
        res.json({ id: result.insertId });
    });
});

app.post('/ordem-servico/:id/itens', (req, res) => {
    const { id } = req.params;
    const { item_nome, quantidade, preco_unitario } = req.body;
    const sql = 'INSERT INTO ordem_servico_itens (ordem_servico_id, item_nome, quantidade, preco_unitario) VALUES (?, ?, ?, ?)';
    db.query(sql, [id, item_nome, quantidade, preco_unitario], (err, result) => {
        if (err) return res.status(500).send(err);
        res.json({ id: result.insertId });
    });
});

// Alertas de Estoque
app.get('/alertas', (req, res) => {
    db.query('SELECT * FROM alertas_estoque', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.post('/alertas', (req, res) => {
    const { produto_uid, estoque_atual, estoque_minimo, loja } = req.body;
    const sql = 'INSERT INTO alertas_estoque (produto_uid, estoque_atual, estoque_minimo, loja) VALUES (?, ?, ?, ?)';
    db.query(sql, [produto_uid, estoque_atual, estoque_minimo, loja], (err, result) => {
        if (err) return res.status(500).send(err);
        res.json({ id: result.insertId });
    });
});

// Inicia o servidor
app.listen(3000, () => {
    console.log('🚀 Servidor rodando em http://localhost:3000');
});
