
const express = require('express');
const fetch = require('node-fetch');
const cheerio = require('cheerio');
const cors = require('cors');

const app = express();

app.use(cors({
  origin: function (origin, callback) {
    const allowedOrigins = ['http://localhost:8081', 'https://mundotechip.com.br'];
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Origem não permitida pelo CORS'));
    }
  },
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type'],
}));


// Aumenta os limites de payload para imagens base64 grandes
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Endpoint 1 – Converte imagem externa em Base64
app.post('/convert-base64', async (req, res) => {
    const { url } = req.body;
    console.log('📥 [convert-base64] URL recebida:', url);

    if (!url) {
        return res.status(400).json({ error: 'URL não fornecida.' });
    }

    try {
        const response = await fetch(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
                'Referer': 'https://www.google.com',
            }
        });

        if (!response.ok) throw new Error(`Erro ao buscar imagem: ${response.status}`);

        const buffer = await response.buffer();
        const mimeType = response.headers.get('content-type') || 'image/jpeg';
        const base64 = `data:${mimeType};base64,${buffer.toString('base64')}`;

        console.log('✅ [convert-base64] Conversão concluída');
        res.json({ base64 });
    } catch (err) {
        console.error('❌ [convert-base64] Erro:', err);
        res.status(500).json({ error: 'Erro ao converter imagem.', message: err.message });
    }
});

// Endpoint 2 – Extrai título e imagem de uma página
app.post('/extrair-dados-url', async (req, res) => {
    const { url } = req.body;
    console.log('🔍 [extrair-dados-url] URL recebida:', url);

    if (!url) return res.status(400).json({ error: 'URL não informada' });

    try {
        const response = await fetch(url, {
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });

        const html = await response.text();
        const $ = cheerio.load(html);

        const titulo = $('title').first().text().trim();
        let imagem = $('meta[property="og:image"]').attr('content') ||
                     $('meta[name="twitter:image"]').attr('content') ||
                     $('img').first().attr('src');

        if (imagem && !imagem.startsWith('http')) {
            const baseURL = new URL(url);
            imagem = baseURL.origin + imagem;
        }

        console.log('✅ [extrair-dados-url] Dados extraídos:', { titulo, imagem });
        res.json({ titulo, imagem });
    } catch (err) {
        console.error('❌ [extrair-dados-url] Erro:', err);
        res.status(500).json({ error: 'Falha ao extrair dados da URL', message: err.message });
    }
});

// Endpoint 3 – Proxy OCR.space
app.post('/ocr', async (req, res) => {
    const { base64 } = req.body;
    console.log('🧠 [OCR] Requisição recebida');

    if (!base64) {
        return res.status(400).json({ error: 'Base64 não fornecido.' });
    }

    try {
        const formData = new URLSearchParams();
        formData.append('base64Image', 'data:image/png;base64,' + base64);
        formData.append('language', 'por');
        formData.append('isOverlayRequired', 'false');
        formData.append('apikey', 'K88920229388957');

        const response = await fetch('https://api.ocr.space/parse/image', {
            method: 'POST',
            body: formData
        });

        const rawText = await response.text();
        let json;

        try {
            json = JSON.parse(rawText);
        } catch (parseError) {
            console.error('❌ [OCR] Resposta inválida (não-JSON):', rawText);
            return res.status(502).json({ error: 'Resposta inesperada do OCR.space', raw: rawText });
        }

        if (json.IsErroredOnProcessing) {
            console.warn('⚠️ [OCR] Erro retornado:', json.ErrorMessage || json.ErrorDetails);
            return res.status(400).json({ error: json.ErrorMessage || 'Erro no OCR.space' });
        }

        const texto = json.ParsedResults?.[0]?.ParsedText || '';
        console.log('✅ [OCR] Texto extraído com sucesso:', texto);
        res.json({ texto });

    } catch (err) {
        console.error('❌ [OCR] Erro na requisição:', err);
        res.status(500).json({ error: 'Erro ao comunicar com OCR.space.', message: err.message });
    }
});


// Inicia o servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
});
