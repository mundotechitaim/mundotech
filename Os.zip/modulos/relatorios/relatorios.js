document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('.btn-relatorio');
    const header = document.getElementById('relatorioHeader');
    const body = document.getElementById('relatorioBody');
    const btnReimprimir = document.getElementById('btnReimprimirNota');

    buttons.forEach(btn => {
        btn.addEventListener('click', () => {
            const tipo = btn.getAttribute('data-relatorio');
            carregarRelatorio(tipo);
        });
    });

    async function carregarRelatorio(tipo) {
        let url = `http://localhost:3000/relatorios/vendas/${tipo}`;
        try {
            const res = await fetch(url);
            const data = await res.json();
            renderizarTabela(tipo, data);
            btnReimprimir.style.display = 'block';
        } catch (error) {
            console.error('Erro ao carregar relatório:', error);
            alert('Erro ao carregar relatório.');
        }
    }

    function renderizarTabela(tipo, data) {
        header.innerHTML = '';
        body.innerHTML = '';

        if (tipo === 'diario') {
            header.innerHTML = '<th>Data</th><th>Qtd. Vendas</th><th>Total Vendido</th>';
            data.forEach(item => {
                body.innerHTML += `<tr>
                    <td>${item.data}</td>
                    <td>${item.qtd_vendas}</td>
                    <td>R$ ${item.total_vendas.toFixed(2)}</td>
                </tr>`;
            });
        } else if (tipo === 'mensal') {
            header.innerHTML = '<th>Mês</th><th>Qtd. Vendas</th><th>Total Vendido</th>';
            data.forEach(item => {
                body.innerHTML += `<tr>
                    <td>${item.mes}</td>
                    <td>${item.qtd_vendas}</td>
                    <td>R$ ${item.total_vendas.toFixed(2)}</td>
                </tr>`;
            });
        } else if (tipo === 'formas-pagamento') {
            header.innerHTML = '<th>Forma Pagamento</th><th>Qtd.</th><th>Total</th>';
            data.forEach(item => {
                body.innerHTML += `<tr>
                    <td>${item.forma_pagamento}</td>
                    <td>${item.qtd}</td>
                    <td>R$ ${item.total.toFixed(2)}</td>
                </tr>`;
            });
        } else if (tipo === 'vendedores') {
            header.innerHTML = '<th>Vendedor</th><th>Qtd. Vendas</th><th>Total</th>';
            data.forEach(item => {
                body.innerHTML += `<tr>
                    <td>${item.vendedor}</td>
                    <td>${item.qtd}</td>
                    <td>R$ ${item.total.toFixed(2)}</td>
                </tr>`;
            });
        } else if (tipo === 'ticket-medio') {
            header.innerHTML = '<th>Ticket Médio</th>';
            body.innerHTML += `<tr>
                <td>R$ ${data.ticket_medio.toFixed(2)}</td>
            </tr>`;
        }
    }

    btnReimprimir.addEventListener('click', () => {
        window.print();
    });
});
